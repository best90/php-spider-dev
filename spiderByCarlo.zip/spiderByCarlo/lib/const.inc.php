<?php
if (!defined('ROOT_PATH'))  die('Hacking attempt');
define('EOL',PHP_EOL);
define('TAB',"\t");
define('BS'," ");

define('CACHE_PATH',ROOT_PATH.'/cache');
define('TEMP_PATH',ROOT_PATH."/temp");
define('SQL_LOG_PATH',TEMP_PATH."/sql");
define('DATA_PATH',ROOT_PATH.'/data');