<?php

namespace Ares333\CurlMulti;

class Exception extends \Exception {
}