#!/usr/local/php/bin/php
<?php
require('./init.php');
require(ROOT_PATH . '/lib/Core/Core.php');
//require(ROOT_PATH . '/lib/Core/Base.php');

$param = (isset($argv[1]) && !empty($argv[1])) ? trim($argv[1]) : '';

if(strpos($param, '/')){
    $param = explode('/', $param);
    $task = lcfirst($param[0]);
    $action = lcfirst($param[1]);

    $file = ROOT_PATH .'/run/'.$task.'.class.php';
}else{
    $task = lcfirst($param);
    $file = ROOT_PATH .'/run/'.$task.'.php';
}


if(file_exists($file)){
	require_once($file);

    if(isset($action)){
        $task = ucfirst($task);
        $class = new $task();
        $class->$action();
    }
}else{
	echo "ERROR TASK : ".lcfirst($task);
}