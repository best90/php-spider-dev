#!/usr/local/php/bin/php
<?php
require('./init.php');
require(ROOT_PATH . '/lib/Core/Core.php');
require(ROOT_PATH . '/lib/Core/Base.php');
require(ROOT_PATH . '/lib/Core/Exception.php');
require(ROOT_PATH . '/crawl/spider.class.php');

$param = (isset($argv[1]) && !empty($argv[1])) ? trim($argv[1]) : '';

if(strpos($param, '/')){
    $param = explode('/', $param);
    $task = lcfirst($param[0]);
    $action = lcfirst($param[1]);

    $file = ROOT_PATH .'/crawl/'.$task.'.class.php';
}else{
    $task = lcfirst($param);
    $file = ROOT_PATH .'/crawl/'.$task.'.php';
}

if(file_exists($file)){
	require_once($file);

    if(isset($action)){
        $task = ucfirst($task);
        $class = new $task();

        if(method_exists($class, $action)){
            if(strpos($task, '_')){
                $dir_arr = explode('_', $task);
                $dir_name = end($dir_arr);
            }else{
                $dir_name = lcfirst($task);
            }
            
            $cache_dir = CACHE_PATH.'/'.$dir_name.'/';
            if(! file_exists( $cache_dir)) {
                mkdir($cache_dir);
            }

            $cache = $cache_dir.$action.'/';
            if(! file_exists( $cache )) {
                mkdir($cache);
            }

            if(method_exists($class, 'setCache')) $class->setCache($cache);
        }

        $class->$action();
    }
}else{
	echo "ERROR TASK : ".lcfirst($task);
}