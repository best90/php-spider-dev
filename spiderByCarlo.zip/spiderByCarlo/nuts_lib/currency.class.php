<?php

/**
 * TODO 大寫符號變小寫符號
 *
 */
final class Currency {
	// from http://www.xe.com/symbols.php
	public static $currency_to_symbol = [
		'ALL' => 'Lek',
		'AFN' => '؋',
		'ARS' => '$',
		'AWG' => 'ƒ',
		'AUD' => '$',
		'AZN' => 'ман',
		'BSD' => '$',
		'BBD' => '$',
		'BYR' => 'p.',
		'BZD' => 'BZ$',
		'BMD' => '$',
		'BOB' => '$b',
		'BAM' => 'KM',
		'BWP' => 'P',
		'BGN' => 'лв',
		'BRL' => 'R$',
		'BND' => '$',
		'KHR' => '៛',
		'CAD' => '$',
		'KYD' => '$',
		'CLP' => '$',
		'CNY' => '¥',
		'COP' => '$',
		'CRC' => '₡',
		'HRK' => 'kn',
		'CUP' => '₱',
		'CZK' => 'Kč',
		'DKK' => 'kr',
		'DOP' => 'RD$',
		'XCD' => '$',
		'EGP' => '£',
		'SVC' => '$',
		'EUR' => '€',
		'FKP' => '£',
		'FJD' => '$',
		'GHS' => '¢',
		'GIP' => '£',
		'GTQ' => 'Q',
		'GGP' => '£',
		'GYD' => '$',
		'HNL' => 'L',
		'HKD' => '$',
		'HUF' => 'Ft',
		'ISK' => 'kr',
		'INR' => null,
		'IDR' => 'Rp',
		'IRR' => '﷼',
		'IMP' => '£',
		'ILS' => '₪',
		'JMD' => 'J$',
		'JPY' => '¥',
		'JEP' => '£',
		'KZT' => 'лв',
		'KPW' => '₩',
		'KRW' => '₩',
		'KGS' => 'лв',
		'LAK' => '₭',
		'LBP' => '£',
		'LRD' => '$',
		'MKD' => 'ден',
		'MYR' => 'RM',
		'MUR' => '₨',
		'MXN' => '$',
		'MNT' => '₮',
		'MZN' => 'MT',
		'NAD' => '$',
		'NPR' => '₨',
		'ANG' => 'ƒ',
		'NZD' => '$',
		'NIO' => 'C$',
		'NGN' => '₦',
		'KPW' => '₩',
		'NOK' => 'kr',
		'OMR' => '﷼',
		'PKR' => '₨',
		'PAB' => 'B/.',
		'PYG' => 'Gs',
		'PEN' => 'S/.',
		'PHP' => '₱',
		'PLN' => 'zł',
		'QAR' => '﷼',
		'RON' => 'lei',
		'RUB' => 'руб',
		'SHP' => '£',
		'SAR' => '﷼',
		'RSD' => 'Дин.',
		'SCR' => '₨',
		'SGD' => '$',
		'SBD' => '$',
		'SOS' => 'S',
		'ZAR' => 'R',
		'KRW' => '₩',
		'LKR' => '₨',
		'SEK' => 'kr',
		'CHF' => 'CHF',
		'SRD' => '$',
		'SYP' => '£',
		'TWD' => 'NT$',
		'THB' => '฿',
		'TTD' => 'TT$',
		'TRY' => null,
		'TVD' => '$',
		'UAH' => '₴',
		'GBP' => '£',
		'USD' => '$',
		'UYU' => '$U',
		'UZS' => 'лв',
		'VEF' => 'Bs',
		'VND' => '₫',
		'YER' => '﷼',
		'ZWD' => 'Z$',
	];
	public static $full_size_symbol_to_half = [
		'＄' => '$',
		'￥' => '¥',
		'￡' => '£',
		'￦' => '₩',
		'￠' => '¢',
	];
	/**
	 * 只取最流通的貨幣
	 *
	 * @var [type]
	 */
	public static $symbol_to_currency = [
		'Lek' => 'ALL',
		'؋' => 'AFN',
		// '$' => 'ARS',
		'ƒ' => 'AWG',
		// '$' => 'AUD',
		'ман' => 'AZN',
		// '$' => 'BSD',
		// '$' => 'BBD',
		'p.' => 'BYR',
		'BZ$' => 'BZD',
		// '$' => 'BMD',
		'$b' => 'BOB',
		'KM' => 'BAM',
		'P' => 'BWP',
		'лв' => 'BGN',
		'R$' => 'BRL',
		// '$' => 'BND',
		'៛' => 'KHR',
		// '$' => 'CAD',
		// '$' => 'KYD',
		// '$' => 'CLP',
		'¥' => 'CNY',
		// '$' => 'COP',
		'₡' => 'CRC',
		'kn' => 'HRK',
		'₱' => 'CUP',
		'Kč' => 'CZK',
		'kr' => 'DKK',
		'RD$' => 'DOP',
		// '$' => 'XCD',
		// '£' => 'EGP',
		// '$' => 'SVC',
		'€' => 'EUR', // 歐元
		// '£' => 'FKP',
		// '$' => 'FJD',
		'¢' => 'GHS',
		// '£' => 'GIP',
		'Q' => 'GTQ',
		// '£' => 'GGP',
		// '$' => 'GYD',
		'L' => 'HNL',
		// '$' => 'HKD',
		'Ft' => 'HUF',
		'kr' => 'ISK',
		// null=>'INR',
		'Rp' => 'IDR',
		'﷼' => 'IRR',
		// '£' => 'IMP',
		'₪' => 'ILS',
		'J$' => 'JMD',
		// '¥' => 'JPY',
		// '£' => 'JEP',
		'лв' => 'KZT',
		'₩' => 'KPW',
		'₩' => 'KRW',
		'лв' => 'KGS',
		'₭' => 'LAK',
		// '£' => 'LBP',
		// '$' => 'LRD',
		'ден' => 'MKD',
		'RM' => 'MYR',
		'₨' => 'MUR',
		// '$' => 'MXN',
		'₮' => 'MNT',
		'MT' => 'MZN',
		// '$' => 'NAD',
		'₨' => 'NPR',
		'ƒ' => 'ANG',
		// '$' => 'NZD',
		'C$' => 'NIO',
		'₦' => 'NGN',
		'₩' => 'KPW',
		'kr' => 'NOK',
		'﷼' => 'OMR',
		'₨' => 'PKR',
		'B/.' => 'PAB',
		'Gs' => 'PYG',
		'S/.' => 'PEN',
		'₱' => 'PHP',
		'zł' => 'PLN',
		'﷼' => 'QAR',
		'lei' => 'RON',
		'руб' => 'RUB',
		// '£' => 'SHP',
		'﷼' => 'SAR',
		'Дин.' => 'RSD',
		'₨' => 'SCR',
		// '$' => 'SGD',
		// '$' => 'SBD',
		'S' => 'SOS',
		'R' => 'ZAR',
		'₩' => 'KRW',
		'₨' => 'LKR',
		'kr' => 'SEK',
		// 'CHF' => 'CHF',
		// '$' => 'SRD',
		// '£' => 'SYP',
		'NT$' => 'TWD',
		'฿' => 'THB',
		'TT$' => 'TTD',
		// null=>'TRY',
		// '$' => 'TVD',
		'₴' => 'UAH',
		'£' => 'GBP', // 英鎊
		'$' => 'USD',
		'$U' => 'UYU',
		'лв' => 'UZS',
		'Bs' => 'VEF',
		'₫' => 'VND',
		'﷼' => 'YER',
		'Z$' => 'ZWD',
	];
	public static $zh_to_currency = [
		'美元' => 'USD',
		'美金' => 'USD',
		//
		'日元' => 'JPY',
		//
		'欧元' => 'EUR',
		'歐元' => 'EUR',
		//
		'英镑' => 'GBP',
		'英鎊' => 'GBP',
		//
		'人民币' => 'CNY',
		'人民幣' => 'CNY',
		//
		'港元' => 'HKD',
		'港币' => 'HKD',
		'港幣' => 'HKD',
		//
		'新台币' => 'TWD',
		'新台幣' => 'TWD',
	];
	public static $zh_to_standard_key = [
		//
		'零' => '○', // 有零可能有 ex: 一千零一 => 1001
		//
		'壹' => '一',
		//
		'貳' => '二',
		'貮' => '二',
		'贰' => '二',
		'倆' => '二',
		'兩' => '二',
		//
		'參' => '三',
		'参' => '三',
		'叄' => '三',
		'叁' => '三',
		//
		'肆' => '四',
		//
		'伍' => '五',
		//
		'陸' => '六',
		'陆' => '六',
		//
		'柒' => '七',
		//
		'捌' => '八',
		//
		'玖' => '九',
		// more
		'拾' => '十',
		'佰' => '百',
		'陌' => '百',
		'仟' => '千',
		'阡' => '千',
		'万' => '萬',
		'亿' => '億',

		'毛' => '角',
		// https://zh.wikipedia.org/wiki/%E5%88%86_(%E8%B2%A8%E5%B9%A3)
		// 1/100 元
		'仙' => '分',
		'厘' => '分',
		'仙' => '分',
		'針' => '分',

		// special chars
		'圓' => '元',
		'圆' => '元',
		'塊' => '元',
		'正' => '整',
		// 不定量詞
		'数' => '數',
		'几' => '數',
		'幾' => '數',
		'约' => '約',
		'级' => '級',

		// 無意義的語尾助詞
		'个' => '', // ex: 十個億 === 十億
		'個' => '',
	];
	// 漢語拼音
	// public static $pinyin_to_standard_key = [
	// 	'yī' => '一',
	// 	'èr' => '二',
	// 	'sān' => '三',
	// 	'sì' => '四',
	// 	'wǔ' => '五',
	// 	'liù' => '六',
	// 	'qī' => '七',
	// 	'bā' => '八',
	// 	'jiǔ' => '九',
	// 	'shí' => '十',
	// ];
	public static $fuzzle_keys = [
		'數', // ex: 數十塊 => [20, 99], 十數塊 => [11, 19],
		'多', // ex: 十多塊 => [11, 19], 十塊多 => ?????,
		'級', // ex: 千萬級 => [10000000, 90000000]
		'近', // ex: 近千萬 => [9000000, 10000000]
		'超', // ex: 超千萬 => [10000000, 11000000]
		'約', // ex: 约千萬 => [10000000]
	];
	public static $full_size_number_to_half = [
		'０' => 0,
		'１' => 1,
		'２' => 2,
		'３' => 3,
		'４' => 4,
		'５' => 5,
		'６' => 6,
		'７' => 7,
		'８' => 8,
		'９' => 9,
	];
	public static $safe_zh_to_number = [
		'一' => 1,
		'二' => 2,
		'三' => 3,
		'四' => 4,
		'五' => 5,
		'六' => 6,
		'七' => 7,
		'八' => 8,
		'九' => 9,
	];
	public static $zh_key_to_multipier = [
		//
		'分' => 0.01,
		'角' => 0.1,
		'十' => 10,
		'百' => 100,
		'千' => 1000,
		'萬' => 10000,
		'億' => 100000000,
		'兆' => 1000000000000,
		'京' => 10000000000000000,

		// 一 (10^0) ㄧ
		// 十 (10^1) ㄕˊ
		// 百 (10^2) ㄅㄞˇ
		// 千 (10^3) ㄑㄧㄢ
		// 萬 (10^4~10^7) ㄨㄢˋ
		// 億 (10^8~10^11) ㄧˋ
		// 兆 (10^12~10^15) ㄓㄠˋ
		// 京 (10^16~10^19) ㄐㄧㄥ
		//
		// 下面太大應該不會用到
		//
		// 垓 (10^20~10^23) ㄍㄞ
		// 秭 (10^24~10^27) ㄗˇ
		// 穰 (10^28~10^31) ㄖㄤˊ
		// 溝 (10^32~10^35) ㄍㄡ
		// 澗 (10^36~10^39) ㄐㄧㄢˋ
		// 正 (10^40~10^43) ㄓㄥˋ
		// 載 (10^44~10^47) ㄗㄞˋ
		// 極 (10^48~10^51) ㄐㄧˊ
		// 恒河沙 (10^52~10^55) ㄏㄥˊㄏㄜˊㄕㄚ
		// 阿僧祇 (10^56~10^59) ㄚ　ㄙㄥ　ㄓˇ
		// 那由他 (10^60~10^63) ㄋㄚˋㄧㄡˊㄊㄚ
		// 不可思議 (10^64~10^67) ㄅㄨˋㄎㄜˇㄙ　ㄧˋ
		// 無量 (10^68~10^71) ㄨˊㄌㄧㄤˋ
		// 大數 (10^72~10^75) ㄉㄚˋㄕㄨˋ
	];
	/**
	 * this method will modify input $str
	 *
	 * @example
	 *
	 * // input
	 * 'abcde',
	 * ['a'=>'甲', 'b'=>'乙']
	 *
	 * // output
	 * ['a', 'b'], ('cde')
	 *
	 * @param  string &$str [description]
	 * @return string       currency key
	 */
	protected static function trimPart(&$str, $map) {
		$delimiter = '/';
		$preg_option = 'i';
		$converted_list = [];
		foreach ($map as $key => $value) {
			$pattern = $delimiter . preg_quote($key, $delimiter) . $delimiter . $preg_option;
			if (preg_match_all($pattern, $str, $match)) {
				$str = preg_replace($pattern, '', $str);
				array_push($converted_list, $key);
			}
		}
		return $converted_list;
	}
	public static function trimCurrencyPart(&$str) {
		$currency = self::trimPart($str, self::$currency_to_symbol);
		foreach (self::trimPart($str, self::$zh_to_currency) as $char) {
			if (!in_array(self::$zh_to_currency[$char], $currency)) {
				array_push($currency, self::$zh_to_currency[$char]);
			}
		}
		return $currency;
	}
	public static function trimSymbolPart(&$str) {
		return self::trimPart($str, self::$symbol_to_currency);
	}
	protected static function convertString($str, $kv_map) {
		$delimiter = '/';
		$preg_option = 'i';
		foreach ($kv_map as $key => $value) {
			$pattern = $delimiter . preg_quote($key, $delimiter) . $delimiter . $preg_option;
			$str = preg_replace($pattern, $value, $str);
		}
		return $str;
	}
	public static function toStandardString($str) {
		// TODO: zhs to zht

		// currency key parts
		$str = self::convertString($str, self::$full_size_symbol_to_half);

		// number parts
		$str = self::convertString($str, self::$zh_to_standard_key);

		// replace full size char to number char
		$str = self::convertString($str, self::$full_size_number_to_half);
		$str = self::convertString($str, self::$safe_zh_to_number);
		return $str;
	}
	/**
	 * http://blog.binux.me/2011/03/python-tools-chinese-digit/
	 *
	 * @param  [type] &$str [description]
	 * @return [type]       [description]
	 */
	public static function trimMoneyPart(&$str) {
		$str_list = [];
		$pattern = '/^[0-9]+$/';
		if (preg_match($pattern, $str)) {
			$number = (int) $str;
			$str = '';
			return $number;
		}
		$result = 0;
		$partial_result = 0;
		$result_list = [];
		$fuzzle_type = false;
		$temp_number = '';
		$multipier = 1;
		for ($i = 0; $i < mb_strlen($str); $i++) {
			$char = mb_substr($str, $i, 1);
			if (preg_match('/^[0-9\.]$/', $char)) {
				$temp_number .= $char;
				if ($partial_result > 0) {
					$result += $partial_result;
					$partial_result = 0;
				}
			} elseif (isset(self::$zh_key_to_multipier[$char])) {
				$multipier = self::$zh_key_to_multipier[$char];
				if ($partial_result > 0) {
					$partial_result *= $multipier;
				} else {
					if ($temp_number === '') {
						$temp_number = 1;
					}
					$partial_result = $temp_number * $multipier;
					if ($fuzzle_type === '~') {
						if (!empty($result_list)) {
							$result_list = array_map(function ($row) use ($multipier) {
								return $row * $multipier;
							}, $result_list);
						}
					}
					$temp_number = '';
				}
			} elseif (in_array($char, self::$fuzzle_keys)) {
				switch ($char) {
				case '級':
					$fuzzle_type = 'prefix_2';
					break;
				case '近':
					$fuzzle_type = 'prefix_3';
					break;
				case '超':
					$fuzzle_type = 'prefix_4';
					break;
				case '約':
					$fuzzle_type = 'prefix_5';
					break;
				default:
					if ($temp_number === '') {
						$fuzzle_type = 'prefix';
					} else {
						$fuzzle_type = 'suffix';
					}
					break;
				}
			} else {
				if (trim($char) !== '') {
					if ($char === '-' ||
						$char === '~') {
						$fuzzle_type = '~';
						$temp_result = 0;
						if ($partial_result > 0) {
							$temp_result += $partial_result;
						}
						if (!empty($temp_number)) {
							$temp_result += $temp_number;
						}
						array_push($result_list, $temp_result);
						$partial_result = 0;
						$temp_number = '';
					} else {
						array_push($str_list, $char);
					}
				}
			}
		}
		if ($partial_result > 0) {
			$result += $partial_result;
		}
		if (!empty($temp_number)) {
			$result += $temp_number;
		}
		$str = implode('', $str_list);
		switch ($fuzzle_type) {
		case 'prefix':
			return [$result * 2, $result * 9];
			break;
		case 'prefix_2':
			return [$result * 1, $result * 9];
			break;
		case 'prefix_3':
			return [$result * 0.9, $result];
			break;
		case 'prefix_4':
		case 'prefix_5':
			return [$result];
			break;
		case 'suffix':
			return [$result * 1.1, $result * 1.9];
			break;
		case '~':
			return array_merge($result_list, [$result]);
		default:
			return $result;
		}
	}
	/**
	 * @example
	 *
	 * // input
	 * '數千萬元人民幣'
	 *
	 * // output
	 * [
	 *     money=>[1000,9999],
	 *     currency=>'CNY'
	 * ]
	 *
	 * // input
	 * CNY75600
	 *
	 * // output
	 * [
	 *     money=>75600,
	 *     currency=>'CNY'
	 * ]
	 *
	 * @return Money
	 */
	public static function toMoney($str) {
		$result = [
			'_source' => $str,
		];
		$str = self::toStandardString($str);

		// 判斷 currency
		$currency = self::trimCurrencyPart($str);
		$symbol = self::trimSymbolPart($str);

		if (empty($currency)) {
			$currency = null;
		} elseif (count($currency) === 1) {
			$currency = $currency[0];
		}

		if (empty($symbol)) {
			$symbol = null;
		} elseif (count($symbol) === 1) {
			$symbol = $symbol[0];
		}

		$money = self::trimMoneyPart($str);

		if ($currency) {
			$result['currency'] = $currency;
		}
		if ($symbol) {
			$result['symbol'] = $symbol;
		}
		if ($money) {
			$result['money'] = $money;
		}
		if (strlen($str) !== 0) {
			$result['_left'] = $str;
		}
		return $result;
	}
}