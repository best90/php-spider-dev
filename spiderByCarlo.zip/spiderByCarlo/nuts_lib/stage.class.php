<?php 
    class Stage{
        //获取获投状态
        public static function toStageId($fund_status){
            
            switch ($fund_status) {
                case '尚未获投':
                    return 1;
                    break;
                case '未融资':
                    return 1;
                    break;
                case '不需要融资':
                    return 1;
                    break;
                case 'No financing':
                    return 1;
                    break;
                case '种子轮':
                    return 2;
                    break;
                case 'Angel round':
                    return 3;
                    break;
                case '天使轮':
                    return 3;
                    break;
                case 'Pre-A':
                    return 4;
                    break;
                case 'Pre-A轮':
                    return 4;
                    break;
                case 'A round':
                    return 5;
                    break;
                case 'A轮':
                    return 5;
                    break;
                case 'A+轮':
                    return 6;
                    break;
                case 'Pre-B轮':
                    return 7;
                    break;
                case 'B 轮':
                    return 8;
                    break;
                case 'B轮':
                    return 8;
                    break;
                case 'B+轮':
                    return 9;
                    break;
                case 'C轮':
                    return 10;
                    break;
                case 'D轮':
                    return 11;
                    break;
                case 'D轮及以上':
                    return 11;
                    break;
                case 'E轮':
                    return 12;
                    break;
                case 'E轮及以后':
                    return 12;
                    break;
                case 'F轮':
                    return 13;
                    break;
                case 'F轮-上市前':
                    return 13;
                    break;
                case 'Pre-IPO':
                    return 13;
                    break;
                case 'PreIPO':
                    return 13;
                    break;
                case 'IPO上市':
                    return 14;
                    break;
                case 'IPO上市后':
                    return 14;
                    break;
                case 'IPO及以后':
                    return 14;
                    break;
                case '新三板':
                    return 14;
                    break;
                case '上市':
                    return 14;
                    break;
                case 'IPO':
                    return 14;
                    break;
                case '已上市':
                    return 14;
                    break;
                case '上市公司':
                    return 14;
                    break;
                case '被收购':
                    return 15;
                    break;
                case '并购':
                    return 15;
                    break;
                case '已被收购':
                    return 15;
                    break;
                case '被收购':
                    return 15;
                    break;
                case '战略投资':
                    return 16;
                    break;
                default:
                    return 0;
                    break;
            }
        }
    }