<?php

/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2016/6/29
 * Time: 16:56
 */
class Spider_complete extends Spider
{
    public $db;

    public function _init(){
        $this->db = new PDO('mysql:dbname=complete;host=127.0.0.1','root','root');
        $this->db->exec('set name utf8');
    }

    /**
     *从百度搜索项目官网
     */
    public function urlFromBaidu(){
        $this->curl->maxThread = 1;

        $res = $this->db->query("SELECT * FROM url WHERE status = 0 ORDER BY id LIMIT 100")->fetchAll(PDO::FETCH_ASSOC);

        while(count($res) > 0) {
            while(count($res) > 0) {
                $re = array_shift($res);

                $this->curl->add ( array (
                    'url' => 'https://www.baidu.com/s?wd='.urlencode($re['project_name']),
                    'opt' => array (
                        CURLOPT_HEADER => false,
                        CURLOPT_REFERER => 'https://www.baidu.com/',
                        //CURLOPT_PROXY => 'http://'.$ip,
                        CURLOPT_USERAGENT => userAgent(),
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_FOLLOWLOCATION => 0,
                        CURLOPT_SSL_VERIFYPEER => false,
                        /*CURLOPT_CONNECTTIMEOUT => 7,
                        CURLOPT_TIMEOUT => 20,*/
                    ),
                    'args' => array (
                        'id' => $re['id'],
                        'file' => $this->cache.$re['id'].'.html'
                    )
                ), array($this,'urlProcess'));
            }
            $this->curl->start ();

            $res = $this->db->query("SELECT * FROM url WHERE status = 0 ORDER BY id LIMIT 100")->fetchAll(PDO::FETCH_ASSOC);
        }
    }

    public function urlProcess($r, $args){
        if($r['info']['http_code'] == 200 && mb_strpos($r['content'], '</html>')){
            file_put_contents($args['file'], $r['content']);
            $sql = "UPDATE url SET status = 1,update_time='".date('Y-m-d H:i:s')."' WHERE id=".$args ['id'];
            $this->db->exec($sql);
        }
        flush();
    }
}