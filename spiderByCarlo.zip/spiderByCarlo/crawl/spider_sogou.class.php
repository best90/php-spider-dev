<?php
    use Ares333\CurlMulti\Core;

    class Spider_sogou{
        public $db;
        public $curl;

        public function __construct(){
            $this->curl = new Core();

            $this->db=new PDO('mysql:dbname=industry;host=127.0.0.1','root','root');
            $this->db->exec("set names utf8");

            $class = explode('_', __CLASS__);
            $dir = end($class);

            $this->cache_dir = CACHE_PATH.'/'.$dir.'/';
            if(! file_exists( $this->cache_dir)) {
                mkdir($this->cache_dir);
            }
        }

        public function zhihu(){
            $this->curl->maxThread = 1;

            $cache = $this->cache_dir.__FUNCTION__.'/';
            if(! file_exists( $cache )) {
                mkdir($cache);
            }

            $res = $this->db->query("SELECT * FROM zhihu ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);

            foreach ($res as $re) {      
                $this->curl->add ( array (
                    'url' => 'http://zhihu.sogou.com/zhihu?query='.urlencode($re['name']).'&ie=utf8',
                    'opt' => array (
                        CURLOPT_HEADER => false,
                        CURLOPT_REFERER => 'http://zhihu.sogou.com/',
                        CURLOPT_USERAGENT => userAgent(),
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_FOLLOWLOCATION => 0, 
                        CURLOPT_SSL_VERIFYPEER => false,
                    ),
                    'args' => array (
                        'id' => $re['id'],
                        'file' => $cache.$re['id'].'.html'
                    )
                ), array($this,'cbProcess'));
            }

            $this->curl->start();
        }

        public function weixin(){
            $this->curl->maxThread = 1;

            $cache = $this->cache_dir.__FUNCTION__.'/';
            if(! file_exists( $cache )) {
                mkdir($cache);
            }

            $res = $this->db->query("SELECT * FROM weixin ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);

            foreach ($res as $re) {      
                $this->curl->add ( array (
                    'url' => 'http://weixin.sogou.com/weixin?ie=utf8&type=2&query='.urlencode($re['name']),
                    'opt' => array (
                        CURLOPT_HEADER => false,
                        CURLOPT_REFERER => 'http://weixin.sogou.com/',
                        CURLOPT_USERAGENT => userAgent(),
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_FOLLOWLOCATION => 0, 
                        CURLOPT_SSL_VERIFYPEER => false,
                    ),
                    'args' => array (
                        'id' => $re['id'],
                        'file' => $cache.$re['id'].'.html'
                    )
                ), array($this,'cbProcess'));
            }

            $this->curl->start();
        }

        public function cbProcess($r, $args) {
            if(mb_strpos($r['content'], '</html>')){
                file_put_contents($args['file'], $r['content']);
                echo 'crawl '.$args ['file']." success\n";
                sleep(mt_rand(5,20));
            }
            flush();
        }
    }