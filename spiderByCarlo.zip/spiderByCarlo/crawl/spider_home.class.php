<?php
    use Ares333\CurlMulti\Core;

    class Spider_home{
        public $db;
        public $curl;

        public function __construct(){
            $this->curl = new Core();

            $this->db=new PDO('mysql:dbname=company;host=127.0.0.1','root','root');
            $this->db->exec("set names utf8");

            $class = explode('_', __CLASS__);
            $dir = end($class);

            $this->cache_dir = CACHE_PATH.'/'.$dir.'/';
            if(! file_exists( $this->cache_dir)) {
                mkdir($this->cache_dir);
            }
        }

        public function url(){
            $this->curl->maxThread = 3;

            $cache = $this->cache_dir.__FUNCTION__.'/';
            if(! file_exists( $cache )) {
                mkdir($cache);
            }

            $res = $this->db->query("SELECT * FROM project WHERE company_id = 0 and status = 0 ORDER BY id LIMIT 100")->fetchAll(PDO::FETCH_ASSOC);

            while(count($res) > 0){
                while(count($res) > 0){
                    $ip = mt_rand(101,120).'.'.mt_rand(50,250).'.'.mt_rand(10,250).'.'.mt_rand(10,250);
                    $re = array_shift($res);

                    if(!$this->filterUrl($re['url'])){
                        $sql = "UPDATE project SET status = -1,update_time=".date('Y-m-d H:i:s')." WHERE id=".$re['id'];
                        $this->db->exec($sql);
                        continue;
                    } 
                    
                    $this->curl->add ( array (
                        'url' => $re['url'],
                        'opt' => array (
                            CURLOPT_HEADER => false,
                            CURLOPT_HTTPHEADER => array('X-FORWARDED-FOR:'.$ip.'','CLIENT-IP:'.$ip.''),
                            CURLOPT_REFERER => 'http://www.baidu.com/',
                            CURLOPT_USERAGENT => userAgent(),
                            CURLOPT_RETURNTRANSFER => true,
                            CURLOPT_FOLLOWLOCATION => 0, 
                            CURLOPT_SSL_VERIFYPEER => false,
                        ),
                        'args' => array (
                            'id' => $re['id'],
                            'file' => $cache.$re['id'].'.html'
                        )
                    ), array($this,'cbProcess'), array($this,'failProcess'));
                }

                $this->curl->start ();

                $res = $db->query("SELECT * FROM project WHERE company_id = 0 and status = 0 ORDER BY id LIMIT 100")->fetchAll(PDO::FETCH_ASSOC);
            }
            $this->curl->start();
        }

        public function cbProcess($r, $args) {
            if(mb_strpos($r['content'], '</html>')){
                file_put_contents($args['file'], $r['content']);
                echo 'crawl '.$args ['file']." success\n";
                $sql = "UPDATE project SET status = 1,update_time=".date('Y-m-d H:i:s')." WHERE id=".$args['id'];
                $this->db->exec($sql);
            }else{
                $sql = "UPDATE project SET status = -1,update_time=".date('Y-m-d H:i:s')." WHERE id=".$args['id'];
                $this->db->exec($sql);
            }
            flush();
        }

        public function failProcess($r, $args){
            $sql = "UPDATE project SET status = -1,update_time=".date('Y-m-d H:i:s')." WHERE id=".$args['id'];
            $this->db->exec($sql);
        }

        //过滤URL
        private function filterUrl($url){
            if(empty($url)) return false;
            if(strpos($url, 'weibo.com/u') !== false || strpos($url, '无') !== false || strpos($url, 't.qq.com') !== false) return false;
            if(strpos($url, 'app.weibo.com') !== false || strpos($url, 'lagou.com/gongsi') !== false || strpos($url, 'mp.weixin.qq.com') !== false) return false;
            if(strpos($url, 'buluo.qq.com') !== false || strpos($url, 'baike.baidu.com') !== false || strpos($url, 'baike.haosou.com') !== false) return false;
            if(strpos($url, 'baike.so.com') !== false || strpos($url, 'baike.sogou.com') !== false || strpos($url, '@') !== false) return false;
            if(strpos($url, 'taobao.com') !== false || strpos($url, 'tmall.com') !== false) return false;
            if(strpos($url, 'app.qq.com') !== false || strpos($url, 'tieba.baidu.com') !== false || strpos($url, 'pan.baidu.com') !== false) return false;

            return true;
        }
    }