<?php

/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2016/6/27
 * Time: 13:53
 */
class Spider_news extends Spider{
    public $db;
    public function _init(){
        $this->db = new PDO('mysql:dbname=news;host=127.0.0.1','root','root');
        $this->db->exec("set names utf8");
    }
    //百度新闻搜索
    public function baidu(){
        $this->curl->maxThread = 1;
        
        $res = $this->db->query("SELECT * FROM search WHERE baidu = 0 ORDER BY id LIMIT 100")->fetchAll(PDO::FETCH_ASSOC);

        while(count($res) > 0) {
            while(count($res) > 0) {
                $re = array_shift($res);

                $this->curl->add ( array (
                    'url' => 'http://news.baidu.com/ns?tn=news&word='.urlencode($re['project_name']),
                    'opt' => array (
                        CURLOPT_HEADER => false,
                        CURLOPT_REFERER => 'http://news.baidu.com/',
                        //CURLOPT_PROXY => 'http://'.$ip,
                        CURLOPT_USERAGENT => userAgent(),
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_FOLLOWLOCATION => 0,
                        CURLOPT_SSL_VERIFYPEER => false,
                        /*CURLOPT_CONNECTTIMEOUT => 7,
                        CURLOPT_TIMEOUT => 20,*/
                    ),
                    'args' => array (
                        'id' => $re['id'],
                        'file' => $this->cache.$re['id'].'.html'
                    )
                ), array($this,'baiduProcess'));
            }
            $this->curl->start ();

            $res = $this->db->query("SELECT * FROM search WHERE baidu = 0 ORDER BY id LIMIT 100")->fetchAll(PDO::FETCH_ASSOC);
        }
    }
    
    //IT桔子新闻
    public function itjuzi(){
        $this->curl->maxThread = 3;

        $res = $this->db->query("SELECT * FROM search WHERE itjuzi = 0 ORDER BY id LIMIT 100")->fetchAll(PDO::FETCH_ASSOC);

        while(count($res) > 0) {
            while(count($res) > 0) {
                $re = array_shift($res);
                $ip = mt_rand(101,120).'.'.mt_rand(50,250).'.'.mt_rand(10,250).'.'.mt_rand(10,250);

                $this->curl->add ( array (
                    'url' => 'https://www.itjuzi.com/search?type=juzi_news&key='.urlencode($re['project_name']),
                    'opt' => array (
                        CURLOPT_HEADER => false,
                        CURLOPT_HTTPHEADER => array('X-FORWARDED-FOR:'.$ip.'','CLIENT-IP:'.$ip.''),
                        CURLOPT_USERAGENT => 'Mozilla/5.0 (compatible; Baiduspider/2.0; +http://www.baidu.com/search/spider.html)',
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_FOLLOWLOCATION => 0,
                        CURLOPT_SSL_VERIFYPEER => false,
                    ),
                    'args' => array (
                        'id' => $re['id'],
                        'file' => $this->cache.$re['id'].'.html'
                    )
                ), array($this,'itjuziProcess'));
            }
            $this->curl->start ();

            $res = $this->db->query("SELECT * FROM search WHERE itjuzi = 0 ORDER BY id LIMIT 100")->fetchAll(PDO::FETCH_ASSOC);
        }
    }

    //36氪新闻
    public function kr36(){
        $this->curl->maxThread = 3;

        $res = $this->db->query("SELECT * FROM search WHERE 36kr = 0 ORDER BY id LIMIT 100")->fetchAll(PDO::FETCH_ASSOC);

        while(count($res) > 0) {
            while(count($res) > 0) {
                $re = array_shift($res);
                $ip = mt_rand(101,120).'.'.mt_rand(50,250).'.'.mt_rand(10,250).'.'.mt_rand(10,250);

                $this->curl->add ( array (
                    'url' => 'http://36kr.com/asynces/newsflashes/search.json?q='.urlencode($re['project_name']),
                    'opt' => array (
                        CURLOPT_HEADER => false,
                        CURLOPT_HTTPHEADER => array('X-FORWARDED-FOR:'.$ip.'','CLIENT-IP:'.$ip.''),
                        CURLOPT_USERAGENT => 'Mozilla/5.0 (compatible; Baiduspider/2.0; +http://www.baidu.com/search/spider.html)',
                        CURLOPT_REFERER => 'http://36kr.com/newsflashes',
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_FOLLOWLOCATION => 0,
                        CURLOPT_SSL_VERIFYPEER => false,
                    ),
                    'args' => array (
                        'id' => $re['id'],
                        'file' => $this->cache.$re['id'].'.txt'
                    )
                ), array($this,'krProcess'));
            }
            $this->curl->start ();

            $res = $this->db->query("SELECT * FROM search WHERE 36kr = 0 ORDER BY id LIMIT 100")->fetchAll(PDO::FETCH_ASSOC);
        }
    }

    //虎嗅网新闻
    public function huxiu(){
        $this->curl->maxThread = 3;

        $res = $this->db->query("SELECT * FROM search WHERE huxiu = 0 ORDER BY id LIMIT 100")->fetchAll(PDO::FETCH_ASSOC);

        while(count($res) > 0) {
            while(count($res) > 0) {
                $re = array_shift($res);
                $ip = mt_rand(101,120).'.'.mt_rand(50,250).'.'.mt_rand(10,250).'.'.mt_rand(10,250);

                $this->curl->add ( array (
                    'url' => 'http://www.huxiu.com/search.html?s='.urlencode($re['project_name']),
                    'opt' => array (
                        CURLOPT_HEADER => false,
                        CURLOPT_HTTPHEADER => array('X-FORWARDED-FOR:'.$ip.'','CLIENT-IP:'.$ip.''),
                        CURLOPT_USERAGENT => userAgent(),
                        CURLOPT_REFERER => 'http://www.huxiu.com/search.html',
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_FOLLOWLOCATION => 0,
                        CURLOPT_SSL_VERIFYPEER => false,
                    ),
                    'args' => array (
                        'id' => $re['id'],
                        'file' => $this->cache.$re['id'].'.html'
                    )
                ), array($this,'huxiuProcess'));
            }
            $this->curl->start ();

            $res = $this->db->query("SELECT * FROM search WHERE huxiu = 0 ORDER BY id LIMIT 100")->fetchAll(PDO::FETCH_ASSOC);
        }
    }
    
    public function baiduProcess($r, $args){
        if($r['info']['http_code'] == 200 && mb_strpos($r['content'], '</html>')){
            file_put_contents($args['file'], $r['content']);
            //echo 'crawl '.$args ['file']." success\n";
            $sql = "UPDATE search SET baidu = 1,update_time='".date('Y-m-d H:i:s')."' WHERE id=".$args ['id'];
            $this->db->exec($sql);
        }
        //sleep(mt_rand(1,3));
        flush();
    }

    public function itjuziProcess($r, $args){
        if($r['info']['http_code'] == 200 && mb_strpos($r['content'], '</html>')){
            file_put_contents($args['file'], $r['content']);
            //echo 'crawl '.$args ['file']." success\n";
            $sql = "UPDATE search SET itjuzi = 1,update_time='".date('Y-m-d H:i:s')."' WHERE id=".$args ['id'];
            $this->db->exec($sql);
        }
        flush();
    }

    public function krProcess($r, $args){
        if($r['info']['http_code'] == 200 && mb_strpos($r['content'], '"code":200')){
            file_put_contents($args['file'], $r['content']);
            //echo 'crawl '.$args ['file']." success\n";
            $sql = "UPDATE search SET 36kr = 1,update_time='".date('Y-m-d H:i:s')."' WHERE id=".$args ['id'];
            $this->db->exec($sql);
        }elseif (mb_strpos($r['content'], '搜索关键词过长')){
            $this->db->exec("UPDATE search SET 36kr = -1,update_time='".date('Y-m-d H:i:s')."' WHERE id=".$args ['id']);
        }
        flush();
    }

    public function huxiuProcess($r, $args){
        if($r['info']['http_code'] == 200 && mb_strpos($r['content'], '</html>')){
            file_put_contents($args['file'], $r['content']);
            //echo 'crawl '.$args ['file']." success\n";
            $sql = "UPDATE search SET huxiu = 1,update_time='".date('Y-m-d H:i:s')."' WHERE id=".$args ['id'];
            $this->db->exec($sql);
        }
        flush();
    }
}