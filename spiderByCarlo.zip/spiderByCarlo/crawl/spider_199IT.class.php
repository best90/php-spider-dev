<?php
    use Ares333\CurlMulti\Core;

    class Spider_199IT{
        public $db;
        public $curl;

        public function __construct(){
            $this->curl = new Core();

            $this->db=new PDO('mysql:dbname=industry;host=127.0.0.1','root','root');
            $this->db->exec("set names utf8");

            $class = explode('_', __CLASS__);
            $dir = end($class);

            $this->cache_dir = CACHE_PATH.'/'.$dir.'/';
            if(! file_exists( $this->cache_dir)) {
                mkdir($this->cache_dir);
            }
        }

        public function search(){
            $this->curl->maxThread = 1;

            $cache = $this->cache_dir.__FUNCTION__.'/';
            if(! file_exists( $cache )) {
                mkdir($cache);
            }

            $res = $this->db->query("SELECT * FROM report ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);

            foreach ($res as $re) {      
                $this->curl->add ( array (
                    'url' => 'http://s.199it.com/cse/search?s=913566115233094367&entry=1&q='.urlencode($re['name']),
                    'opt' => array (
                        CURLOPT_HEADER => false,
                        CURLOPT_REFERER => 'http://www.199it.com/',
                        CURLOPT_USERAGENT => userAgent(),
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_FOLLOWLOCATION => 0, 
                        CURLOPT_SSL_VERIFYPEER => false,
                    ),
                    'args' => array (
                        'file' => $cache.$re['id'].'.html'
                    )
                ), array($this,'cbProcess'));
                
            }
            $this->curl->start();
        }

        public function cbProcess($r, $args) {
            $dom = phpQuery::newDocumentHTML($r['content']);
            $target = trim(pq($dom['#results .result:first'])->find('h3 a')->attr('href'));

            if($target){
                echo "ADD NEW URL : ".$target."\r\n";
                $this->curl->add ( array (
                        'url' => $target,
                        'args' => array (
                            'file' => $args['file']
                        )
                ), array($this,'nextProcess'));
            }
            sleep(mt_rand(1,5));
        }

        public function nextProcess($r, $args) {
            if(mb_strpos($r['content'], '</html>')){
                file_put_contents($args['file'], $r['content']);
                echo 'crawl '.$args ['file']." success\n";
                sleep(mt_rand(1,5));
            }
            flush();
        }
    }