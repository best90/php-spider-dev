<?php
    use Ares333\CurlMulti\Core;

    class Spider_so{
        public $db;
        public $curl;

        public function __construct(){
            $this->curl = new Core();

            $this->db=new PDO('mysql:dbname=industry;host=127.0.0.1','root','root');
            $this->db->exec("set names utf8");

            $class = explode('_', __CLASS__);
            $dir = end($class);

            $this->cache_dir = CACHE_PATH.'/'.$dir.'/';
            if(! file_exists( $this->cache_dir)) {
                mkdir($this->cache_dir);
            }
        }

        public function index(){
            $this->curl->maxThread = 1;

            $cache = $this->cache_dir.__FUNCTION__.'/';
            if(! file_exists( $cache )) {
                mkdir($cache);
            }

            $res = $this->db->query("SELECT * FROM index_word ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);

            foreach ($res as $re) {      
                $this->curl->add ( array (
                    'url' => 'http://index.so.com/index.php?a=soIndexJson&q='.urlencode($re['name']).'&area=%E5%85%A8%E5%9B%BD',
                    'opt' => array (
                        CURLOPT_HEADER => false,
                        CURLOPT_REFERER => 'http://index.so.com/',
                        CURLOPT_USERAGENT => userAgent(),
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_FOLLOWLOCATION => 0, 
                        CURLOPT_SSL_VERIFYPEER => false,
                    ),
                    'args' => array (
                        'file' => $cache.$re['id'].'.txt'
                    )
                ), array($this,'cbProcess'));
                
            }
            $this->curl->start();
        }

        public function cbProcess($r, $args) {
            if(mb_strpos($r['content'], '"status":0')){
                file_put_contents($args['file'], $r['content']);
                echo 'crawl '.$args ['file']." success\n";
                sleep(mt_rand(1,5));
            }
            flush();
        }
    }