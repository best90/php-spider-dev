<?php

/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2016/6/29
 * Time: 17:59
 */
class Spider_newseed extends Spider
{
    public function project(){
        $this->curl->maxThread = 1;

        $url = 'http://newseed.pedaily.cn/project/';

        for($i = 1; $i <= 52000; $i ++) {
            $ip = mt_rand(101,120).'.'.mt_rand(50,250).'.'.mt_rand(10,250).'.'.mt_rand(10,250);

            $this->curl->add ( array (
                'url' => $url . $i,
                'opt' => array (
                    CURLOPT_HEADER => false,
                    CURLOPT_HTTPHEADER => array('X-FORWARDED-FOR:'.$ip.'','CLIENT-IP:'.$ip.''),
                    CURLOPT_USERAGENT => 'Mozilla/5.0 (compatible; Baiduspider/2.0; +http://www.baidu.com/search/spider.html)',
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_SSL_VERIFYPEER => false
                ),
                'args' => array (
                    'file' => $this->cache.$i.'.html'
                )
            ), array($this,'process'));
        }

        $this->curl->start ();
    }

    public function process($r, $args){
        if($r['info']['http_code'] == 200 && mb_strpos($r['content'], '</html>')){
            file_put_contents($args['file'], $r['content']);
        }
        flush();
    }
}