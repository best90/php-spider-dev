<?php
    use Ares333\CurlMulti\Core;

    class Spider_cyzone{
        public $curl;
        public $cache_dir;

        public function __construct(){
            $this->curl = new Core();
            
            $class = explode('_', __CLASS__);
            $dir = end($class);

            $this->cache_dir = CACHE_PATH.'/'.$dir.'/';
            if(! file_exists( $this->cache_dir)) {
                mkdir($this->cache_dir);
            }
        }

        public function project(){
            $this->curl->maxThread = 3;

            $cache = $this->cache_dir.__FUNCTION__.'/';
            if(! file_exists( $cache )) {
                mkdir($cache);
            }

            $url = 'http://www.cyzone.cn/r/';

            for ($i=1; $i <= 26000; $i++) {
                $ip = mt_rand(101,120).'.'.mt_rand(50,250).'.'.mt_rand(10,250).'.'.mt_rand(10,250);

                $this->curl->add ( array (
                        'url' => $url.date('Ymd').'/'.$i.'.html',
                        'opt' => array (
                            CURLOPT_HEADER => false,
                            CURLOPT_HTTPHEADER => array('X-FORWARDED-FOR:'.$ip.'','CLIENT-IP:'.$ip.''),
                            CURLOPT_REFERER => 'http://www.cyzone.cn/vcompany/list-0-0-1/',
                            CURLOPT_USERAGENT => 'Mozilla/5.0 (compatible; Baiduspider/2.0; +http://www.baidu.com/search/spider.html)',
                            CURLOPT_RETURNTRANSFER => true,
                            CURLOPT_FOLLOWLOCATION => 0,
                            CURLOPT_SSL_VERIFYPEER => false
                        ),
                        'args' => array (
                                'file' => $cache.$i.'.html'
                        )
                ), array($this,'cbProcess'));
            }
            $this->curl->start ();
        }

        public function cbProcess($r, $args) {
            if($r['info']['http_code'] != 404){
                file_put_contents($args['file'], $r['content']);
                echo 'crawl '.$args ['file']." success\n";
                sleep(mt_rand(60,180));
            }else{
                echo "Not Found \n";
            }
            flush();
        }
    }