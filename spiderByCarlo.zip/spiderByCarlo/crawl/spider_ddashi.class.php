<?php
    use Ares333\CurlMulti\Core;
    require_once(ROOT_PATH . '/run/proxy.class.php');

    class Spider_ddashi{
        public $curl;
        public $proxy;
        public $proxy_db;

        public function __construct(){
            $this->curl = new Core();

            $class = explode('_', __CLASS__);
            $dir = end($class);

            $this->cache_dir = CACHE_PATH.'/'.$dir.'/';
            if(! file_exists( $this->cache_dir)) {
                mkdir($this->cache_dir);
            }

            $this->proxy = new Proxy();
            $this->proxy_db = new PDO('mysql:dbname=proxy;host=127.0.0.1','root','root');
            $this->proxy_db->exec("set names utf8");
        }

        //抓取搜索结果页
        public function search(){
            $db=new PDO('mysql:dbname=app;host=127.0.0.1','root','root');
            $db->exec("set names utf8");

            $this->curl->maxThread = 100;

            $cache = $this->cache_dir.__FUNCTION__.'/';
            if(! file_exists( $cache )) {
                mkdir($cache);
            }

            $res = $db->query("SELECT * FROM ddashi_list WHERE status = 0 ORDER BY id LIMIT 100")->fetchAll(PDO::FETCH_ASSOC);

            while(count($res) > 0) {
                $proxies = $this->proxy->getProxy();
                while(count($res) > 0) {
                    $re = array_shift($res);
                    $ip = array_shift($proxies);
                    while (empty($ip)) {
                        $ip = array_shift($proxies);
                    }
                    
                    $this->curl->add ( array (
                        'url' => 'http://www.chandashi.com/search/index.html?keyword='.urlencode($re['project_name']).'&type=store&view=web',
                        'opt' => array (
                            CURLOPT_HEADER => false,
                            //CURLOPT_HTTPHEADER => array('X-FORWARDED-FOR:'.$ip.'','CLIENT-IP:'.$ip.''),
                            CURLOPT_REFERER => 'http://www.chandashi.com/',
                            CURLOPT_PROXY => 'http://'.$ip,
                            CURLOPT_USERAGENT => userAgent(),
                            CURLOPT_RETURNTRANSFER => true,
                            CURLOPT_FOLLOWLOCATION => 0, 
                            CURLOPT_SSL_VERIFYPEER => false,
                            CURLOPT_CONNECTTIMEOUT => 7,
                            CURLOPT_TIMEOUT => 20,
                        ),
                        'args' => array (
                            'id' => $re['id'],
                            'name' => $re['project_name'],
                            'db' => $db,
                            'ip' => $ip,
                            'file' => $cache.$re['id'].'.html'
                        )
                    ), array($this,'cbProcess'),array($this,'failProcess'));
                }

                $this->curl->start ();

                $res = $db->query("SELECT * FROM ddashi_list WHERE status = 0 ORDER BY id LIMIT 100")->fetchAll(PDO::FETCH_ASSOC);
            }
        }

        //抓取App ios数据
        public function app_ios(){
            $db=new PDO('mysql:dbname=app;host=127.0.0.1','root','root');
            $db->exec("set names utf8");

            $this->curl->maxThread = 100;

            $cache = $this->cache_dir.__FUNCTION__.'/';
            if(! file_exists( $cache )) {
                mkdir($cache);
            }

            $res = $db->query("SELECT * FROM ddashi_app_list WHERE status = 0 ORDER BY id LIMIT 100")->fetchAll(PDO::FETCH_ASSOC);

            while(count($res) > 0) {
                $proxies = $this->proxy->getProxy();
                while(count($res) > 0) {
                    $re = array_shift($res);
                    $ip = array_shift($proxies);
                    while (empty($ip)) {
                        $ip = array_shift($proxies);
                    }
                    
                    $this->curl->add ( array (
                        'url' => 'http://www.chandashi.com'.$re['url'],
                        'opt' => array (
                            CURLOPT_HEADER => false,
                            //CURLOPT_HTTPHEADER => array('X-FORWARDED-FOR:'.$ip.'','CLIENT-IP:'.$ip.''),
                            CURLOPT_REFERER => 'http://www.chandashi.com/',
                            CURLOPT_PROXY => 'http://'.$ip,
                            CURLOPT_USERAGENT => userAgent(),
                            CURLOPT_RETURNTRANSFER => true,
                            CURLOPT_FOLLOWLOCATION => 0, 
                            CURLOPT_SSL_VERIFYPEER => false,
                            CURLOPT_CONNECTTIMEOUT => 7,
                            CURLOPT_TIMEOUT => 20,
                        ),
                        'args' => array (
                            'id' => $re['id'],
                            'db' => $db,
                            'ip' => $ip,
                            'file' => $cache.$re['id'].'.html'
                        )
                    ), array($this,'iosProcess'),array($this,'failProcess'));
                }

                $this->curl->start ();

                $res = $db->query("SELECT * FROM ddashi_app_list WHERE status = 0 ORDER BY id LIMIT 100")->fetchAll(PDO::FETCH_ASSOC);
            }
        }

        //抓取android搜索结果页
        public function search_android(){
            $db=new PDO('mysql:dbname=app;host=127.0.0.1','root','root');
            $db->exec("set names utf8");

            $this->curl->maxThread = 100;

            $cache = $this->cache_dir.__FUNCTION__.'/';
            if(! file_exists( $cache )) {
                mkdir($cache);
            }

            $res = $db->query("SELECT * FROM ddashi_list WHERE android_status = 0 ORDER BY id LIMIT 100")->fetchAll(PDO::FETCH_ASSOC);

            while(count($res) > 0) {
                //$this->proxy->run();
                $proxies = $this->proxy->getProxy();
                while(count($res) > 0) {
                    $re = array_shift($res);
                    $ip = array_shift($proxies);
                    while (empty($ip)) {
                        $ip = array_shift($proxies);
                    }

                    $this->curl->add ( array (
                        'url' => 'http://www.chandashi.com/search/index.html?keyword='.urlencode($re['project_name']).'&type=android&view=html',
                        'opt' => array (
                            CURLOPT_HEADER => false,
                            //CURLOPT_HTTPHEADER => array('X-FORWARDED-FOR:'.$ip.'','CLIENT-IP:'.$ip.''),
                            CURLOPT_REFERER => 'http://www.chandashi.com/',
                            CURLOPT_PROXY => 'http://'.$ip,
                            CURLOPT_USERAGENT => userAgent(),
                            CURLOPT_RETURNTRANSFER => true,
                            CURLOPT_FOLLOWLOCATION => 0,
                            CURLOPT_SSL_VERIFYPEER => false,
                            CURLOPT_CONNECTTIMEOUT => 7,
                            CURLOPT_TIMEOUT => 20,
                        ),
                        'args' => array (
                            'id' => $re['id'],
                            'db' => $db,
                            'ip' => $ip,
                            'file' => $cache.$re['id'].'.html'
                        )
                    ), array($this,'cb2Process'),array($this,'failProcess'));
                }

                $this->curl->start ();

                $res = $db->query("SELECT * FROM ddashi_list WHERE android_status = 0 ORDER BY id LIMIT 100")->fetchAll(PDO::FETCH_ASSOC);
            }
        }

        //抓取App android数据
        public function app_android(){
            $db=new PDO('mysql:dbname=app;host=127.0.0.1','root','root');
            $db->exec("set names utf8");

            $this->curl->maxThread = 100;

            $cache = $this->cache_dir.__FUNCTION__.'/';
            if(! file_exists( $cache )) {
                mkdir($cache);
            }

            $res = $db->query("SELECT * FROM ddashi_android_list WHERE status = 0 ORDER BY id LIMIT 100")->fetchAll(PDO::FETCH_ASSOC);

            while(count($res) > 0) {
                //$this->proxy->run();
                $proxies = $this->proxy->getProxy();
                while(count($res) > 0) {
                    $re = array_shift($res);
                    $ip = array_shift($proxies);
                    while (empty($ip)) {
                        $ip = array_shift($proxies);
                    }

                    if(strpos($re['url'], 'www.chandashi.com')) {
                        $url = $re['url'];
                    }else{
                        $url = 'http://www.chandashi.com'.$re['url'];
                    }
                    $this->curl->add ( array (
                        'url' => $url,
                        'opt' => array (
                            CURLOPT_HEADER => false,
                            //CURLOPT_HTTPHEADER => array('X-FORWARDED-FOR:'.$ip.'','CLIENT-IP:'.$ip.''),
                            CURLOPT_REFERER => 'http://www.chandashi.com/search/index.html?keyword='.urlencode($re['app_name']).'&type=android&view=html',
                            CURLOPT_PROXY => 'http://'.$ip,
                            CURLOPT_USERAGENT => userAgent(),
                            CURLOPT_RETURNTRANSFER => true,
                            CURLOPT_FOLLOWLOCATION => 0,
                            CURLOPT_SSL_VERIFYPEER => false,
                            CURLOPT_CONNECTTIMEOUT => 7,
                            CURLOPT_TIMEOUT => 20,
                        ),
                        'args' => array (
                            'id' => $re['id'],
                            'db' => $db,
                            'ip' => $ip,
                            'file' => $cache.$re['id'].'.html'
                        )
                    ), array($this,'androidProcess'),array($this,'failProcess'));
                }

                $this->curl->start ();

                $res = $db->query("SELECT * FROM ddashi_android_list WHERE status = 0 ORDER BY id LIMIT 100")->fetchAll(PDO::FETCH_ASSOC);
            }
        }

        public function cbProcess($r, $args) {
            if(mb_strpos($r['content'], '蝉大师') && mb_strpos($r['content'], '</html>')){
                file_put_contents($args['file'], $r['content']);
                echo 'crawl '.$args ['file']." success\n";
                $sql = "UPDATE ddashi_list SET status = 1,update_time='".date('Y-m-d H:i:s')."' WHERE id=".$args ['id'];
                $args ['db']->exec($sql);
                
                $this->proxy_db->exec("UPDATE proxy SET valid_counter = valid_counter + 1,update_time=".time()." WHERE proxy='".$args ['ip']."'");
            }else{
                $this->proxy_db->exec("UPDATE proxy SET status=0,update_time=".time()." WHERE proxy='".$args ['ip']."'");
            }
            //sleep(mt_rand(60,180));
            
            flush();
        }

        public function cb2Process($r, $args) {
            if(mb_strpos($r['content'], '蝉大师') && mb_strpos($r['content'], '</html>')){
                file_put_contents($args['file'], $r['content']);
                echo 'crawl '.$args ['file']." success\n";
                $sql = "UPDATE ddashi_list SET android_status = 1,update_time='".date('Y-m-d H:i:s')."' WHERE id=".$args ['id'];
                $args ['db']->exec($sql);

                $this->proxy_db->exec("UPDATE proxy SET valid_counter = valid_counter + 1,update_time=".time()." WHERE proxy='".$args ['ip']."'");
            }else{
                $this->proxy_db->exec("UPDATE proxy SET status=0,update_time=".time()." WHERE proxy='".$args ['ip']."'");
            }

            flush();
        }

        public function failProcess($r, $args){
            $this->proxy_db->exec("UPDATE proxy SET status=0,update_time=".time()." WHERE proxy='".$args ['ip']."'");
        }

        public function iosProcess($r, $args) {
            if(mb_strpos($r['content'], '蝉大师') && mb_strpos($r['content'], '</html>')){
                file_put_contents($args['file'], $r['content']);
                echo 'crawl '.$args ['file']." success\n";
                $sql = "UPDATE ddashi_app_list SET status = 1,update_time='".date('Y-m-d H:i:s')."' WHERE id=".$args ['id'];
                $args ['db']->exec($sql);
                
                $this->proxy_db->exec("UPDATE proxy SET valid_counter = valid_counter + 1,update_time=".time()." WHERE proxy='".$args ['ip']."'");
            }else{
                $this->proxy_db->exec("UPDATE proxy SET status=0,update_time=".time()." WHERE proxy='".$args ['ip']."'");
            }
            
            flush();
        }

        public function androidProcess($r, $args) {
            if(mb_strpos($r['content'], '蝉大师') && mb_strpos($r['content'], '</html>')){
                file_put_contents($args['file'], $r['content']);
                echo 'crawl '.$args ['file']." success\n";
                $sql = "UPDATE ddashi_android_list SET status = 1,update_time='".date('Y-m-d H:i:s')."' WHERE id=".$args ['id'];
                $args ['db']->exec($sql);

                $this->proxy_db->exec("UPDATE proxy SET valid_counter = valid_counter + 1,update_time=".time()." WHERE proxy='".$args ['ip']."'");
            }else{
                $this->proxy_db->exec("UPDATE proxy SET status=0,update_time='".date('Y-m-d H:i:s')."' WHERE proxy='".$args ['ip']."'");
            }

            flush();
        }
    }