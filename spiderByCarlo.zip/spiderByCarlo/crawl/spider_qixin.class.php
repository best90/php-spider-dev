<?php
    use Ares333\CurlMulti\Core;

    class Spider_qixin{
        public $curl;

        public function __construct(){
            $this->curl = new Core();
        }

        public function search(){
            $db=new PDO('mysql:dbname=qixin;host=127.0.0.1','root','root');
            $db->exec("set names utf8");

            $this->curl->maxThread = 1;

            $cache = CACHE_PATH . '/qixin/list_m/';
            if (! file_exists( $cache )) {
                mkdir($cache);
            }

            //$url = 'http://www.qixin.com/search?key=';
            $url = 'http://m.qixin.com/search/';
           
            $res = $db->query("SELECT id,company_name FROM company ORDER BY id ASC limit 1000")->fetchAll(PDO::FETCH_ASSOC);

            foreach ($res as $re) {
                //$cookie = "gr_user_id=f5d6427a-89f6-421b-ac4a-c6e0f7dbcaf2; Hm_lvt_52d64b8d3f6d42a2e416d59635df3f71=1463032339,1463109678,1463109895,1463143151; aliyungf_tc=AQAAAKKn0wTK3gMAvxA9OwbPZ+/xIOyI; Hm_lvt_020971628e81872ff6d45847a9a8f09c=1463314104; Hm_lpvt_020971628e81872ff6d45847a9a8f09c=1463315373; _alicdn_sec=57386bae5556a7bc0a53ae2f94139650c41ed97c";

                //$url = $url.urlencode($re['company_name']).'&type=enterprise&source=&isGlobal=Y';
                $this->curl->add ( array (
                        'url' => $url.urlencode($re['company_name']).'.html?province=',
                        'opt' => array (
                            CURLOPT_HEADER => true,
                            CURLOPT_HTTPHEADER => array("Upgrade-Insecure-Requests:1\n"),
                            CURLOPT_POST => 1,
                            CURLOPT_RETURNTRANSFER => true,
                            //CURLOPT_COOKIE => 'gr_user_id=f5d6427a-89f6-421b-ac4a-c6e0f7dbcaf2; pgv_pvid=3152814551; aliyungf_tc=AQAAABLtYR8DawYAvxA9OwPpGMYgOOvJ; __qc_wId=510; login_returnurl=http%3A//www.qixin.com/search%3Fkey%3DVisionary+20VR%26type%3Denterprise%26source%3D%26isGlobal%3DY; __qc__k=TC_MK=E291233D8F82D1430ABF39FB9468DA19; userKey=QXBAdmin-Web2.0_34MZRZ1+OueT5jQcMTAoWBN5KjpRZbcQfU9MWV+53Cg%3D; userValue=1190dd24-cb89-5b91-21b1-f499265d9870; Hm_lvt_52d64b8d3f6d42a2e416d59635df3f71=1462346123,1463032339,1463109678,1463109895; Hm_lpvt_52d64b8d3f6d42a2e416d59635df3f71=1463133862; gr_session_id_955c17a7426f3e98=53e89aaa-cf38-4ec0-9ccd-4a3816bc6a5f; _alicdn_sec=5735a77127fd720c192e4f5b09c783cba52958e8',
                            //CURLOPT_COOKIE => 'gr_user_id=f5d6427a-89f6-421b-ac4a-c6e0f7dbcaf2; Hm_lvt_52d64b8d3f6d42a2e416d59635df3f71=1463032339,1463109678,1463109895,1463143151; aliyungf_tc=AQAAAKKn0wTK3gMAvxA9OwbPZ+/xIOyI; Hm_lvt_020971628e81872ff6d45847a9a8f09c=1463314104; Hm_lpvt_020971628e81872ff6d45847a9a8f09c=1463315373; _alicdn_sec=57386bae5556a7bc0a53ae2f94139650c41ed97c',
                            CURLOPT_FOLLOWLOCATION => 1,
                            CURLOPT_SSL_VERIFYPEER => false
                        ),
                        'args' => array (
                                'file' => $cache.$re['id'].'.html'
                        )
                ), array($this,'cbProcess'));
            }

            $this->curl->start ();
        }

        public function cbProcess($r, $args) {
            file_put_contents($args['file'], $r['content']);
            echo $args ['file'] . " finished\n";
            flush();
            sleep(mt_rand(1,5));
        }
    }