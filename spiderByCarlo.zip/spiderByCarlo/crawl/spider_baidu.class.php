<?php
    use Ares333\CurlMulti\Core;

    class Spider_baidu{
        public $db;
        public $curl;

        public function __construct(){
            $this->curl = new Core();

            $this->db=new PDO('mysql:dbname=industry;host=127.0.0.1','root','root');
            $this->db->exec("set names utf8");

            $class = explode('_', __CLASS__);
            $dir = end($class);

            $this->cache_dir = CACHE_PATH.'/'.$dir.'/';
            if(! file_exists( $this->cache_dir)) {
                mkdir($this->cache_dir);
            }
        }

        public function baike(){
            $this->curl->maxThread = 1;

            $cache = $this->cache_dir.__FUNCTION__.'/';
            if(! file_exists( $cache )) {
                mkdir($cache);
            }

            $res = $this->db->query("SELECT * FROM baike ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);

            foreach ($res as $re) {      
                $this->curl->add ( array (
                    'url' => 'http://baike.baidu.com/search?word='.urlencode($re['name']).'&pn=0&rn=0&enc=utf8',
                    'opt' => array (
                        CURLOPT_HEADER => false,
                        CURLOPT_REFERER => 'http://baike.baidu.com/',
                        CURLOPT_USERAGENT => userAgent(),
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_FOLLOWLOCATION => 0, 
                        CURLOPT_SSL_VERIFYPEER => false,
                    ),
                    'args' => array (
                        'id' => $re['id'],
                        'file' => $cache.$re['id'].'.html'
                    )
                ), array($this,'cbProcess'));
            }

            $this->curl->start();
        }

        public function news(){
            $this->curl->maxThread = 1;

            $cache = $this->cache_dir.__FUNCTION__.'/';
            if(! file_exists( $cache )) {
                mkdir($cache);
            }

            $res = $this->db->query("SELECT * FROM news ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);

            foreach ($res as $re) {      
                $this->curl->add ( array (
                    'url' => 'http://www.baidu.com/s?tn=baidurt&rtt=1&bsst=1&wd='.urlencode($re['name']).'&origin=ps',
                    'opt' => array (
                        CURLOPT_HEADER => false,
                        CURLOPT_REFERER => 'http://www.baidu.com/',
                        CURLOPT_USERAGENT => userAgent(),
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_FOLLOWLOCATION => 0, 
                        CURLOPT_SSL_VERIFYPEER => false,
                    ),
                    'args' => array (
                        'id' => $re['id'],
                        'file' => $cache.$re['id'].'.html'
                    )
                ), array($this,'cbProcess'));
            }

            $this->curl->start();
        }

        //app111 厂商搜索
        public function app111(){
            $this->curl->maxThread = 1;

            $cache = $this->cache_dir.__FUNCTION__.'/';
            if(! file_exists( $cache )) {
                mkdir($cache);
            }

            for ($i=0; $i <= 76; $i++) { 
                if(filesize($cache.$i.'.html') > 10000) continue;
                $this->curl->add ( array (
                    'url' => 'https://www.baidu.com/s?wd=inurl%3Awww.app111.com%2Fdevinfo%2F&pn='.($i*10).'&oq=inurl%3Awww.app111.com%2Fdevinfo%2F&ie=utf-8',
                    'opt' => array (
                        CURLOPT_HEADER => false,
                        CURLOPT_REFERER => 'https://www.baidu.com/',
                        CURLOPT_USERAGENT => userAgent(),
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_FOLLOWLOCATION => 0, 
                        CURLOPT_SSL_VERIFYPEER => false,
                    ),
                    'args' => array (
                        'file' => $cache.$i.'.html'
                    )
                ), array($this,'cbProcess'));
            }

            $this->curl->start();
        }

        public function cbProcess($r, $args) {
            if(mb_strpos($r['content'], '</html>')){
                file_put_contents($args['file'], $r['content']);
                echo 'crawl '.$args ['file']." success\n";
                sleep(mt_rand(5,20));
            }
            flush();
        }
    }