<?php
    use Ares333\CurlMulti\Core;

    class Spider_itjuzi{
        public $curl;
        public $cache_dir;

        public function __construct(){
            $this->curl = new Core();
            
            $class = explode('_', __CLASS__);
            $dir = end($class);

            $this->cache_dir = CACHE_PATH.'/'.$dir.'/';
            if(! file_exists( $this->cache_dir)) {
                mkdir($this->cache_dir);
            }
        }

        //项目数据抓取
        public function project(){
            $this->curl->maxThread = 3;

            $cache = $this->cache_dir.__FUNCTION__.'/';
            if(! file_exists( $cache )) {
                mkdir($cache);
            }

            $url = 'http://www.itjuzi.com/company/';
            for($i = 1; $i <= 40000; $i ++) {
                $ip = mt_rand(101,120).'.'.mt_rand(50,250).'.'.mt_rand(10,250).'.'.mt_rand(10,250);
                
                $this->curl->add ( array (
                        'url' => $url . $i,
                        'opt' => array (
                            CURLOPT_HEADER => false,
                            CURLOPT_HTTPHEADER => array('X-FORWARDED-FOR:'.$ip.'','CLIENT-IP:'.$ip.''),
                            CURLOPT_USERAGENT => 'Mozilla/5.0 (compatible; Baiduspider/2.0; +http://www.baidu.com/search/spider.html)',
                            CURLOPT_RETURNTRANSFER => true,
                            CURLOPT_SSL_VERIFYPEER => false
                        ),
                        'args' => array (
                                'file' => $cache.$i.'.html'
                        )
                ), array($this,'cbProcess'));
            }

            $this->curl->start ();
        }

        //国内投资事件抓取
        public function investevents(){
            $this->curl->maxThread = 1;

            $cache = $this->cache_dir.__FUNCTION__.'/';
            if(! file_exists( $cache )) {
                mkdir($cache);
            }

            $url = 'https://www.itjuzi.com/investevents?page=';
            for($i = 1; $i <= 1400; $i ++) {
                $ip = mt_rand(101,120).'.'.mt_rand(50,250).'.'.mt_rand(10,250).'.'.mt_rand(10,250);
                
                $this->curl->add ( array (
                        'url' => $url . $i,
                        'opt' => array (
                            CURLOPT_HEADER => false,
                            CURLOPT_HTTPHEADER => array('X-FORWARDED-FOR:'.$ip.'','CLIENT-IP:'.$ip.''),
                            CURLOPT_USERAGENT => 'Mozilla/5.0 (compatible; Baiduspider/2.0; +http://www.baidu.com/search/spider.html)',
                            CURLOPT_RETURNTRANSFER => true,
                            CURLOPT_SSL_VERIFYPEER => false
                        ),
                        'args' => array (
                                'file' => $cache.$i.'.html'
                        )
                ), array($this,'listProcess'));
            }

            $this->curl->start ();
        } 

        //国内并购事件抓取
        public function merger(){
            $this->curl->maxThread = 1;

            $cache = $this->cache_dir.__FUNCTION__.'/';
            if(! file_exists( $cache )) {
                mkdir($cache);
            }

            $url = 'https://www.itjuzi.com/merger?page=';
            for($i = 1; $i <= 100; $i ++) {
                $ip = mt_rand(101,120).'.'.mt_rand(50,250).'.'.mt_rand(10,250).'.'.mt_rand(10,250);
                
                $this->curl->add ( array (
                        'url' => $url . $i,
                        'opt' => array (
                            CURLOPT_HEADER => false,
                            CURLOPT_HTTPHEADER => array('X-FORWARDED-FOR:'.$ip.'','CLIENT-IP:'.$ip.''),
                            CURLOPT_USERAGENT => 'Mozilla/5.0 (compatible; Baiduspider/2.0; +http://www.baidu.com/search/spider.html)',
                            CURLOPT_RETURNTRANSFER => true,
                            CURLOPT_SSL_VERIFYPEER => false
                        ),
                        'args' => array (
                                'file' => $cache.$i.'.html'
                        )
                ), array($this,'listProcess'));
            }

            $this->curl->start ();
        }

        //国外融资事件抓取
        public function investevents_foreign(){
            $this->curl->maxThread = 1;

            $cache = $this->cache_dir.__FUNCTION__.'/';
            if(! file_exists( $cache )) {
                mkdir($cache);
            }

            $url = 'https://www.itjuzi.com/investevents/foreign?page=';
            for($i = 1; $i <= 400; $i ++) {
                $ip = mt_rand(101,120).'.'.mt_rand(50,250).'.'.mt_rand(10,250).'.'.mt_rand(10,250);
                
                $this->curl->add ( array (
                        'url' => $url . $i,
                        'opt' => array (
                            CURLOPT_HEADER => false,
                            CURLOPT_HTTPHEADER => array('X-FORWARDED-FOR:'.$ip.'','CLIENT-IP:'.$ip.''),
                            CURLOPT_USERAGENT => 'Mozilla/5.0 (compatible; Baiduspider/2.0; +http://www.baidu.com/search/spider.html)',
                            CURLOPT_RETURNTRANSFER => true,
                            CURLOPT_SSL_VERIFYPEER => false
                        ),
                        'args' => array (
                                'file' => $cache.$i.'.html'
                        )
                ), array($this,'listProcess'));
            }

            $this->curl->start ();
        }

        //国外并购事件抓取
        public function merger_foreign(){
            $this->curl->maxThread = 1;

            $cache = $this->cache_dir.__FUNCTION__.'/';
            if(! file_exists( $cache )) {
                mkdir($cache);
            }

            $url = 'https://www.itjuzi.com/merger/foreign?page=';
            for($i = 1; $i <= 60; $i ++) {
                $ip = mt_rand(101,120).'.'.mt_rand(50,250).'.'.mt_rand(10,250).'.'.mt_rand(10,250);
                
                $this->curl->add ( array (
                        'url' => $url . $i,
                        'opt' => array (
                            CURLOPT_HEADER => false,
                            CURLOPT_HTTPHEADER => array('X-FORWARDED-FOR:'.$ip.'','CLIENT-IP:'.$ip.''),
                            CURLOPT_USERAGENT => 'Mozilla/5.0 (compatible; Baiduspider/2.0; +http://www.baidu.com/search/spider.html)',
                            CURLOPT_RETURNTRANSFER => true,
                            CURLOPT_SSL_VERIFYPEER => false
                        ),
                        'args' => array (
                                'file' => $cache.$i.'.html'
                        )
                ), array($this,'listProcess'));
            }

            $this->curl->start ();
        }

        public function cbProcess($r, $args) {
            if($r['info']['http_code'] != 404){
                file_put_contents($args['file'], $r['content']);
                echo 'crawl '.$args ['file']." success\n";
                sleep(mt_rand(60,180));
            }else{
                echo "Not Found \n";
            }
            flush();
        }

        public function listProcess($r, $args) {
            if($r['info']['http_code'] != 404){
                file_put_contents($args['file'], $r['content']);
                echo 'crawl '.$args ['file']." success\n";
                sleep(mt_rand(1,3));
            }else{
                echo "Not Found \n";
            }
            flush();
        }
    }