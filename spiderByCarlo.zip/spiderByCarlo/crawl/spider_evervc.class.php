<?php
    use Ares333\CurlMulti\Core;

    class Spider_evervc{
        public $db;
        public $curl;
        public $cache_dir;

        public function __construct(){
            $this->curl = new Core();
            
            $class = explode('_', __CLASS__);
            $dir = end($class);

            $this->cache_dir = CACHE_PATH.'/'.$dir.'/';
            if(! file_exists( $this->cache_dir)) {
                mkdir($this->cache_dir);
            }

            $this->db = new PDO('mysql:dbname=evervc_project;host=127.0.0.1','root','root');
            $this->db->exec("set names utf8");
        }

        

        //投资事件抓取
        public function invest(){
            $this->curl->maxThread = 1;

            $cache = $this->cache_dir.__FUNCTION__.'/';
            if(! file_exists( $cache )) {
                mkdir($cache);
            }

            $res = $this->db->query("SELECT * FROM invest_list WHERE pid=0 ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);

            $url = 'http://www.evervc.com/events?cates=';
            foreach($res as $re){
                $ip = mt_rand(101,120).'.'.mt_rand(50,250).'.'.mt_rand(10,250).'.'.mt_rand(10,250);
                
                $this->curl->add ( array (
                        'url' => $url . $re['cate_id'],
                        'opt' => array (
                            CURLOPT_HEADER => false,
                            CURLOPT_HTTPHEADER => array('X-FORWARDED-FOR:'.$ip.'','CLIENT-IP:'.$ip.''),
                            CURLOPT_USERAGENT => 'Mozilla/5.0 (compatible; Baiduspider/2.0; +http://www.baidu.com/search/spider.html)',
                            CURLOPT_RETURNTRANSFER => true,
                            CURLOPT_SSL_VERIFYPEER => false
                        ),
                        'args' => array (
                            'cache' => $cache,
                            'id' => $re['cate_id'],
                            'file' => $cache.$re['cate_id'].'.html'
                        )
                ), array($this,'pageProcess'));
            }

            $this->curl->start ();
        } 

        public function pageProcess($r, $args) {
            if($r['info']['http_code'] != 404){
                echo 'crawl '.$args ['file']." success\n";

                $dom = phpQuery::newDocumentHTML($r['content']);
                $total = trim(pq($dom['div.data-main-tit'])->find('h3 em')->text());
                $total = trim(mb_substr($total, 1, mb_strpos($total, '个')));
                $total = str_replace(',', '', $total);
                $page = ceil(intval($total)/20);

                $this->db->exec("UPDATE invest_list SET page=".$page.",update_time='".date('Y-m-d H:i:s')."' WHERE cate_id=".$args['id']);
                echo $page;
                echo "\r\n";

                for($i=1;$i <= $page; $i++){
                    $ip = mt_rand(101,120).'.'.mt_rand(50,250).'.'.mt_rand(10,250).'.'.mt_rand(10,250);
                    $this->curl->add ( array (
                        'url' => 'http://www.evervc.com/events?page='.$i.'&cates='.$args['id'],
                        'opt' => array (
                            CURLOPT_HEADER => false,
                            CURLOPT_HTTPHEADER => array('X-FORWARDED-FOR:'.$ip.'','CLIENT-IP:'.$ip.''),
                            CURLOPT_USERAGENT => 'Mozilla/5.0 (compatible; Baiduspider/2.0; +http://www.baidu.com/search/spider.html)',
                            CURLOPT_RETURNTRANSFER => true,
                            CURLOPT_SSL_VERIFYPEER => false
                        ),
                        'args' => array (
                            'file' => $args['cache'].$args['id'].'_'.$i.'.html'
                        )
                    ), array($this,'listProcess'));
                }
            }else{
                echo "Not Found \n";
            }
            flush();
        }

        public function listProcess($r, $args) {
            if($r['info']['http_code'] != 404){
                file_put_contents($args['file'], $r['content']);
                echo 'crawl '.$args ['file']." success\n";
            }else{
                echo "Not Found \n";
            }
            flush();
        }
    }