<?php
    use Ares333\CurlMulti\Core;

    class Spider_ping{
        public $curl;

        public function __construct(){
            $this->curl = new Core();
        }

        public function ping(){
            $db=new PDO('mysql:dbname=nuts_tool;host=127.0.0.1','root','root');
            $db->exec("set names utf8");

            $this->curl->maxThread = 10;
            
            $id = 0;
            $res = $db->query("SELECT id,url FROM company_project WHERE id>".$id." AND status=1 ORDER BY id ASC LIMIT 500")->fetchAll(PDO::FETCH_ASSOC);

            while(count($res) > 0) {
                while(count($res) > 0) {
                    $r = array_shift($res);
                    if(empty($r['url'])) continue;

                    $this->curl->add ( array (
                            'url' => $r['url'],
                            'opt' => array (
                                CURLOPT_HEADER => false,
                                CURLOPT_USERAGENT => userAgent(),
                                CURLOPT_RETURNTRANSFER => true,
                                CURLOPT_NOBODY => 1,
                                CURLOPT_FOLLOWLOCATION => 0,
                                CURLOPT_TIMECONDITION => 20,
                                CURLOPT_TIMEOUT => 40,
                                CURLOPT_SSL_VERIFYPEER => false
                            ),
                            'args' => array (
                                'id' => $r['id'],
                                'url' => $r['url'],
                                'db' => $db
                            )
                    ), array($this,'cbProcess'),array($this, 'faildProcess'));
                }

                $this->curl->start ();

                $id = $r['id'];
                $res = $db->query("SELECT id,url FROM company_project WHERE id>".$id." AND status=1 ORDER BY id ASC LIMIT 500")->fetchAll(PDO::FETCH_ASSOC);
            }
        }

        public function cbProcess($r, $args) {
            echo $args ['id'] ."   ".$r['info']['http_code']."\n";
            if(isset($r['info']['http_code']) && in_array($r['info']['http_code'], array(200,301,302))){
                echo "ping success\n";
            }else{
                $sql = "UPDATE company_project SET status = 0 WHERE id=".$args ['id'];
                $args ['db']->exec($sql);
                echo "ping faild\n";
            }
        }

        public function faildProcess($r,$args){
            $sql = "UPDATE company_project SET status = 0 WHERE id=".$args ['id'];
            $args ['db']->exec($sql);
            echo $args ['id'] ."   ping faild\n";
        }
    }