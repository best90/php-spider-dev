<?php
    use Ares333\CurlMulti\Core;

    class Spider_app111{
        public $db;
        public $curl;
        public $cache_dir;

        public function __construct(){
            $this->curl = new Core();
            
            $class = explode('_', __CLASS__);
            $dir = end($class);

            $this->cache_dir = CACHE_PATH.'/'.$dir.'/';
            if(! file_exists( $this->cache_dir)) {
                mkdir($this->cache_dir);
            }

            $this->db = new PDO('mysql:dbname=app;host=127.0.0.1','root','root');
            $this->db->exec("set names utf8");
        }

        //APP 列表抓取
        public function search(){
            $this->curl->maxThread = 3;

            $cache = $this->cache_dir.__FUNCTION__.'/';
            if(! file_exists( $cache )) {
                mkdir($cache);
            }

            $url = 'http://www.app111.com/all/1-0-0-0-0-0-0-0-1-';
            for($i = 1; $i <= 4353; $i ++) {
                $ip = mt_rand(101,120).'.'.mt_rand(50,250).'.'.mt_rand(10,250).'.'.mt_rand(10,250);
                
                $this->curl->add ( array (
                        'url' => $url . $i.'/',
                        'opt' => array (
                            CURLOPT_HEADER => false,
                            CURLOPT_HTTPHEADER => array('X-FORWARDED-FOR:'.$ip.'','CLIENT-IP:'.$ip.''),
                            CURLOPT_USERAGENT => 'Mozilla/5.0 (compatible; Baiduspider/2.0; +http://www.baidu.com/search/spider.html)',
                            CURLOPT_RETURNTRANSFER => true,
                            CURLOPT_SSL_VERIFYPEER => false
                        ),
                        'args' => array (
                                'file' => $cache.$i.'.html'
                        )
                ), array($this,'cbProcess'));
            }
            $this->curl->start ();
        }

        //APP 详情抓取
        public function info(){
            $this->curl->maxThread = 10;

            $cache = $this->cache_dir.__FUNCTION__.'/';
            if(! file_exists( $cache )) {
                mkdir($cache);
            }

            $res = $this->db->query("SELECT * FROM app111_search_list WHERE status=0 ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);
            
            foreach ($res as $re) {
                $ip = mt_rand(101,120).'.'.mt_rand(50,250).'.'.mt_rand(10,250).'.'.mt_rand(10,250);
                
                $this->curl->add ( array (
                        'url' => $re['url'],
                        'opt' => array (
                            CURLOPT_HEADER => false,
                            CURLOPT_HTTPHEADER => array('X-FORWARDED-FOR:'.$ip.'','CLIENT-IP:'.$ip.''),
                            CURLOPT_USERAGENT => 'Mozilla/5.0 (compatible; Baiduspider/2.0; +http://www.baidu.com/search/spider.html)',
                            CURLOPT_RETURNTRANSFER => true,
                            CURLOPT_SSL_VERIFYPEER => false
                        ),
                        'args' => array (
                                'id' => $re['id'],    
                                'file' => $cache.$re['id'].'.html'
                        )
                ), array($this,'infoProcess'));
            }
            $this->curl->start ();
        }

        //APP 厂商抓取
        public function devinfo(){
            $this->curl->maxThread = 10;

            $cache = $this->cache_dir.__FUNCTION__.'/';
            if(! file_exists( $cache )) {
                mkdir($cache);
            }

            $res = $this->db->query("SELECT id,devinfo FROM app111_info_list WHERE status=0 ORDER BY id ASC LIMIT 100")->fetchAll(PDO::FETCH_ASSOC);
            
            while (count($res) > 0) {
                while (count($res) > 0) {
                    $re = array_shift($res);
                    $ip = mt_rand(101,120).'.'.mt_rand(50,250).'.'.mt_rand(10,250).'.'.mt_rand(10,250);
                    
                    if(empty($re['devinfo'])){
                        $this->db->exec("UPDATE app111_info_list SET status=1,update_time='".date('Y-m-d H:i:s')."' WHERE id=".$re['id']);
                        continue;
                    }

                    $this->curl->add ( array (
                            'url' => $re['devinfo'],
                            'opt' => array (
                                CURLOPT_HEADER => false,
                                CURLOPT_HTTPHEADER => array('X-FORWARDED-FOR:'.$ip.'','CLIENT-IP:'.$ip.''),
                                CURLOPT_USERAGENT => 'Mozilla/5.0 (compatible; Baiduspider/2.0; +http://www.baidu.com/search/spider.html)',
                                CURLOPT_RETURNTRANSFER => true,
                                CURLOPT_SSL_VERIFYPEER => false
                            ),
                            'args' => array (
                                    'id' => $re['id'],    
                                    'file' => $cache.$re['id'].'.html'
                            )
                    ), array($this,'devinfoProcess'));
                }

                $this->curl->start ();

                $res = $this->db->query("SELECT id,devinfo FROM app111_info_list WHERE status=0 ORDER BY id ASC LIMIT 100")->fetchAll(PDO::FETCH_ASSOC);
            }      
        }

        //APP 厂商分页抓取
        public function dev_list(){
            $this->curl->maxThread = 10;

            $cache = $this->cache_dir.__FUNCTION__.'/';
            if(! file_exists( $cache )) {
                mkdir($cache);
            }

            $res = $this->db->query("SELECT * FROM app111_devinfo_list WHERE status=0 ORDER BY id ASC LIMIT 100")->fetchAll(PDO::FETCH_ASSOC);

            while (count($res) > 0) {
                while (count($res) > 0) {
                    $re = array_shift($res);
                    $ip = mt_rand(101,120).'.'.mt_rand(50,250).'.'.mt_rand(10,250).'.'.mt_rand(10,250);

                    if(empty($re['url'])){
                        $this->db->exec("UPDATE app111_devinfo_list SET status=2,update_time='".date('Y-m-d H:i:s')."' WHERE id=".$re['id']);
                        continue;
                    }

                    $this->curl->add ( array (
                        'url' => $re['url'],
                        'opt' => array (
                            CURLOPT_HEADER => false,
                            CURLOPT_HTTPHEADER => array('X-FORWARDED-FOR:'.$ip.'','CLIENT-IP:'.$ip.''),
                            CURLOPT_USERAGENT => 'Mozilla/5.0 (compatible; Baiduspider/2.0; +http://www.baidu.com/search/spider.html)',
                            CURLOPT_RETURNTRANSFER => true,
                            CURLOPT_SSL_VERIFYPEER => false
                        ),
                        'args' => array (
                            'id' => $re['id'],
                            'file' => $cache.$re['id'].'.html'
                        )
                    ), array($this,'devlistProcess'));
                }

                $this->curl->start ();

                $res = $this->db->query("SELECT * FROM app111_devinfo_list WHERE status=0 ORDER BY id ASC LIMIT 100")->fetchAll(PDO::FETCH_ASSOC);
            }
        }

        public function cbProcess($r, $args) {
            if($r['info']['http_code'] != 404){
                file_put_contents($args['file'], $r['content']);
                echo 'crawl '.$args ['file']." success\n";
                sleep(1);
            }else{
                echo "Not Found \n";
            }
            flush();
        }

        public function infoProcess($r, $args) {
            if($r['info']['http_code'] != 404){
                file_put_contents($args['file'], $r['content']);
                echo 'crawl '.$args ['file']." success\n";

                $this->db->exec("UPDATE app111_search_list SET status=1,update_time='".date('Y-m-d H:i:s')."' WHERE id=".$args['id']);
                sleep(1);
            }else{
                echo "Not Found \n";
            }
            flush();
        }

        public function devinfoProcess($r, $args) {
            if($r['info']['http_code'] != 404){
                file_put_contents($args['file'], $r['content']);
                echo 'crawl '.$args ['file']." success\n";

                $this->db->exec("UPDATE app111_info_list SET status=1,update_time='".date('Y-m-d H:i:s')."' WHERE id=".$args['id']);
                sleep(1);
            }else{
                echo "Not Found \n";
            }
            flush();
        }

        public function devlistProcess($r, $args){
            if($r['info']['http_code'] != 404){
                file_put_contents($args['file'], $r['content']);
                echo 'crawl '.$args ['file']." success\n";

                $this->db->exec("UPDATE app111_devinfo_list SET status=1,update_time='".date('Y-m-d H:i:s')."' WHERE id=".$args['id']);
                sleep(1);
            }else{
                echo "Not Found \n";
            }
            flush();
        }
    }