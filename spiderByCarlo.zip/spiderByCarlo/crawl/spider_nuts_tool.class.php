<?php
    use Ares333\CurlMulti\Core;

    class Spider_nuts_tool{
        public $curl;

        public function __construct(){
            $this->curl = new Core();
        }

        //项目logo
        public function icon(){
            $db=new PDO('mysql:dbname=nuts_tool;host=127.0.0.1','root','root');
            $db->exec("set names utf8");

            $this->curl->maxThread = 1;

            $cache = CACHE_PATH.'/nuts_tool/icon/';
            if (! file_exists( $cache )) {
                mkdir($cache);
            }
            
            $id = 1200;
            $res = $db->query("SELECT id,icon FROM company_project WHERE id>".$id." ORDER BY id ASC LIMIT 500")->fetchAll(PDO::FETCH_ASSOC);

            while(count($res) > 0) {
                while(count($res) > 0) {
                    $r = array_shift($res);
                    if(empty($r['icon'])) continue;

                    $dirname = substr($r['id'], -4);
                    $sub_dir = $cache.$dirname.'/';
                    if (! file_exists( $sub_dir)) {
                        mkdir($sub_dir);
                    }

                    $file = $sub_dir.$r['id'].'.png';
                    $this->curl->add ( array (
                            'url' => $r['icon'],
                            'opt' => array (
                                CURLOPT_HEADER => false,
                                CURLOPT_USERAGENT => userAgent(),
                                CURLOPT_RETURNTRANSFER => true,
                                CURLOPT_FOLLOWLOCATION => 0,
                                CURLOPT_TIMECONDITION => 60,
                                CURLOPT_TIMEOUT => 120,
                                CURLOPT_SSL_VERIFYPEER => false
                            ),
                            'args' => array (
                                'file' => $file
                            )
                    ), array($this,'cbProcess'));
                }

                $this->curl->start ();

                $id = $r['id'];
                $res = $db->query("SELECT id,icon FROM company_project WHERE id>".$id." ORDER BY id ASC LIMIT 500")->fetchAll(PDO::FETCH_ASSOC);
            }
        }

        //项目详情图
        public function main_pic(){
            $db=new PDO('mysql:dbname=nuts_tool;host=127.0.0.1','root','root');
            $db->exec("set names utf8");

            $this->curl->maxThread = 1;

            $cache = CACHE_PATH.'/nuts_tool/main_pic/';
            if (! file_exists( $cache )) {
                mkdir($cache);
            }
            
            $id = 0;
            $res = $db->query("SELECT id,main_pic FROM company_project WHERE id>".$id." ORDER BY id ASC LIMIT 500")->fetchAll(PDO::FETCH_ASSOC);

            while(count($res) > 0) {
                while(count($res) > 0) {
                    $r = array_shift($res);
                    if(empty($r['main_pic'])) continue;

                    $dirname = substr($r['id'], -4);
                    $sub_dir = $cache.$dirname.'/';
                    if (! file_exists( $sub_dir)) {
                        mkdir($sub_dir);
                    }

                    $pic_list = explode(',', $r['main_pic']);
                    foreach ($pic_list as $k => $pic) {
                        $file = $sub_dir.$r['id'].'_'.$k.'.jpg';
                        $this->curl->add ( array (
                                'url' => $r['main_pic'],
                                'opt' => array (
                                    CURLOPT_HEADER => false,
                                    CURLOPT_USERAGENT => userAgent(),
                                    CURLOPT_RETURNTRANSFER => true,
                                    CURLOPT_FOLLOWLOCATION => 0,
                                    CURLOPT_TIMECONDITION => 60,
                                    CURLOPT_TIMEOUT => 120,
                                    CURLOPT_SSL_VERIFYPEER => false
                                ),
                                'args' => array (
                                    'file' => $file
                                )
                        ), array($this,'cbProcess'));
                    }
                }

                $this->curl->start ();

                $id = $r['id'];
                $res = $db->query("SELECT id,main_pic FROM company_project WHERE id>".$id." ORDER BY id ASC LIMIT 500")->fetchAll(PDO::FETCH_ASSOC);
            }
        }

        //团队成员头像
        public function avatar(){
            $db=new PDO('mysql:dbname=nuts_tool;host=127.0.0.1','root','root');
            $db->exec("set names utf8");

            $this->curl->maxThread = 1;

            $cache = CACHE_PATH.'/nuts_tool/avatar/';
            if (! file_exists( $cache )) {
                mkdir($cache);
            }
            
            $id = 0;
            $res = $db->query("SELECT id,usericon FROM company_team WHERE id>".$id." ORDER BY id ASC LIMIT 500")->fetchAll(PDO::FETCH_ASSOC);

            while(count($res) > 0) {
                while(count($res) > 0) {
                    $r = array_shift($res);
                    if(empty($r['usericon'])) continue;

                    $dirname = substr($r['id'], -4);
                    $sub_dir = $cache.$dirname.'/';
                    if (! file_exists( $sub_dir)) {
                        mkdir($sub_dir);
                    }

                    $file = $sub_dir.$r['id'].'.png';
                    $this->curl->add ( array (
                            'url' => $r['usericon'],
                            'opt' => array (
                                CURLOPT_HEADER => false,
                                CURLOPT_USERAGENT => userAgent(),
                                CURLOPT_RETURNTRANSFER => true,
                                CURLOPT_FOLLOWLOCATION => 0,
                                CURLOPT_TIMECONDITION => 60,
                                CURLOPT_TIMEOUT => 120,
                                CURLOPT_SSL_VERIFYPEER => false
                            ),
                            'args' => array (
                                'file' => $file
                            )
                    ), array($this,'cbProcess'));
                }

                $this->curl->start ();

                $id = $r['id'];
                $res = $db->query("SELECT id,usericon FROM company_team WHERE id>".$id." ORDER BY id ASC LIMIT 500")->fetchAll(PDO::FETCH_ASSOC);
            }
        }

        public function cbProcess($r, $args) {
            file_put_contents($args['file'], $r['content']);
            echo $args ['file'] . " finished\n";
            flush();
        }
    }