

# nutstool-spider

## deploy

- install docker
- execute ./docker.run.sh <entrypoint>
```bash
./docker.run.sh /bin/bash
```

## TODO

- move the cache & temp folder outside the project.
- config switcher to switch production and local db config.