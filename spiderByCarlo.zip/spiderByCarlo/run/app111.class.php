<?php
    class App111{
        public $db;
        public function __construct(){
            $this->db = new PDO('mysql:dbname=app;host=127.0.0.1','root','root');
            $this->db->exec("set names utf8");
        }

        //搜索列表页处理
        public function search(){
            $cache = CACHE_PATH . '/app111/search/';

            $sql = "INSERT INTO app111_search_list(url,update_time) VALUES(:url,:utime) ON DUPLICATE KEY UPDATE update_time=VALUES(update_time)";
            $st = $this->db->prepare($sql);

            for($i = 1; $i <= 4353; $i ++) {
                $file = $cache.$i.'.html';
                if(!file_exists($file)) continue;

                $html = toUtf8(read($file));
                $list = $this->getSearchList($html);

                $date = date('Y-m-d H:i:s');
                foreach ($list as $li) {
                    $st->bindParam(':url',$li);
                    $st->bindParam(':utime',$date);

                    $st->execute();
                    echo "Id : ".$this->db->lastInsertId()."\r\n";
                }
            }
        }

        //详情页处理
        public function info(){
            $cache = CACHE_PATH . '/app111/info/';

            $sql = "INSERT INTO app111_info_list(app_name,icon,intro,score,dev,devinfo,update_time) VALUES(:app,:icon,:intro,:score,:dev,:devinfo,:utime)";
            $st = $this->db->prepare($sql);

            $res = $this->db->query("SELECT * FROM app111_search_list WHERE status = 1")->fetchAll(PDO::FETCH_ASSOC);
            
            foreach ($res as $re) {
                $file = $cache.$re['id'].'.html';
                if(!file_exists($file)) continue;

                $html = toUtf8(read($file));
                $info = $this->getAppInfo($html);

                $date = date('Y-m-d H:i:s');
                $st->bindParam(':app',$info['app_name']);
                $st->bindParam(':icon',$info['icon']);
                $st->bindParam(':intro',$info['intro']);
                //$st->bindParam(':ios',$info['ios_url']);
                $st->bindParam(':score',$info['score']);
                $st->bindParam(':dev',$info['dev']);
                $st->bindParam(':devinfo',$info['devinfo']);
                $st->bindParam(':utime',$date);

                $st->execute();
                echo "Id : ".$this->db->lastInsertId()."\r\n";

                $this->db->exec("UPDATE app111_search_list SET status=2 WHERE id=".$re['id']);
            }
        }

        //厂商大全页面处理
        public function devinfo(){
            $cache = CACHE_PATH . '/app111/devinfo/';

            $sql = "INSERT INTO app111_dev_app(app_name,icon,url,intro,type,dev,info_list_dev,update_time) VALUES(:app,:icon,:url,:intro,:type,:dev,:idev,:utime) ON DUPLICATE KEY UPDATE update_time=VALUES(update_time)";
            $st = $this->db->prepare($sql);

            $dev_sql = "INSERT INTO app111_dev_info(dev,info_list_dev,logo,intro,update_time) VALUES(:dev,:idev,:logo,:intro,:utime) ON DUPLICATE KEY UPDATE update_time=VALUES(update_time)";
            $dev_st = $this->db->prepare($dev_sql);
            
            $list_sql = "INSERT INTO app111_devinfo_list(url,info_list_dev) VALUES(:url,:idev) ON DUPLICATE KEY UPDATE info_list_dev=VALUES(info_list_dev)";
            $list_st = $this->db->prepare($list_sql);

            $res = $this->db->query("SELECT * FROM app111_info_list WHERE status = 1")->fetchAll(PDO::FETCH_ASSOC);

            foreach ($res as $re) {
                $file = $cache.$re['id'].'.html';
                if(!file_exists($file)) continue;

                $html = toUtf8(read($file));
                $info = $this->getDevAppInfo($html);

                $date = date('Y-m-d H:i:s');

                if($info['app']){
                    foreach ($info['app'] as $in){
                        $st->bindParam(':app',$in['app_name']);
                        $st->bindParam(':icon',$in['icon']);
                        $st->bindParam(':url',$in['url']);
                        $st->bindParam(':intro',$in['intro']);
                        $st->bindParam(':type',$in['type']['cate']);
                        $st->bindParam(':dev',$info['dev']);
                        $st->bindParam(':idev',$re['dev']);
                        $st->bindParam(':utime',$date);

                        $st->execute();
                        echo "Id : ".$this->db->lastInsertId()."\r\n";
                    }
                }

                $dev_st->bindParam(':dev',$info['dev']);
                $dev_st->bindParam(':idev',$re['dev']);
                $dev_st->bindParam(':logo',$info['logo']);
                $dev_st->bindParam(':intro',$info['intro']);
                $dev_st->bindParam(':utime',$date);

                $dev_st->execute();
                echo "DEV_INFO Id : ".$this->db->lastInsertId()."\r\n";

                if(isset($info['next_page'])){
                    $list_st->bindParam(':url',$info['next_page']);
                    $list_st->bindParam(':idev',$re['dev']);

                    $list_st->execute();
                    echo "DEVINFO_LIST Id : ".$this->db->lastInsertId()."\r\n";
                }

                $this->db->exec("UPDATE app111_info_list SET status=2 WHERE id=".$re['id']);
            }
        }

        //厂商大全分页处理
        public function dev_list(){
            $cache = CACHE_PATH . '/app111/dev_list/';

            $sql = "INSERT INTO app111_dev_app(app_name,icon,url,intro,type,dev,info_list_dev,update_time) VALUES(:app,:icon,:url,:intro,:type,:dev,:idev,:utime) ON DUPLICATE KEY UPDATE update_time=VALUES(update_time)";
            $st = $this->db->prepare($sql);

            $list_sql = "INSERT INTO app111_devinfo_list(url,info_list_dev) VALUES(:url,:idev) ON DUPLICATE KEY UPDATE info_list_dev=VALUES(info_list_dev)";
            $list_st = $this->db->prepare($list_sql);

            $res = $this->db->query("SELECT * FROM app111_devinfo_list WHERE status = 1")->fetchAll(PDO::FETCH_ASSOC);

            while (count($res) > 0){
                while (count($res) > 0) {
                    $re = array_shift($res);

                    $file = $cache.$re['id'].'.html';
                    if(!file_exists($file)){
                        $this->db->exec("UPDATE app111_devinfo_list SET status=1 WHERE id=".$re['id']);
                        continue;
                    }

                    $html = toUtf8(read($file));
                    $info = $this->getDevAppInfo($html);

                    $date = date('Y-m-d H:i:s');

                    if($info['app']){
                        foreach ($info['app'] as $in){
                            $st->bindParam(':app',$in['app_name']);
                            $st->bindParam(':icon',$in['icon']);
                            $st->bindParam(':url',$in['url']);
                            $st->bindParam(':intro',$in['intro']);
                            $st->bindParam(':type',$in['type']['cate']);
                            $st->bindParam(':dev',$info['dev']);
                            $st->bindParam(':idev',$re['info_list_dev']);
                            $st->bindParam(':utime',$date);

                            $st->execute();
                            echo "APP Id : ".$this->db->lastInsertId()."\r\n";
                        }
                    }

                    if(isset($info['next_page'])){
                        $list_st->bindParam(':url',$info['next_page']);
                        $list_st->bindParam(':idev',$re['info_list_dev']);

                        $list_st->execute();
                        echo "DEVINFO_LIST Id : ".$this->db->lastInsertId()."\r\n";
                    }

                    $this->db->exec("UPDATE app111_devinfo_list SET status=2 WHERE id=".$re['id']);
                }
                $res = $this->db->query("SELECT * FROM app111_devinfo_list WHERE status = 1")->fetchAll(PDO::FETCH_ASSOC);
                sleep(10);
            }

        }

        //提取search url list信息
        private function getSearchList($html){
            $info = array();
            $dom = phpQuery::newDocumentHTML($html);

            $list = $dom['#main_list_ul li div.list_box_top'];
            foreach ($list as $li) {
                $info[] = trim(pq($li)->find('h2 a')->attr('href'));
            }

            $dom -> unloadDocument();
            return $info;
        }

        //提取详情页信息
        private function getAppInfo($html){
            $info = array();
            $dom = phpQuery::newDocumentHTML($html);

            $info['app_name'] = trim(pq($dom['div.title h1 a'])->text());
            $info['icon'] = trim(pq($dom['div.logo a img'])->attr('src'));
            $info['intro'] = trim(pq($dom['div.summary span.text'])->text());
            $info['intro'] = str_replace('简介：','', $info['intro']);

            $info['score'] = trim(pq($dom['div.score .num'])->text());
            $info['dev'] = trim(pq($dom['p.factory i a'])->attr('title'));
            $info['devinfo'] = trim(pq($dom['p.factory i a'])->attr('href'));

            $dom -> unloadDocument();
            return $info;
        }

        /**提取APP厂商页面信息
         * @param string $html
         * @return array
         */
        private function getDevAppInfo($html){
            $info = [];
            $dom = phpQuery::newDocumentHTML($html);

            $info['dev'] = trim(pq($dom['.car_introduce .car_introduce_2'])->text());
            $info['logo'] = trim(pq($dom['.car_introduce .car_introduce_1 img'])->attr('src'));
            $info['intro'] = trim(pq($dom['.car_introduce .car_introduce_3'])->text());

            $info['app'] = [];
            $list = $dom['.car_leftcon2_con ul li'];
            foreach ($list as $k => $li) {
                $info['app'][$k]['app_name'] = trim(pq($li)->find('.car_con2_font1_1 b a')->attr('title'));
                $info['app'][$k]['icon'] = trim(pq($li)->find('.car_con1_img1 a img')->attr('src'));

                $url_str    = trim(pq($li)->find('.car_con2_1 .car_img1 a')->attr('href'));
                $url_str = mb_substr($url_str, mb_strpos($url_str,"Statistics('")+12, (mb_strpos($url_str,"');")-mb_strpos($url_str,'Statistics(')-3));
                $toArr = explode("','",$url_str);

                $info['app'][$k]['url'] = $toArr[1];
                $info['app'][$k]['intro'] = trim(pq($li)->find('.car_con2_1 p')->text());
                $type = trim(pq($li)->find('.car_con2_font1_1 .span_name1')->text());
                $type = explode("\r\n",$type);
                $info['app'][$k]['type']['cate'] = trim($type[0]);
                $info['app'][$k]['type']['other'] = trim($type[1]);
            }

            $page = trim(pq($dom['.app_page a:last'])->attr('href'));
            if($page) $info['next_page'] = $page;

            $dom -> unloadDocument();
            return $info;
        }
    }