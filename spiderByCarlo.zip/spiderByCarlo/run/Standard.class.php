<?php
    require_once(ROOT_PATH . '/nuts_lib/location.class.php');
    require_once(ROOT_PATH . '/nuts_lib/stage.class.php');
    require_once(ROOT_PATH . '/nuts_lib/currency.class.php');

    class Standard{
        public function run(){
            $target_db = $this->databaseObj('standard');
            
            //IT桔子
            $this->standardITjuzi($target_db, 'itjuzi_project','itjuzi_project','*');
            
            //36kr
            $this->standard36kr($target_db, '36kr_project','36kr_project','*');
            
            //拉勾网
            $this->standardLagou($target_db, 'lagou_project', 'lagou_project', '*');

            //创业邦
            $this->standardCyzone($target_db, 'cyzone_project', 'cyzone_project', '*');

            //天天投
            $this->standardEvervc($target_db, 'evervc_project', 'evervc_project', '*');

            //天使汇
            $this->standardAngel($target_db, 'angel_project', 'angel_project', '*');

            //虎嗅网
            $this->standardHuxiu($target_db, 'other_project', 'huxiu_project', '*');

            //猎云网
            $this->standardLieyun($target_db, 'other_project', 'lieyun_project', '*');
        }

        public function debug(){
            $target_db = $this->databaseObj('standard');
            $this->standardVc($target_db, 'vc_project', 'vc_project', '*');
        }

/*
 * --------------------------------------------分割线------------------------------------------------------
 * 相关处理方法
 */
    
        public function standardITjuzi($target_db, $dbname, $table, $field, $type = PDO::FETCH_ASSOC){
            $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field,'',$type);

            $sql = "INSERT INTO itjuzi(_source,_creator,name,logo,brief,intro,industry,tag,fund_status,image,video,introduction,location,url,product,social_network,company,founder,team,funding,funding_history,milestone,news,_undefined,create_time,update_time) VALUES(:sou,:cre,:nam,:log,:bri,:intro,:ind,:tag,:fun,:ima,:vid,:introduct,:loc,:url,:pro,:soc,:com,:fou,:tea,:fund,:funding,:mil,:news,:und,:create_t,:update_t) ON DUPLICATE KEY UPDATE _source=VALUES(_source),_creator=VALUES(_creator),name=VALUES(name),logo=VALUES(logo),brief=VALUES(brief),intro=VALUES(intro),industry=VALUES(industry),tag=VALUES(tag),fund_status=VALUES(fund_status),image=VALUES(image),video=VALUES(video),introduction=VALUES(introduction),location=VALUES(location),url=VALUES(url),product=VALUES(product),social_network=VALUES(social_network),company=VALUES(company),founder=VALUES(founder),team=VALUES(team),funding=VALUES(funding),funding_history=VALUES(funding_history),milestone=VALUES(milestone),news=VALUES(news),_undefined=VALUES(_undefined),create_time=VALUES(create_time),update_time=VALUES(update_time)";
            $st = $target_db->prepare($sql);

            foreach ($data as $d) {
                $row['_source'] = array(
                        'pkid' => $d['id'],
                        'htmlid' => $d['project_html_id'],
                    );
                $row['_creator'] = array();
                $row['name'] = $d['project_name'];
                $row['logo'] = $d['logo'];
                $row['brief'] = NULL;
                $row['intro'] = $d['intro'];
                $row['industry'] = $d['industry'];
                $row['tag'] = $d['tags'] ? explode(',',$d['tags']) : array();
                $row['fund_status'] = $d['stage'] ? Stage::toStageId($d['stage']) : 0;
                $row['image'] = !empty($d['picshow_url']) ? explode(',',$d['picshow_url']) : array();
                $row['video'] = array();
                $row['introduction'] = array();

                //$local = $d['location'] ? explode('·',$d['location']) : array();
                $row['location'] = array(
                        //'country' => Location::string2CountryId($local),
                        //'province' => Location::string2ProvinceId($local),
                        //'city' => Location::string2CityId($local),
                        'local' => $d['location'],
                    );

                $row['url'] = array();
                if($d['url']) $row['url'][] = array('type' => 'web','url' => $d['url']);
                
                $row['product'] = array();
                
                $products = json_decode($d['product'], true);
                foreach ($products as $k => $p) {
                    $row['product'][$k]['name'] = $p['name'];
                    $row['product'][$k]['typeName'] = $p['type'];
                    $row['product'][$k]['url'] = $p['url'];
                    $row['product'][$k]['intro'] = $p['info'];   
                }

                $row['social_network'] = array();
                $row['company'] = empty($d['company']) ? NULL : array($d['company']);
                $row['founder'] = array();

                $row['team'] = array();
                $members = array();
                $team = json_decode($d['team'], true);
                foreach ($team as $k => $t) {
                    $members[$k]['name'] = $t['name'];
                    $members[$k]['title'] = $t['position'];
                    $members[$k]['avatar'] = $t['usericon'];
                    $members[$k]['intro'] = $t['resume'];
                    $members[$k]['social_network'][0] = array(
                            'type' => 'weibo',
                            'url' => $t['weibo'],
                        );
                }
                if($members) $row['team']['member'] = $members;
                $row['funding'] = array();

                $financing = array();
                $funding = json_decode($d['funding'],true);
                foreach ($funding as $k => $f) {
                    $financing[$k]['date'] = $this->string2Date($f['date']);
                    $financing[$k]['stage_id']= Stage::toStageId($f['round']);
                    $financing[$k]['stage'] = $f['round'];
                    $financing[$k]['money'] = $f['finades'];
                    $financing[$k]['investor'] = explode('、',$f['investors']);
                }
                $row['funding_history'] = $financing;

                $row['milestone'] = array();
                $milestone = json_decode($d['milestone'],true);
                foreach ($milestone as $k => $m) {
                    $row['milestone'][$k]['title'] = $m['event'];
                    $row['milestone'][$k]['date'] = $this->string2Date($m['date']); 
                }

                $row['news'] = array();
                $news = json_decode($d['news'],true);
                foreach ($news as $k => $n) {
                    $row['news'][$k]['title'] = $n['title'];
                    $row['news'][$k]['type'] = $n['type'];
                    $row['news'][$k]['url'] = $n['url'];
                    $row['news'][$k]['date'] = $this->string2Date($n['date']);
                    $row['news'][$k]['source'] = $n['source'];
                }

                $row['_undefined'] = array();
                if(!empty($d['status'])) $row['_undefined']['status'] = $d['status'];
                if(!empty($d['email'])) $row['_undefined']['email'] = $d['email'];
                if(!empty($d['phone'])) $row['_undefined']['phone'] = $d['phone'];
                if(!empty($d['address'])) $row['_undefined']['address'] = $d['address'];
                
                $row['create_time'] = $d['update_time'];
                $row['update_time'] = date('Y-m-d H:i:s');

                foreach ($row as $key => $value) {
                    if(is_array($value)) $row[$key] = json_encode($value);
                    if(empty($value) && $value !== 0) $row[$key] = NULL;
                }

                $st->bindParam(':sou',$row['_source']);
                $st->bindParam(':cre',$row['_creator']);
                $st->bindParam(':nam',$row['name']);
                $st->bindParam(':log',$row['logo']);
                $st->bindParam(':bri',$row['brief']);
                $st->bindParam(':intro',$row['intro']);
                $st->bindParam(':ind',$row['industry']);
                $st->bindParam(':tag',$row['tag']);
                $st->bindParam(':fun',$row['fund_status']);
                $st->bindParam(':ima',$row['image']);
                $st->bindParam(':vid',$row['video']);
                $st->bindParam(':introduct',$row['introduction']);
                $st->bindParam(':loc',$row['location']);
                $st->bindParam(':url',$row['url']);
                $st->bindParam(':pro',$row['product']);
                $st->bindParam(':soc',$row['social_network']);
                $st->bindParam(':com',$row['company']);
                $st->bindParam(':fou',$row['founder']);
                $st->bindParam(':tea',$row['team']);
                $st->bindParam(':fund',$row['funding']);
                $st->bindParam(':funding',$row['funding_history']);
                $st->bindParam(':mil',$row['milestone']);
                $st->bindParam(':news',$row['news']);
                $st->bindParam(':und',$row['_undefined']);
                $st->bindParam(':create_t',$row['create_time']);
                $st->bindParam(':update_t',$row['update_time']);

                $st->execute(); 
                echo "Id : ".$target_db->lastInsertId()."\r\n";
            }

            echo "===============\r\n";
        }

        public function standard36kr($target_db, $dbname, $table, $field, $type = PDO::FETCH_ASSOC){
            $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field,'',$type);

            $sql = "INSERT INTO 36kr(_source,_creator,name,logo,brief,intro,industry,tag,fund_status,image,video,introduction,location,url,product,social_network,company,founder,team,funding,funding_history,milestone,news,_undefined,create_time,update_time) VALUES(:sou,:cre,:nam,:log,:bri,:intro,:ind,:tag,:fun,:ima,:vid,:introduct,:loc,:url,:pro,:soc,:com,:fou,:tea,:fund,:funding,:mil,:news,:und,:create_t,:update_t) ON DUPLICATE KEY UPDATE _source=VALUES(_source),_creator=VALUES(_creator),name=VALUES(name),logo=VALUES(logo),brief=VALUES(brief),intro=VALUES(intro),industry=VALUES(industry),tag=VALUES(tag),fund_status=VALUES(fund_status),image=VALUES(image),video=VALUES(video),introduction=VALUES(introduction),location=VALUES(location),url=VALUES(url),product=VALUES(product),social_network=VALUES(social_network),company=VALUES(company),founder=VALUES(founder),team=VALUES(team),funding=VALUES(funding),funding_history=VALUES(funding_history),milestone=VALUES(milestone),news=VALUES(news),_undefined=VALUES(_undefined),create_time=VALUES(create_time),update_time=VALUES(update_time)";
            $st = $target_db->prepare($sql);

            foreach ($data as $d) {
                $row['_source'] = array(
                        'pkid' => $d['id'],
                        'htmlid' => $d['project_html_id'],
                    );
                $row['_creator'] = array();
                $row['name'] = $d['project_name'];
                $row['logo'] = $d['logo'];
                $row['brief'] = !empty($d['brief']) ? $d['brief'] : NULL;
                $row['intro'] = $d['intro'];
                $row['industry'] = $d['industry'];
                $row['tag'] = $d['tags'] ? explode(',',$d['tags']) : array();
                $row['image'] = !empty($d['pictures']) ? explode(',',$d['pictures']) : array();
                $row['video'] = array();
                $row['introduction'] = array();
                if(!empty($d['advantage'])) $row['introduction']['advantage'] = $d['advantage'];
                if(!empty($d['data_light'])) $row['introduction']['highlights'] = $d['data_light'];
                if(!empty($d['story'])) $row['introduction']['story'] = $d['story'];


                //$local = $d['location'] ? explode('·',$d['location']) : array();
                $local = $d['address1'].'·'.$d['address2'].'·'.$d['address3'];
                $local = trim($local,'·');

                $row['location'] = array(
                        //'country' => Location::string2CountryId($local),
                        //'province' => Location::string2ProvinceId($local),
                        //'city' => Location::string2CityId($local),
                        'local' => $local,
                    );

                $row['url'] = array();
                if(!empty($d['website'])) {
                    $url = array('type' => 'web','url' => $d['website']);
                    $row['url'][] = $url;
                }
                if(!empty($d['iphone'])){
                    $iphone = array('type' => 'iphone','url' => $d['iphone']);
                    $row['url'][] = $iphone;
                }
                if(!empty($d['ipad'])){
                    $ipad = array('type' => 'ipad','url' => $d['ipad']);
                    $row['url'][] = $ipad;
                } 
                if(!empty($d['android'])){
                    $android = array('type' => 'android','url' => $d['android']);
                    $row['url'][]= $android;
                }              
                
                $row['product'] = array();
                $row['social_network'] = array();
                if(!empty($d['weixin'])){
                    $weixin = array('type' => 'weixin','account' => $d['weixin']);
                    $row['social_network'][] = $weixin;
                }
                if(!empty($d['weibo'])){
                    $weibo = array('type' => 'weibo','url' => $d['weibo']);
                    $row['social_network'][] = $weibo;
                }

                $row['company'] = array();
                $company = json_decode($d['company_info'],true);
                if($company){
                    $row['company'][] = $company['Name']; 
                }

                $row['founder'] = array();
                $founder = json_decode($d['founder'],true);
                if(!empty($founder)){
                    $founder_arr = array();
                    foreach ($founder as $k => $f) {
                        $founder_arr[$k]['name'] = $f['name'];
                        $founder_arr[$k]['title'] = $f['type'];
                        $founder_arr[$k]['avatar'] = $f['avatar'];
                        $founder_arr[$k]['intro'] = $f['intro'];
                    }

                    $row['founder']['member'] = $founder_arr;
                }

                $row['team'] = array();
                $members = array();
                $team = json_decode($d['team'], true);
                foreach ($team as $k => $t) {
                    $members[$k]['name'] = $t['name'];
                    $members[$k]['avatar'] = $t['avatar'];
                    $members[$k]['intro'] = $t['intro'];
                }
                if(!empty($members)) $row['team']['member'] = $members;
                $row['funding'] = array();

                $financing = array();
                $funding = json_decode($d['funding'],true);
                foreach ($funding as $k => $f) {
                    $financing[$k]['date'] = $f['date'];
                    $financing[$k]['stage_id']= Stage::toStageId($f['stage']);
                    $financing[$k]['stage'] = $f['stage'];
                    $financing[$k]['money'] = $f['amount'];
                    $financing[$k]['investor'] = explode('、',$f['investors']);
                }
                $row['fund_status'] = isset($financing[0]['stage_id']) ? $financing[0]['stage_id'] : 0;
                $row['funding_history'] = $financing;

                $row['milestone'] = array();

                $row['news'] = array();
                $news = json_decode($d['news'],true);
                foreach ($news as $k => $n) {
                    $row['news'][$k]['title'] = $n['title'];
                    $row['news'][$k]['type'] = $n['type'];
                    $row['news'][$k]['date'] = $n['date'];
                }

                $row['_undefined'] = array();
                if(!empty($d['com_type'])) $row['_undefined']['com_type'] = $d['com_type'];

                $former_member = json_decode($d['former_member'],true);
                if(!empty($former_member)){
                    $former = array();
                    foreach ($former_member as $k => $fm) {
                        $former[$k]['name'] = $fm['name'];
                        $former[$k]['title'] = $fm['position'];
                        $former[$k]['avatar'] = $fm['avatar'];
                        $former[$k]['intro'] = $fm['intro'];
                    }
                    if($former) $row['_undefined']['former_member'] = array('member' => $former);
                }
                
                $row['create_time'] = $d['update_time'];
                $row['update_time'] = date('Y-m-d H:i:s');

                foreach ($row as $key => $value) {
                    if(is_array($value)) $row[$key] = json_encode($value);
                    if(empty($value) && $value !== 0) $row[$key] = NULL;
                }

                $st->bindParam(':sou',$row['_source']);
                $st->bindParam(':cre',$row['_creator']);
                $st->bindParam(':nam',$row['name']);
                $st->bindParam(':log',$row['logo']);
                $st->bindParam(':bri',$row['brief']);
                $st->bindParam(':intro',$row['intro']);
                $st->bindParam(':ind',$row['industry']);
                $st->bindParam(':tag',$row['tag']);
                $st->bindParam(':fun',$row['fund_status']);
                $st->bindParam(':ima',$row['image']);
                $st->bindParam(':vid',$row['video']);
                $st->bindParam(':introduct',$row['introduction']);
                $st->bindParam(':loc',$row['location']);
                $st->bindParam(':url',$row['url']);
                $st->bindParam(':pro',$row['product']);
                $st->bindParam(':soc',$row['social_network']);
                $st->bindParam(':com',$row['company']);
                $st->bindParam(':fou',$row['founder']);
                $st->bindParam(':tea',$row['team']);
                $st->bindParam(':fund',$row['funding']);
                $st->bindParam(':funding',$row['funding_history']);
                $st->bindParam(':mil',$row['milestone']);
                $st->bindParam(':news',$row['news']);
                $st->bindParam(':und',$row['_undefined']);
                $st->bindParam(':create_t',$row['create_time']);
                $st->bindParam(':update_t',$row['update_time']);

                $st->execute(); 
                echo "Id : ".$target_db->lastInsertId()."\r\n";
            }

            echo "===============\r\n";
        }

        public function standardLagou($target_db, $dbname, $table, $field, $type = PDO::FETCH_ASSOC){
            $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field,'',$type);

            $sql = "INSERT INTO lagou(_source,_creator,name,logo,brief,intro,industry,tag,fund_status,image,video,introduction,location,url,product,social_network,company,founder,team,funding,funding_history,milestone,news,_undefined,create_time,update_time) VALUES(:sou,:cre,:nam,:log,:bri,:intro,:ind,:tag,:fun,:ima,:vid,:introduct,:loc,:url,:pro,:soc,:com,:fou,:tea,:fund,:funding,:mil,:news,:und,:create_t,:update_t) ON DUPLICATE KEY UPDATE _source=VALUES(_source),_creator=VALUES(_creator),name=VALUES(name),logo=VALUES(logo),brief=VALUES(brief),intro=VALUES(intro),industry=VALUES(industry),tag=VALUES(tag),fund_status=VALUES(fund_status),image=VALUES(image),video=VALUES(video),introduction=VALUES(introduction),location=VALUES(location),url=VALUES(url),product=VALUES(product),social_network=VALUES(social_network),company=VALUES(company),founder=VALUES(founder),team=VALUES(team),funding=VALUES(funding),funding_history=VALUES(funding_history),milestone=VALUES(milestone),news=VALUES(news),_undefined=VALUES(_undefined),create_time=VALUES(create_time),update_time=VALUES(update_time)";
            $st = $target_db->prepare($sql);

            foreach ($data as $d) {
                if(empty($d['project_name'])) continue;

                $row['_source'] = array(
                        'pkid' => $d['id'],
                        'htmlid' => $d['project_html_id'],
                    );
                $row['_creator'] = array();
                $row['name'] = $d['project_name'];
                $row['logo'] = $d['logo'];
                $row['brief'] = $d['intro'];
                $row['intro'] = NULL;
                $row['industry'] = $d['industry'];
                $row['tag'] = $d['industry'] ? explode(',',$d['industry']) : array();
                $row['fund_status'] = $d['stage'] ? Stage::toStageId($d['stage']) : 0;
                $row['image'] = NULL;
                $row['video'] = array();
                $row['introduction'] = array();

                //$local = $d['location'] ? explode('·',$d['location']) : array();
                $row['location'] = array(
                        //'country' => Location::string2CountryId($local),
                        //'province' => Location::string2ProvinceId($local),
                        //'city' => Location::string2CityId($local),
                        'local' => $d['location'],
                    );

                $row['url'] = array();
                if($d['url']){
                    $row['url'][] = array(
                            'type' => 'web',
                            'url' => $d['url'],
                        );
                }
                
                $row['product'] = array();
                
                $products = json_decode($d['product'], true);
                foreach ($products as $k => $p) {
                    $row['product'][$k]['name'] = $p['product_name'];
                    $row['product'][$k]['typeName'] = isset($p['type']) ? $p['type'] : NULL;
                    $row['product'][$k]['url'] = $p['product_url'];
                    $row['product'][$k]['intro'] = $p['intro'];   
                }

                $row['social_network'] = array();
                $row['company'] = array();
                if($d['company']) $row['company'][] = $d['company'];

                $row['founder'] = array();

                $row['team'] = array();
                $members = array();
                $team = json_decode($d['team'], true);
                foreach ($team as $k => $t) {
                    $members[$k]['name'] = $t['name'];
                    $members[$k]['title'] = $t['job'];
                    $members[$k]['avatar'] = $t['photo'];
                    $members[$k]['intro'] = $t['info'];
                    if($t['weibo']) $members[$k]['social_network'][] = array('type' => 'weibo','url' => $t['weibo']);
                }
                if($d['scale']) $row['team']['scale'] = $d['scale'];
                if($members) $row['team']['member'] = $members;
                
                $row['funding'] = array();
                $row['funding_history'] = array();

                $row['milestone'] = array();
                $milestone = json_decode($d['milestone'],true);
                if(!empty($milestone)){
                    foreach ($milestone as $k => $m) {
                        $row['milestone'][$k]['title'] = $m['title'];
                        $row['milestone'][$k]['type'] = $m['type'];
                        if($m['desc']) $row['milestone'][$k]['desc'] = $m['desc'];
                        $row['milestone'][$k]['date'] = $m['time']; 
                    }
                }

                $row['news'] = array();

                $row['_undefined'] = array();
                if(!empty($d['company_info'])) $row['_undefined']['company_intro'] = $d['company_info'];

                $com_img = json_decode($d['company_img'],true);
                if(!empty($com_img)) $row['_undefined']['company_image'] = $com_img;

                $address = json_decode($d['address'],true);
                if(!empty($address)) $row['_undefined']['address'] = $address;
                
                $row['create_time'] = $d['update_time'];
                $row['update_time'] = date('Y-m-d H:i:s');

                foreach ($row as $key => $value) {
                    if(is_array($value)) $row[$key] = json_encode($value);
                    if(empty($value) && $value !== 0) $row[$key] = NULL;
                }

                $st->bindParam(':sou',$row['_source']);
                $st->bindParam(':cre',$row['_creator']);
                $st->bindParam(':nam',$row['name']);
                $st->bindParam(':log',$row['logo']);
                $st->bindParam(':bri',$row['brief']);
                $st->bindParam(':intro',$row['intro']);
                $st->bindParam(':ind',$row['industry']);
                $st->bindParam(':tag',$row['tag']);
                $st->bindParam(':fun',$row['fund_status']);
                $st->bindParam(':ima',$row['image']);
                $st->bindParam(':vid',$row['video']);
                $st->bindParam(':introduct',$row['introduction']);
                $st->bindParam(':loc',$row['location']);
                $st->bindParam(':url',$row['url']);
                $st->bindParam(':pro',$row['product']);
                $st->bindParam(':soc',$row['social_network']);
                $st->bindParam(':com',$row['company']);
                $st->bindParam(':fou',$row['founder']);
                $st->bindParam(':tea',$row['team']);
                $st->bindParam(':fund',$row['funding']);
                $st->bindParam(':funding',$row['funding_history']);
                $st->bindParam(':mil',$row['milestone']);
                $st->bindParam(':news',$row['news']);
                $st->bindParam(':und',$row['_undefined']);
                $st->bindParam(':create_t',$row['create_time']);
                $st->bindParam(':update_t',$row['update_time']);

                $st->execute(); 
                echo "Id : ".$target_db->lastInsertId()."\r\n";
            }

            echo "===============\r\n";
        }

        public function standardCyzone($target_db, $dbname, $table, $field, $type = PDO::FETCH_ASSOC){
            $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field,'',$type);

            $sql = "INSERT INTO cyzone(_source,_creator,name,logo,brief,intro,industry,tag,fund_status,image,video,introduction,location,url,product,social_network,company,founder,team,funding,funding_history,milestone,news,_undefined,create_time,update_time) VALUES(:sou,:cre,:nam,:log,:bri,:intro,:ind,:tag,:fun,:ima,:vid,:introduct,:loc,:url,:pro,:soc,:com,:fou,:tea,:fund,:funding,:mil,:news,:und,:create_t,:update_t) ON DUPLICATE KEY UPDATE _source=VALUES(_source),_creator=VALUES(_creator),name=VALUES(name),logo=VALUES(logo),brief=VALUES(brief),intro=VALUES(intro),industry=VALUES(industry),tag=VALUES(tag),fund_status=VALUES(fund_status),image=VALUES(image),video=VALUES(video),introduction=VALUES(introduction),location=VALUES(location),url=VALUES(url),product=VALUES(product),social_network=VALUES(social_network),company=VALUES(company),founder=VALUES(founder),team=VALUES(team),funding=VALUES(funding),funding_history=VALUES(funding_history),milestone=VALUES(milestone),news=VALUES(news),_undefined=VALUES(_undefined),create_time=VALUES(create_time),update_time=VALUES(update_time)";
            $st = $target_db->prepare($sql);

            foreach ($data as $d) {
                $row['_source'] = array(
                        'pkid' => $d['id'],
                        'htmlid' => $d['project_html_id'],
                    );
                $row['_creator'] = array();
                $row['name'] = $d['project_name'];
                $row['logo'] = $d['icon'];
                $row['brief'] = NULL;
                $row['intro'] = $d['intro'];
                $row['industry'] = $d['industry'];
                $row['tag'] = $d['industry'] ? explode(',',$d['industry']) : array();
                $row['fund_status'] = $d['financing_stage'] ? Stage::toStageId($d['financing_stage']) : 0;
                $row['image'] = !empty($d['info_img']) ? explode(',',$d['info_img']) : array();
                $row['video'] = array();
                $row['introduction'] = array();

                //$local = $d['location'] ? explode('·',$d['location']) : array();
                $row['location'] = array(
                        //'country' => Location::string2CountryId($local),
                        //'province' => Location::string2ProvinceId($local),
                        //'city' => Location::string2CityId($local),
                        'local' => $d['location'],
                    );

                $row['url'] = array();
                if($d['url']) $row['url'][] = array('type' => 'web','url' => $d['url']);
                
                $row['product'] = array();
                $row['social_network'] = array();
                $row['company'] = empty($d['company_name']) ? NULL : array($d['company_name']);
                $row['founder'] = array();

                $row['team'] = array();
                
                $team = json_decode($d['team'], true);
                if(!empty($team)){
                    $members = array();
                    foreach ($team as $k => $t) {
                        $members[$k]['name'] = $t['name'];
                        $members[$k]['title'] = $t['job'];
                        $members[$k]['avatar'] = $t['img'];
                        $members[$k]['url'] = $t['url'];
                    }
                    $row['team']['member'] = $members;
                }
                
                $row['funding'] = array();

                $financing = array();
                $funding = json_decode($d['financing'],true);
                if(!empty($funding)){
                    foreach ($funding as $k => $f) {
                        $financing[$k]['date'] = str_replace('-','.',$f['time']);
                        $financing[$k]['stage_id']= Stage::toStageId($f['stage']);
                        $financing[$k]['stage'] = $f['stage'];
                        $financing[$k]['money'] = $f['amount'];
                        $financing[$k]['investor'] = explode('、',$f['investors']);
                    }
                }
                $row['funding_history'] = $financing;

                $row['milestone'] = array();
                $milestone = json_decode($d['trends'],true);
                if(!empty($milestone)){
                    foreach ($milestone as $k => $m) {
                        $row['milestone'][$k]['title'] = $m['title'];
                        $row['milestone'][$k]['date'] = str_replace('.','-',$m['time']); 
                    }
                }
                
                $row['news'] = array();
                $news = json_decode($d['news'],true);
                if(!empty($news)){
                    foreach ($news as $k => $n) {
                        $row['news'][$k]['title'] = $n['title'];
                        $row['news'][$k]['url'] = $n['url'];
                        $row['news'][$k]['date'] = str_replace('.','-',$n['time']);
                    }
                }

                $row['_undefined'] = array();
                if(!empty($d['found_time'])) $row['_undefined']['found_time'] = $this->string2Date(trim($this->string2Date($d['found_time']),'.'));
                
                $row['create_time'] = $d['update_time'];
                $row['update_time'] = date('Y-m-d H:i:s');

                foreach ($row as $key => $value) {
                    if(is_array($value)) $row[$key] = json_encode($value);
                    if(empty($value) && $value !== 0) $row[$key] = NULL;
                }

                $st->bindParam(':sou',$row['_source']);
                $st->bindParam(':cre',$row['_creator']);
                $st->bindParam(':nam',$row['name']);
                $st->bindParam(':log',$row['logo']);
                $st->bindParam(':bri',$row['brief']);
                $st->bindParam(':intro',$row['intro']);
                $st->bindParam(':ind',$row['industry']);
                $st->bindParam(':tag',$row['tag']);
                $st->bindParam(':fun',$row['fund_status']);
                $st->bindParam(':ima',$row['image']);
                $st->bindParam(':vid',$row['video']);
                $st->bindParam(':introduct',$row['introduction']);
                $st->bindParam(':loc',$row['location']);
                $st->bindParam(':url',$row['url']);
                $st->bindParam(':pro',$row['product']);
                $st->bindParam(':soc',$row['social_network']);
                $st->bindParam(':com',$row['company']);
                $st->bindParam(':fou',$row['founder']);
                $st->bindParam(':tea',$row['team']);
                $st->bindParam(':fund',$row['funding']);
                $st->bindParam(':funding',$row['funding_history']);
                $st->bindParam(':mil',$row['milestone']);
                $st->bindParam(':news',$row['news']);
                $st->bindParam(':und',$row['_undefined']);
                $st->bindParam(':create_t',$row['create_time']);
                $st->bindParam(':update_t',$row['update_time']);

                $st->execute(); 
                echo "Id : ".$target_db->lastInsertId()."\r\n";
            }

            echo "===============\r\n";
        }

        public function standardEvervc($target_db, $dbname, $table, $field, $type = PDO::FETCH_ASSOC){
            $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field,'',$type);

            $sql = "INSERT INTO evervc(_source,_creator,name,logo,brief,intro,industry,tag,fund_status,image,video,introduction,location,url,product,social_network,company,founder,team,funding,funding_history,milestone,news,_undefined,create_time,update_time) VALUES(:sou,:cre,:nam,:log,:bri,:intro,:ind,:tag,:fun,:ima,:vid,:introduct,:loc,:url,:pro,:soc,:com,:fou,:tea,:fund,:funding,:mil,:news,:und,:create_t,:update_t) ON DUPLICATE KEY UPDATE _source=VALUES(_source),_creator=VALUES(_creator),name=VALUES(name),logo=VALUES(logo),brief=VALUES(brief),intro=VALUES(intro),industry=VALUES(industry),tag=VALUES(tag),fund_status=VALUES(fund_status),image=VALUES(image),video=VALUES(video),introduction=VALUES(introduction),location=VALUES(location),url=VALUES(url),product=VALUES(product),social_network=VALUES(social_network),company=VALUES(company),founder=VALUES(founder),team=VALUES(team),funding=VALUES(funding),funding_history=VALUES(funding_history),milestone=VALUES(milestone),news=VALUES(news),_undefined=VALUES(_undefined),create_time=VALUES(create_time),update_time=VALUES(update_time)";
            $st = $target_db->prepare($sql);

            foreach ($data as $d) {
                $row['_source'] = array(
                        'pkid' => $d['id'],
                        'htmlid' => $d['project_html_id'],
                    );
                $row['_creator'] = array();
                $row['name'] = $d['project_name'];
                $row['logo'] = $d['logo'];
                $row['brief'] = NULL;
                $row['intro'] = $d['intro'];
                $row['industry'] = $d['tags'];
                $row['tag'] = $d['tags'] ? explode(',',$d['tags']) : array();
                $row['fund_status'] = $d['stage'] ? Stage::toStageId($d['stage']) : 0;

                $pic = json_decode($d['pic'],true);
                $row['image'] = $pic ? $pic : array();
                $row['video'] = $d['video'] ? array($d['video']) : array();
                $row['introduction'] = array();

                //$local = $d['location'] ? explode('·',$d['location']) : array();
                $row['location'] = array(
                        //'country' => Location::string2CountryId($local),
                        //'province' => Location::string2ProvinceId($local),
                        //'city' => Location::string2CityId($local),
                        'local' => $d['location'],
                    );

                $row['url'] = array();
                if($d['url']) $row['url'][] = array('type' => 'web','url' => trim($d['url'],'/'));
                
                $row['product'] = array();
                $row['social_network'] = array();
                $row['company'] = $d['company'] ? array($d['company']) : NULL;
                $row['founder'] = array();

                $row['team'] = array();
                
                $team = json_decode($d['team'], true);
                if(!empty($team)){
                    $members = array();
                    foreach ($team as $k => $t) {
                        $members[$k]['name'] = $t['name'];
                        $members[$k]['title'] = $t['job'];
                        $members[$k]['avatar'] = $t['photo'];
                        $members[$k]['intro'] = $t['info'];
                    }
                    $row['team']['member'] = $members;
                }
                
                $row['funding'] = array();

                $financing = array();
                $funding = json_decode($d['funding'],true);
                if(!empty($funding)){
                    foreach ($funding as $k => $f) {
                        $financing[$k]['date'] = $f['date'];
                        $financing[$k]['stage_id']= Stage::toStageId($f['stage']);
                        $financing[$k]['stage'] = $f['stage'];
                        $financing[$k]['money'] = $f['amount'];
                        $financing[$k]['investor'] = explode('、',$f['investor']);
                    }
                }
                $row['funding_history'] = $financing;

                $row['milestone'] = array();
                $milestone = json_decode($d['milestone'],true);
                if(!empty($milestone)){
                    foreach ($milestone as $k => $m) {
                        $row['milestone'][$k]['title'] = $m['title'];
                        $row['milestone'][$k]['type'] = $m['type'];
                        $row['milestone'][$k]['date'] = $m['time']; 
                    }
                }
                
                $row['news'] = array();

                $row['_undefined'] = array();
                if($d['status']) $row['_undefined']['status'] = $d['status'];
                if($d['address']) $row['_undefined']['address'] = $d['address'];
                
                $row['create_time'] = $d['update_time'];
                $row['update_time'] = date('Y-m-d H:i:s');

                foreach ($row as $key => $value) {
                    if(is_array($value)) $row[$key] = json_encode($value);
                    if(empty($value) && $value !== 0) $row[$key] = NULL;
                }

                $st->bindParam(':sou',$row['_source']);
                $st->bindParam(':cre',$row['_creator']);
                $st->bindParam(':nam',$row['name']);
                $st->bindParam(':log',$row['logo']);
                $st->bindParam(':bri',$row['brief']);
                $st->bindParam(':intro',$row['intro']);
                $st->bindParam(':ind',$row['industry']);
                $st->bindParam(':tag',$row['tag']);
                $st->bindParam(':fun',$row['fund_status']);
                $st->bindParam(':ima',$row['image']);
                $st->bindParam(':vid',$row['video']);
                $st->bindParam(':introduct',$row['introduction']);
                $st->bindParam(':loc',$row['location']);
                $st->bindParam(':url',$row['url']);
                $st->bindParam(':pro',$row['product']);
                $st->bindParam(':soc',$row['social_network']);
                $st->bindParam(':com',$row['company']);
                $st->bindParam(':fou',$row['founder']);
                $st->bindParam(':tea',$row['team']);
                $st->bindParam(':fund',$row['funding']);
                $st->bindParam(':funding',$row['funding_history']);
                $st->bindParam(':mil',$row['milestone']);
                $st->bindParam(':news',$row['news']);
                $st->bindParam(':und',$row['_undefined']);
                $st->bindParam(':create_t',$row['create_time']);
                $st->bindParam(':update_t',$row['update_time']);

                $st->execute(); 
                echo "Id : ".$target_db->lastInsertId()."\r\n";
            }

            echo "===============\r\n";
        }

        public function standardAngel($target_db, $dbname, $table, $field, $type = PDO::FETCH_ASSOC){
            $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field,'',$type);

            $sql = "INSERT INTO angel(_source,_creator,name,logo,brief,intro,industry,tag,fund_status,image,video,introduction,location,url,product,social_network,company,founder,team,funding,funding_history,milestone,news,_undefined,create_time,update_time) VALUES(:sou,:cre,:nam,:log,:bri,:intro,:ind,:tag,:fun,:ima,:vid,:introduct,:loc,:url,:pro,:soc,:com,:fou,:tea,:fund,:funding,:mil,:news,:und,:create_t,:update_t) ON DUPLICATE KEY UPDATE _source=VALUES(_source),_creator=VALUES(_creator),name=VALUES(name),logo=VALUES(logo),brief=VALUES(brief),intro=VALUES(intro),industry=VALUES(industry),tag=VALUES(tag),fund_status=VALUES(fund_status),image=VALUES(image),video=VALUES(video),introduction=VALUES(introduction),location=VALUES(location),url=VALUES(url),product=VALUES(product),social_network=VALUES(social_network),company=VALUES(company),founder=VALUES(founder),team=VALUES(team),funding=VALUES(funding),funding_history=VALUES(funding_history),milestone=VALUES(milestone),news=VALUES(news),_undefined=VALUES(_undefined),create_time=VALUES(create_time),update_time=VALUES(update_time)";
            $st = $target_db->prepare($sql);

            foreach ($data as $d) {
                $row['_source'] = array(
                        'pkid' => $d['id'],
                        'htmlid' => $d['com_id'],
                    );
                $row['_creator'] = array();
                $row['name'] = $d['proj_name'];
                $row['logo'] = $d['logo_id'] ? 'http://fs.angelcrunch.com/IMG/'.$d['logo_id'] : NULL;
                $row['brief'] = NULL;
                $row['intro'] = $d['description'];
                $row['industry'] = str_replace(' · ',',',$d['industry']);
                $row['tag'] = $d['industry'] ? explode(' · ',$d['industry']) : array();
                $row['fund_status'] = 0;

                $row['image'] = array();
                $pic = json_decode($d['pic'],true);
                foreach ($pic as $p) {
                    $row['image'][] = 'http://fs.angelcrunch.com/IMG/'.$p['file_name'];
                }
                
                $row['video'] = array();
                $row['introduction'] = array();
                if($d['adg_other']) $row['introduction']['advantage'] = $d['adg_other'];
                if($d['biz_mode']) $row['introduction']['bussiness_mode'] = $d['biz_mode'];

                //$local = $d['location'] ? explode('·',$d['location']) : array();
                $local = $d['country'].'·'.$d['province'].'·'.$d['city'];
                $local = trim($local,'·');
                $row['location'] = array(
                        //'country' => Location::string2CountryId($local),
                        //'province' => Location::string2ProvinceId($local),
                        //'city' => Location::string2CityId($local),
                        'local' => $local,
                    );

                $row['url'] = array();
                if($d['url']) $row['url'][] = array('type' => 'web','url' => trim($d['url'],'/'));
                if($d['ios']) $row['url'][] = array('type' => 'ios','url' => $d['ios']);
                if($d['android']) $row['url'][] = array('type' => 'android','url' => $d['android']);
                if($d['bp']) $row['url'][] = array('type' => 'bp', 'url' => $d['bp']);

                $row['product'] = array();

                $row['social_network'] = array();
                if($d['weixin']) $row['social_network'][] = array('type' => 'weixin','account' => $d['weixin']);
                if($d['weibo'] && $d['weibo'] != 'http://') $row['social_network'][] = array('type' => 'weibo','url' => $d['weibo']);

                $row['company'] = empty($d['org_name']) ? NULL : array($d['org_name']);
                $row['founder'] = array();

                $row['team'] = array();
                $members = array();
                $team = json_decode($d['team'], true);
                foreach ($team as $k => $t) {
                    $members[$k]['name'] = $t['name'];
                    $members[$k]['title'] = $t['title'];
                    if($t['avatar']) $members[$k]['avatar'] = 'http://fs.angelcrunch.com/IMG/'.$t['avatar'];
                    $members[$k]['intro'] = $t['desc'];
                }
                if($members) $row['team']['member'] = $members;
                
                $row['funding'] = array();
                $row['funding_history'] = array();

                $row['milestone'] = array();
                $milestone = json_decode($d['milestone'],true);
                foreach ($milestone as $k => $m) {
                    $row['milestone'][$k]['title'] = $m['title'];
                    $row['milestone'][$k]['type'] = $m['type'];
                    $row['milestone'][$k]['date'] = $m['time']; 
                }

                $row['news'] = array();

                $row['_undefined'] = array();
                if(!empty($d['stage'])) $row['_undefined']['status'] = $d['stage'];
               
                
                $row['create_time'] = $d['update_time'];
                $row['update_time'] = date('Y-m-d H:i:s');

                foreach ($row as $key => $value) {
                    if(is_array($value)) $row[$key] = json_encode($value);
                    if(empty($value) && $value !== 0) $row[$key] = NULL;
                }

                $st->bindParam(':sou',$row['_source']);
                $st->bindParam(':cre',$row['_creator']);
                $st->bindParam(':nam',$row['name']);
                $st->bindParam(':log',$row['logo']);
                $st->bindParam(':bri',$row['brief']);
                $st->bindParam(':intro',$row['intro']);
                $st->bindParam(':ind',$row['industry']);
                $st->bindParam(':tag',$row['tag']);
                $st->bindParam(':fun',$row['fund_status']);
                $st->bindParam(':ima',$row['image']);
                $st->bindParam(':vid',$row['video']);
                $st->bindParam(':introduct',$row['introduction']);
                $st->bindParam(':loc',$row['location']);
                $st->bindParam(':url',$row['url']);
                $st->bindParam(':pro',$row['product']);
                $st->bindParam(':soc',$row['social_network']);
                $st->bindParam(':com',$row['company']);
                $st->bindParam(':fou',$row['founder']);
                $st->bindParam(':tea',$row['team']);
                $st->bindParam(':fund',$row['funding']);
                $st->bindParam(':funding',$row['funding_history']);
                $st->bindParam(':mil',$row['milestone']);
                $st->bindParam(':news',$row['news']);
                $st->bindParam(':und',$row['_undefined']);
                $st->bindParam(':create_t',$row['create_time']);
                $st->bindParam(':update_t',$row['update_time']);

                $st->execute(); 
                echo "Id : ".$target_db->lastInsertId()."\r\n";
            }

            echo "===============\r\n";
        }

        public function standardHuxiu($target_db, $dbname, $table, $field, $type = PDO::FETCH_ASSOC){
            $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field,'',$type);

            $sql = "INSERT INTO huxiu(_source,_creator,name,logo,brief,intro,industry,tag,fund_status,image,video,introduction,location,url,product,social_network,company,founder,team,funding,funding_history,milestone,news,_undefined,create_time,update_time) VALUES(:sou,:cre,:nam,:log,:bri,:intro,:ind,:tag,:fun,:ima,:vid,:introduct,:loc,:url,:pro,:soc,:com,:fou,:tea,:fund,:funding,:mil,:news,:und,:create_t,:update_t) ON DUPLICATE KEY UPDATE _source=VALUES(_source),_creator=VALUES(_creator),name=VALUES(name),logo=VALUES(logo),brief=VALUES(brief),intro=VALUES(intro),industry=VALUES(industry),tag=VALUES(tag),fund_status=VALUES(fund_status),image=VALUES(image),video=VALUES(video),introduction=VALUES(introduction),location=VALUES(location),url=VALUES(url),product=VALUES(product),social_network=VALUES(social_network),company=VALUES(company),founder=VALUES(founder),team=VALUES(team),funding=VALUES(funding),funding_history=VALUES(funding_history),milestone=VALUES(milestone),news=VALUES(news),_undefined=VALUES(_undefined),create_time=VALUES(create_time),update_time=VALUES(update_time)";
            $st = $target_db->prepare($sql);

            foreach ($data as $d) {
                $row['_source'] = array(
                        'pkid' => $d['id'],
                        'htmlid' => $d['project_html_id'],
                    );
                $row['_creator'] = array();
                $row['name'] = $d['project_name'];
                $row['logo'] = $d['icon'];
                $row['brief'] = $d['intro'];
                $row['intro'] = $d['intro_info'];
                $row['industry'] = $d['tag'];
                $row['tag'] = $d['tag'] ? explode(',',$d['tag']) : array();
                $row['fund_status'] = $d['financing_stage'] ? Stage::toStageId($d['financing_stage']) : 0;
                
                $row['image'] = array();
                $pic = json_decode($d['gallery_list'],true);
                if($pic) $row['image'] = $pic;

                $row['video'] = array();
                $row['introduction'] = array();
                if($d['advantage']) $row['introduction']['advantage'] = $d['advantage'];
                if($d['results']) $row['introduction']['performance'] = $d['results'];

                //$local = $d['location'] ? explode('·',$d['location']) : array();
                $local = str_replace(' ', '·', $d['location']);
                if($local == '暂无') $local = NULL;
                $row['location'] = array(
                        //'country' => Location::string2CountryId($local),
                        //'province' => Location::string2ProvinceId($local),
                        //'city' => Location::string2CityId($local),
                        'local' => $local,
                    );

                $row['url'] = array();
                if($d['url']) $row['url'][] = array('type' => 'web','url' => trim($d['url'],'/'));
                
                $row['product'] = array();

                $row['social_network'] = array();
                $row['company'] = empty($d['company_name']) ? NULL : array($d['company_name']);
                $row['founder'] = array();

                $row['team'] = array();
                if($d['member_num']) $row['team']['scale'] = $d['member_num'];

                $members = array();
                $team = json_decode($d['team'], true);
                if($team){
                    foreach ($team as $k => $t) {
                        $members[$k]['name'] = $t['name'];
                        if($t['position']) $members[$k]['title'] = $t['position'];
                        $members[$k]['intro'] = $t['intro'];
                    }
                    if($members) $row['team']['member'] = $members;
                }
                
                $row['funding'] = array();
                $row['funding_history'] = array();

                $financing = array();
                if($d['financing_stage']) $financing['stage_id']= Stage::toStageId($d['financing_stage']);
                if($d['financing_stage']) $financing['stage'] = $d['financing_stage'];
                if($d['amount']) $financing['money'] = $d['amount'];
                if($d['investors']) $financing['investor'] = explode('、',$d['investors']);
            
                if($financing) $row['funding_history'][] = $financing;

                $row['milestone'] = array();

                $row['news'] = array();
                $news = json_decode($d['news'],true);
                if($news){
                    foreach ($news as $k => $n) {
                        $row['news'][$k]['title'] = $n['title']; 
                        $row['news'][$k]['url'] = $n['url'];
                    }
                }
                

                $row['_undefined'] = array();
                if(!empty($d['status'])) $row['_undefined']['status'] = $d['status'];
                
                $row['create_time'] = $d['update_time'];
                $row['update_time'] = date('Y-m-d H:i:s');

                foreach ($row as $key => $value) {
                    if(is_array($value)) $row[$key] = json_encode($value);
                    if(empty($value) && $value !== 0) $row[$key] = NULL;
                }

                $st->bindParam(':sou',$row['_source']);
                $st->bindParam(':cre',$row['_creator']);
                $st->bindParam(':nam',$row['name']);
                $st->bindParam(':log',$row['logo']);
                $st->bindParam(':bri',$row['brief']);
                $st->bindParam(':intro',$row['intro']);
                $st->bindParam(':ind',$row['industry']);
                $st->bindParam(':tag',$row['tag']);
                $st->bindParam(':fun',$row['fund_status']);
                $st->bindParam(':ima',$row['image']);
                $st->bindParam(':vid',$row['video']);
                $st->bindParam(':introduct',$row['introduction']);
                $st->bindParam(':loc',$row['location']);
                $st->bindParam(':url',$row['url']);
                $st->bindParam(':pro',$row['product']);
                $st->bindParam(':soc',$row['social_network']);
                $st->bindParam(':com',$row['company']);
                $st->bindParam(':fou',$row['founder']);
                $st->bindParam(':tea',$row['team']);
                $st->bindParam(':fund',$row['funding']);
                $st->bindParam(':funding',$row['funding_history']);
                $st->bindParam(':mil',$row['milestone']);
                $st->bindParam(':news',$row['news']);
                $st->bindParam(':und',$row['_undefined']);
                $st->bindParam(':create_t',$row['create_time']);
                $st->bindParam(':update_t',$row['update_time']);

                $st->execute(); 
                echo "Id : ".$target_db->lastInsertId()."\r\n";
            }

            echo "===============\r\n";
        }

        public function standardLieyun($target_db, $dbname, $table, $field, $type = PDO::FETCH_ASSOC){
            $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field,'',$type);

            $sql = "INSERT INTO lieyun(_source,_creator,name,logo,brief,intro,industry,tag,fund_status,image,video,introduction,location,url,product,social_network,company,founder,team,funding,funding_history,milestone,news,_undefined,create_time,update_time) VALUES(:sou,:cre,:nam,:log,:bri,:intro,:ind,:tag,:fun,:ima,:vid,:introduct,:loc,:url,:pro,:soc,:com,:fou,:tea,:fund,:funding,:mil,:news,:und,:create_t,:update_t) ON DUPLICATE KEY UPDATE _source=VALUES(_source),_creator=VALUES(_creator),name=VALUES(name),logo=VALUES(logo),brief=VALUES(brief),intro=VALUES(intro),industry=VALUES(industry),tag=VALUES(tag),fund_status=VALUES(fund_status),image=VALUES(image),video=VALUES(video),introduction=VALUES(introduction),location=VALUES(location),url=VALUES(url),product=VALUES(product),social_network=VALUES(social_network),company=VALUES(company),founder=VALUES(founder),team=VALUES(team),funding=VALUES(funding),funding_history=VALUES(funding_history),milestone=VALUES(milestone),news=VALUES(news),_undefined=VALUES(_undefined),create_time=VALUES(create_time),update_time=VALUES(update_time)";
            $st = $target_db->prepare($sql);

            foreach ($data as $d) {
                $row['_source'] = array(
                        'pkid' => $d['id'],
                        'htmlid' => $d['pid'],
                    );
                $row['_creator'] = array();
                $row['name'] = $d['project_name'];
                $row['logo'] = $d['project_logo'] ? 'http://u.lieyunwang.com'.$d['project_logo'] : NULL;
                $row['brief'] = $d['intro'];
                $row['intro'] = $d['desc'] ? $d['desc'] : NULL;
                $row['industry'] = $d['domain_name'];
                $row['tag'] = $d['domain_name'] ? array($d['domain_name']) : array();
                $row['fund_status'] = 0;
                $row['image'] = array();
                $row['video'] = array();
                $row['introduction'] = array();
                if($d['project_highlight']) $row['introduction']['highlights'] = $d['project_highlight'];
                if($d['product_intro']) $row['introduction']['product_intro'] = $d['product_intro'];
                if($d['market_intro']) $row['introduction']['market'] = $d['market_intro'];
                if($d['bus_model']) $row['introduction']['bussiness_mode'] = $d['bus_model'];
                if($d['operate_data']) $row['introduction']['operate_data'] = $d['operate_data'];

                //$local = $d['location'] ? explode('·',$d['location']) : array();
                $row['location'] = array(
                        //'country' => Location::string2CountryId($local),
                        //'province' => Location::string2ProvinceId($local),
                        //'city' => Location::string2CityId($local),
                        'local' => $d['city_name'],
                    );

                $row['url'] = array();
                if($d['project_url']) $row['url'][] = array('type' => 'web','url' => trim($d['project_url'],'/'));
                if($d['ios_url']) $row['url'][] = array('type'=>'ios','url' => $d['ios_url']);
                if($d['android_url']) $row['url'][] = array('type'=>'android', 'url'=> $d['android_url']);
                if($d['bp']) $row['url'][] = array('type' => 'bp','url' => 'http://u.lieyunwang.com'.$d['bp']);

                $row['product'] = array();

                $row['social_network'] = array();
                $row['company'] = empty($d['company']) ? NULL : array($d['company']);
                $row['founder'] = array();

                $founder = array();
                if($d['creator_name']) $founder['name'] = $d['creator_name'];
                if($d['creator_email']) $founder['email']  = $d['creator_email'];
                if($d['creator_phone']) $founder['phone']  = $d['creator_phone'];
                if($d['creator_wechat']) $founder['social_network'][] = array('type'=>'weixin','account'=> $d['creator_wechat']);
                if($founder) $row['founder']['member'][] = $founder; 

                $row['team'] = array();
                if($d['team_desc']) $row['team']['intro'] = $d['team_desc'];
                if($d['team_highlight']) $row['team']['highlights'] = $d['team_highlight'];

                $row['funding'] = array();
                if($d['stage_name']) $row['funding']['stage_id'] = Stage::toStageId($d['stage_name']);
                if($d['stage_name']) $row['funding']['stage'] = $d['stage_name'];
                if($d['require_amount']) $row['funding']['money'] = $d['require_amount'];

                $financing = array();
                $row['funding_history'] = $financing;

                $row['milestone'] = array();
                
                $row['news'] = array();
                
                $row['_undefined'] = array();
                if(!empty($d['incubator'])) $row['_undefined']['incubator'] = $d['incubator'];
                
                $row['create_time'] = $d['update_time'];
                $row['update_time'] = date('Y-m-d H:i:s');

                foreach ($row as $key => $value) {
                    if(is_array($value)) $row[$key] = json_encode($value);
                    if(empty($value) && $value !== 0) $row[$key] = NULL;
                }

                $st->bindParam(':sou',$row['_source']);
                $st->bindParam(':cre',$row['_creator']);
                $st->bindParam(':nam',$row['name']);
                $st->bindParam(':log',$row['logo']);
                $st->bindParam(':bri',$row['brief']);
                $st->bindParam(':intro',$row['intro']);
                $st->bindParam(':ind',$row['industry']);
                $st->bindParam(':tag',$row['tag']);
                $st->bindParam(':fun',$row['fund_status']);
                $st->bindParam(':ima',$row['image']);
                $st->bindParam(':vid',$row['video']);
                $st->bindParam(':introduct',$row['introduction']);
                $st->bindParam(':loc',$row['location']);
                $st->bindParam(':url',$row['url']);
                $st->bindParam(':pro',$row['product']);
                $st->bindParam(':soc',$row['social_network']);
                $st->bindParam(':com',$row['company']);
                $st->bindParam(':fou',$row['founder']);
                $st->bindParam(':tea',$row['team']);
                $st->bindParam(':fund',$row['funding']);
                $st->bindParam(':funding',$row['funding_history']);
                $st->bindParam(':mil',$row['milestone']);
                $st->bindParam(':news',$row['news']);
                $st->bindParam(':und',$row['_undefined']);
                $st->bindParam(':create_t',$row['create_time']);
                $st->bindParam(':update_t',$row['update_time']);

                $st->execute(); 
                echo "Id : ".$target_db->lastInsertId()."\r\n";
            }
            echo "===============\r\n";
        }

        public function standardVc($target_db, $dbname, $table, $field, $type = PDO::FETCH_ASSOC){
            $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field,'',$type);

            $sql = "INSERT INTO vc(_source,_creator,name,logo,brief,intro,industry,tag,fund_status,image,video,introduction,location,url,product,social_network,company,founder,team,funding,funding_history,milestone,news,_undefined,create_time,update_time) VALUES(:sou,:cre,:nam,:log,:bri,:intro,:ind,:tag,:fun,:ima,:vid,:introduct,:loc,:url,:pro,:soc,:com,:fou,:tea,:fund,:funding,:mil,:news,:und,:create_t,:update_t) ON DUPLICATE KEY UPDATE _source=VALUES(_source),_creator=VALUES(_creator),name=VALUES(name),logo=VALUES(logo),brief=VALUES(brief),intro=VALUES(intro),industry=VALUES(industry),tag=VALUES(tag),fund_status=VALUES(fund_status),image=VALUES(image),video=VALUES(video),introduction=VALUES(introduction),location=VALUES(location),url=VALUES(url),product=VALUES(product),social_network=VALUES(social_network),company=VALUES(company),founder=VALUES(founder),team=VALUES(team),funding=VALUES(funding),funding_history=VALUES(funding_history),milestone=VALUES(milestone),news=VALUES(news),_undefined=VALUES(_undefined),create_time=VALUES(create_time),update_time=VALUES(update_time)";
            $st = $target_db->prepare($sql);

            foreach ($data as $d) {
                $row['_source'] = array(
                        'pkid' => $d['id'],
                        'htmlid' => $d['project_html_id'],
                    );
                $row['_creator'] = array();
                $row['name'] = $d['project_name'];
                $row['logo'] = $d['logo'];
                $row['brief'] = $d['intro'];
                $row['intro'] = $d['intro'];
                $row['industry'] = $d['industry'];
                $row['tag'] = $d['industry'] ? explode(',',$d['industry']) : array();
                $row['fund_status'] = $d['stage'] ? Stage::toStageId($d['stage']) : 0;
                
                $row['image'] = array();
                $pic = json_decode($d['pic'],true);
                if($pic) $row['image'] = $pic;

                $row['video'] = $d['video'] ? array($d['video']) :array();
                $row['introduction'] = array();
                if($d['highlight']) $row['introduction']['highlights'] = $d['highlight'];

                //$local = $d['location'] ? explode('·',$d['location']) : array();
                $local = str_replace(' ', '·', $d['local']);
                $row['location'] = array(
                        //'country' => Location::string2CountryId($local),
                        //'province' => Location::string2ProvinceId($local),
                        //'city' => Location::string2CityId($local),
                        'local' => $local,
                    );

                $row['url'] = array();
                if($d['url'] && $d['url'] != 'http://无') $row['url'][] = array('type' => 'web','url' => trim($d['url'],'/'));
                if($d['ios'] && $d['ios'] != 'http://无') $row['url'][] = array('type' => 'ios','url' => $d['ios']);
                if($d['android'] && $d['android'] != 'http://无') $row['url'][] = array('type' => 'android','url' => $d['android']);
                
                $row['product'] = array();
                $row['social_network'] = array();
                $row['company'] = NULL;
                $row['founder'] = array();

                $founder = array();
                $t = json_decode($d['team'], true);
                if($t){
                    $founder['name'] = $t['name'];
                    $founder['title'] = $t['job'];
                    $founder['avatar'] = $t['avatar'];
                    $founder['intro'] = $t['info'];
                }
                    
                if($founder) $row['founder']['member'][] = $founder;

                $row['team'] = array();
                if($d['scale']) $row['team']['scale'] = $d['scale'];

                $row['funding'] = array();

                $financing = array();
                $row['funding_history'] = $financing;

                $row['milestone'] = array();
                $milestone = json_decode($d['milestone'],true);
                if($milestone){
                    foreach ($milestone as $k => $m) {
                        $row['milestone'][$k]['title'] = $m['title'];
                        $row['milestone'][$k]['type'] = $m['type'];
                        $row['milestone'][$k]['date'] = $this->string2Date($m['time']); 
                    }
                }
                
                $row['news'] = array();

                $row['_undefined'] = array();
                
                $row['create_time'] = $d['update_time'];
                $row['update_time'] = date('Y-m-d H:i:s');

                foreach ($row as $key => $value) {
                    if(is_array($value)) $row[$key] = json_encode($value);
                    if(empty($value) && $value !== 0) $row[$key] = NULL;
                }

                $st->bindParam(':sou',$row['_source']);
                $st->bindParam(':cre',$row['_creator']);
                $st->bindParam(':nam',$row['name']);
                $st->bindParam(':log',$row['logo']);
                $st->bindParam(':bri',$row['brief']);
                $st->bindParam(':intro',$row['intro']);
                $st->bindParam(':ind',$row['industry']);
                $st->bindParam(':tag',$row['tag']);
                $st->bindParam(':fun',$row['fund_status']);
                $st->bindParam(':ima',$row['image']);
                $st->bindParam(':vid',$row['video']);
                $st->bindParam(':introduct',$row['introduction']);
                $st->bindParam(':loc',$row['location']);
                $st->bindParam(':url',$row['url']);
                $st->bindParam(':pro',$row['product']);
                $st->bindParam(':soc',$row['social_network']);
                $st->bindParam(':com',$row['company']);
                $st->bindParam(':fou',$row['founder']);
                $st->bindParam(':tea',$row['team']);
                $st->bindParam(':fund',$row['funding']);
                $st->bindParam(':funding',$row['funding_history']);
                $st->bindParam(':mil',$row['milestone']);
                $st->bindParam(':news',$row['news']);
                $st->bindParam(':und',$row['_undefined']);
                $st->bindParam(':create_t',$row['create_time']);
                $st->bindParam(':update_t',$row['update_time']);

                $st->execute(); 
                echo "Id : ".$target_db->lastInsertId()."\r\n";
            }

            echo "===============\r\n";
        }
        /*
        public function syncVc($target_db, $dbname, $table, $field, $type = PDO::FETCH_ASSOC){
            $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field,'',$type);

            $sql = "INSERT INTO company_project(company_id,project_name,fund_status_id,industry,location,province_id,city_id,icon,url,main_pic,info,update_time) VALUES(?,?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE company_id=VALUES(company_id),fund_status_id=VALUES(fund_status_id),industry=VALUES(industry),location=VALUES(location),province_id=VALUES(province_id),city_id=VALUES(city_id),icon=VALUES(icon),url=VALUES(url),main_pic=VALUES(main_pic),info=VALUES(info),update_time=VALUES(update_time)";
            $st = $target_db->prepare($sql);

            foreach ($data as $d) {
                if(empty($d['company_name'])){
                    $com_id = 0;
                }else{
                    $result = $target_db->query("SELECT id FROM company WHERE company_name='".addslashes($d['company_name'])."'")->fetchAll(PDO::FETCH_COLUMN);
                    if($result){
                        $com_id = $result[0];
                    }else{
                        $com_id = 0;
                    }  
                }

                $fund_status = $this->fundStatusNum($d['stage']);

                if(empty($d['local'])){
                    $province_id = 0;
                    $city_id = 0;
                }else{
                    if(mb_strpos($d['local'], ' · ') === false){
                        $province = $target_db->query("SELECT province_id FROM province WHERE province_name like '".$d['local']."%'")->fetchAll(PDO::FETCH_COLUMN);

                        $province_id = empty($province) ? 35 : $province[0];

                        if(in_array($d['local'], array('北京','北京市','上海','上海市','天津','天津市','重庆','重庆市','香港','澳门'))){
                            $city = $target_db->query("SELECT city_id FROM city WHERE city_name like '".$d['local']."%'")->fetchAll(PDO::FETCH_COLUMN);
                            $city_id = empty($city) ? 0 : $city[0];
                        }
                        
                    }else{
                        $local = explode(' · ', $d['local']);
                        $province = $target_db->query("SELECT province_id FROM province WHERE province_name like '".$local[0]."%'")->fetchAll(PDO::FETCH_COLUMN);

                        $province_id = empty($province) ? 35 : $province[0];

                        if(in_array($local[0], array('北京','北京市','上海','上海市','天津','天津市','重庆','重庆市','香港','澳门'))){
                            $local[1] = $local[0];
                        }
                        $city = $target_db->query("SELECT city_id FROM city WHERE city_name like '".$local[1]."%'")->fetchAll(PDO::FETCH_COLUMN);
                        $city_id = empty($city) ? 0 : $city[0];
                    }
                      
                }

                $pic = json_decode($d['pic'],true);
                if($pic){
                    $pic = implode(',', $pic);
                }else{
                    $pic = '';
                }

                $url = trim($d['url'],'/');
                $date = date('Y-m-d H:i:s');

                $exists = $target_db->query("SELECT * FROM company_project WHERE project_name='".addslashes($d['project_name'])."'")->fetchAll(PDO::FETCH_ASSOC);
                if($exists){
                    $com_id = $exists[0]['company_id'] == 0 ? $com_id : $exists[0]['company_id'];
                    $fund_status = $exists[0]['fund_status_id'] == 0 ? $fund_status : $exists[0]['fund_status_id'];
                    $d['industry'] = empty($exists[0]['industry']) ? $d['industry'] : $exists[0]['industry'];
                    $d['local'] = empty($exists[0]['location']) ? $d['local'] : $exists[0]['location'];
                    $province_id = $exists[0]['province_id'] == 0 ? $province_id : $exists[0]['province_id'];
                    $city_id = $exists[0]['city_id'] == 0 ? $city_id : $exists[0]['city_id'];
                    $d['logo'] = empty($exists[0]['icon']) ? $d['logo'] : $exists[0]['icon'];
                    $d['url'] = empty($exists[0]['url']) ? $d['url'] : $exists[0]['url'];
                    $d['intro'] = empty($exists[0]['intro']) ? $d['intro'] : $exists[0]['intro'];
                    $pic = empty($exists[0]['main_pic']) ? $pic : $exists[0]['main_pic'];
                }

                $st->bindParam(1,$com_id,PDO::PARAM_INT);
                $st->bindParam(2,$d['project_name'],PDO::PARAM_STR);
                $st->bindParam(3,$fund_status,PDO::PARAM_INT);
                $st->bindParam(4,$d['industry'],PDO::PARAM_STR);
                $st->bindParam(5,$d['local'],PDO::PARAM_STR);
                $st->bindParam(6,$province_id,PDO::PARAM_INT);
                $st->bindParam(7,$city_id,PDO::PARAM_INT);
                $st->bindParam(8,$d['logo'],PDO::PARAM_STR);
                $st->bindParam(9,$url,PDO::PARAM_STR);
                $st->bindParam(10,$pic,PDO::PARAM_STR);
                $st->bindParam(11,$d['intro'],PDO::PARAM_STR);
                $st->bindParam(12,$date,PDO::PARAM_STR);
                $st->execute();

                echo "Id : ".$target_db->lastInsertId()."\r\n";
            }

            echo "===============\r\n";
        }*/
    
        private function databaseObj($dbname,$host = '127.0.0.1',$user = 'root',$password = 'root'){
            $db=new PDO('mysql:dbname='.$dbname.';host='.$host,$user,$password);
            $db->exec("set names utf8");

            return $db;
        }

        private function selectData($db, $table, $field, $where = '', $type = PDO::FETCH_COLUMN){
            $data = $db->query("SELECT ".$field." FROM ".$table." ".$where)->fetchAll($type); 
            
            return $data;
        }

        //日期转换
        private function string2Date($date){
            $arr = array(
                    '.10' => '.10',
                    '.11' => '.11',
                    '.12' => '.12',
                    '.13' => '.13',
                    '.14' => '.14',
                    '.15' => '.15',
                    '.16' => '.16',
                    '.17' => '.17',
                    '.18' => '.18',
                    '.19' => '.19',
                    '.20' => '.20',
                    '.21' => '.21',
                    '.22' => '.22',
                    '.23' => '.23',
                    '.24' => '.24',
                    '.25' => '.25',
                    '.26' => '.26',
                    '.27' => '.27',
                    '.28' => '.28',
                    '.29' => '.29',
                    '.30' => '.30',
                    '.31' => '.31',
                    '.1' => '.01',
                    '.2' => '.02',
                    '.3' => '.03',
                    '.4' => '.04',
                    '.5' => '.05',
                    '.6' => '.06',
                    '.7' => '.07',
                    '.8' => '.08',
                    '.9' => '.09',
                    '-' => '.',
                    '年' => '.',
                    '月' => '.',
                    '日' => '.'
                );
            return strtr($date,$arr);
        }
    }