<?php
    class IT199{
        public function search(){
            $db=new PDO('mysql:dbname=industry;host=127.0.0.1','root','root');
            $db->exec("set names utf8");

            $cache = CACHE_PATH . '/199IT/search/';

            $res = $db->query("SELECT id,name FROM report")->fetchAll(PDO::FETCH_ASSOC);

            $sql = "UPDATE report SET info=:info WHERE id=:id";
            $st = $db->prepare($sql);

            foreach ($res as $re) {
                $file = $cache.$re['id'].'.html';
                if(!file_exists($file)) continue;

                $html = toUtf8(read($file));
                $list = $this->getSearchList($html);

                if(empty($list)) continue;

                $info = json_encode($list);
                
                $st->bindParam(':id',$re['id']);
                $st->bindParam(':info', $info);

                $st->execute();
            }
        }

        //提取url信息
        private function getSearchList($html){
            $info = array();
            $dom = phpQuery::newDocumentHTML($html);

            $list = $dom['#content article.entry-list'];
            foreach ($list as $k => $li) {
                $info[$k]['title'] = trim(pq($li)->find('h2 a')->text());
                $info[$k]['url'] = trim(pq($li)->find('h2 a')->attr('href'));
                $info[$k]['intro'] = trim(pq($li)->find('p.post-excerpt')->text());
            }

            $dom -> unloadDocument();
            return $info;
        }
    }