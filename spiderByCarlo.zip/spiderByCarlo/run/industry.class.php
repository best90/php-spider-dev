<?php
    require_once(ROOT_PATH.'/nuts_lib/currency.class.php');
    class Industry{
        //同步融资事件
        public function syncEvents(){
            $itjuzi =new PDO('mysql:dbname=itjuzi_project;host=127.0.0.1','root','root');
            $itjuzi->exec("set names utf8");

            $evervc = new PDO('mysql:dbname=evervc_project;host=127.0.0.1','root','root');
            $evervc->exec("set names utf8");

            $db=new PDO('mysql:dbname=industry;host=127.0.0.1','root','root');
            $db->exec("set names utf8");

            $sql = "INSERT INTO events(project_name,industry,location,stage,amount,investors,update_time) VALUES(:pro,:ind,:loc,:sta,:amo,:inv,:upd) ON DUPLICATE KEY UPDATE location=VALUES(location),stage=VALUES(stage),amount=VALUES(amount),investors=VALUES(investors)";
            $st = $db->prepare($sql);

            $invest_res = $itjuzi->query("SELECT * FROM investevents ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);
            $merger_res = $itjuzi->query("SELECT * FROM merger ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);
            $evervc_res = $evervc->query("SELECT * FROM invest ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);

            $res = array_merge($invest_res,$merger_res,$evervc_res);

            foreach ($res as $re) {
                switch ($re['industry']) {
                    case '体育运动':
                        $re['industry'] = '文体娱乐';
                        break;
                    case '房产服务':
                        $re['industry'] = '房产家居';
                        break;
                    case '文化娱乐':
                        $re['industry'] = '文体娱乐';
                        break;
                    case '本地生活':
                        $re['industry'] = '本地服务';
                        break;
                    case '电子商务':
                        $re['industry'] = '电商';
                        break;
                    case '硬件':
                        $re['industry'] = '智能硬件';
                        break;
                    case '社交网络':
                        $re['industry'] = '社交';
                        break;
                    case 'O2O':
                        $re['industry'] = '本地服务';
                        break;
                    case '房产':
                        $re['industry'] = '房产家居';
                        break;
                    case '文娱体育':
                        $re['industry'] = '文体娱乐';
                        break;
                    case '智能家居':
                        $re['industry'] = '智能硬件';
                        break;
                    default:
                        $re['industry'] = $re['industry'];
                        break;
                }

                $st->bindParam(':pro',$re['project_name']);
                $st->bindParam(':ind',$re['industry']);

                if(empty($re['location'])) $re['location'] = NULL;
                $st->bindParam(':loc',$re['location']);

                if(isset($re['stage'])){
                    $st->bindParam(':sta',$re['stage']);
                }else{
                    $stage = NULL;
                    $st->bindParam(':sta',$stage);
                }
                
                $st->bindParam(':amo',$re['amount']);
                $st->bindParam(':inv',$re['investors']);
                $st->bindParam(':upd',$re['update_time']);

                $st->execute();
                $return = $db->lastInsertId();
                echo "id : ".$return."\r\n";
            }
        }

        //行业融资统计
        public function statistic(){
            $db=new PDO('mysql:dbname=industry;host=127.0.0.1','root','root');
            $db->exec("set names utf8");

            $sql = "UPDATE invest SET month_num=:mn,month_amount=:ma,2month_num=:2mn,2month_amount=:2ma,3month_num=:3mn,3month_amount=:3ma,6month_num=:6mn,6month_amount=:6ma,year_num=:yn,year_amount=:ya WHERE name=:name";
            $st = $db->prepare($sql);

            $res = $db->query("SELECT * FROM invest WHERE pid=0")->fetchAll(PDO::FETCH_ASSOC);
                
            $month = date('Y-m-d', strtotime("-1 month"));
            $two_month = date('Y-m-d', strtotime("-2 months"));
            $three_month = date('Y-m-d', strtotime("-3 months"));
            $six_month = date('Y-m-d', strtotime("-6 months"));
            $year = date('Y-m-d', strtotime("last year"));

            foreach ($res as $re) {
                $month_res = $db->query("SELECT * FROM events WHERE industry='".$re['name']."' AND update_time>='".$month."'")->fetchAll(PDO::FETCH_ASSOC);
                
                $month_num = count($month_res);
                $month_amount = 0;
                foreach ($month_res as $val) {
                    $money = Currency::toMoney($val['amount']);
                    if(!isset($money['money'])) continue;
                    if(is_array($money['money'])) $money['money'] = $money['money'][0];
                    
                    if(isset($money['currency'])){
                        $month_amount += $this->moneyToCNY($money['money'],$money['currency']);
                    }elseif(isset($money['symbol'])){
                        $month_amount += $this->moneyToCNY($money['money'],$money['symbol']);
                    }else{
                        $month_amount += $this->moneyToCNY($money['money']);
                    }
                }

                $two_month_res = $db->query("SELECT * FROM events WHERE industry='".$re['name']."' AND update_time>='".$two_month."'")->fetchAll(PDO::FETCH_ASSOC);
                $two_month_num = count($two_month_res);
                $two_month_amount = 0;
                foreach ($two_month_res as $val) {
                    $money = Currency::toMoney($val['amount']);
                    if(!isset($money['money'])) continue;
                    if(is_array($money['money'])) $money['money'] = $money['money'][0];
                    
                    if(isset($money['currency'])){   
                        $two_month_amount += $this->moneyToCNY($money['money'],$money['currency']);
                    }elseif(isset($money['symbol'])){
                        $two_month_amount += $this->moneyToCNY($money['money'],$money['symbol']);
                    }else{
                        $two_month_amount += $this->moneyToCNY($money['money']);
                    }
                }

                $three_month_res = $db->query("SELECT * FROM events WHERE industry='".$re['name']."' AND update_time>='".$three_month."'")->fetchAll(PDO::FETCH_ASSOC);
                $three_month_num = count($three_month_res);
                $three_month_amount = 0;
                foreach ($three_month_res as $val) {
                    $money = Currency::toMoney($val['amount']);
                    if(!isset($money['money'])) continue;
                    if(is_array($money['money'])) $money['money'] = $money['money'][0];
                    
                    if(isset($money['currency'])){
                        $three_month_amount += $this->moneyToCNY($money['money'],$money['currency']);
                    }elseif(isset($money['symbol'])){
                        $three_month_amount += $this->moneyToCNY($money['money'],$money['symbol']);
                    }else{
                        $three_month_amount += $this->moneyToCNY($money['money']);
                    }
                }

                $six_month_res = $db->query("SELECT * FROM events WHERE industry='".$re['name']."' AND update_time>='".$six_month."'")->fetchAll(PDO::FETCH_ASSOC);
                $six_month_num = count($six_month_res);
                $six_month_amount = 0;
                foreach ($six_month_res as $val) {
                    $money = Currency::toMoney($val['amount']);
                    if(!isset($money['money'])) continue;
                    if(is_array($money['money'])) $money['money'] = $money['money'][0];
                    
                    if(isset($money['currency'])){
                        $six_month_amount += $this->moneyToCNY($money['money'],$money['currency']);
                    }elseif(isset($money['symbol'])){
                        $six_month_amount += $this->moneyToCNY($money['money'],$money['symbol']);
                    }else{
                        $six_month_amount += $this->moneyToCNY($money['money']);
                    }
                }

                $year_res = $db->query("SELECT * FROM events WHERE industry='".$re['name']."' AND update_time>='".$year."'")->fetchAll(PDO::FETCH_ASSOC);
                $year_num = count($year_res);
                $year_amount = 0;
                foreach ($year_res as $val) {
                    $money = Currency::toMoney($val['amount']);
                    if(!isset($money['money'])) continue;
                    if(is_array($money['money'])) $money['money'] = $money['money'][0];

                    if(isset($money['currency'])){
                        $year_amount += $this->moneyToCNY($money['money'],$money['currency']);
                    }elseif(isset($money['symbol'])){
                        $year_amount += $this->moneyToCNY($money['money'],$money['symbol']);
                    }else{
                        $year_amount += $this->moneyToCNY($money['money']);
                    }
                }
                
                $st->bindParam(':mn',$month_num);
                $st->bindParam(':ma',$month_amount);
                $st->bindParam(':2mn',$two_month_num);
                $st->bindParam(':2ma',$two_month_amount);
                $st->bindParam(':3mn',$three_month_num);
                $st->bindParam(':3ma',$three_month_amount);
                $st->bindParam(':6mn',$six_month_num);
                $st->bindParam(':6ma',$six_month_amount);
                $st->bindParam(':yn',$year_num);
                $st->bindParam(':ya',$year_amount);
                $st->bindParam(':name',$re['name']);

                $st->execute();
            }
        }

        private function moneyToCNY($money,$uint = 'CNY'){
            switch ($uint) {
                case 'USD':
                    $money_CNY = $money*6.5;
                    break;
                case '$':
                    $money_CNY = $money*6.5;
                    break;
                case 'EUR':
                    $money_CNY = $money*7.4;
                    break;
                case '€':
                    $money_CNY = $money*7.4;
                    break;
                case 'GBP':
                    $money_CNY = $money*9.3;
                    break;
                case 'HKD':
                    $money_CNY = $money*0.8;
                    break;
                case 'TWD':
                    $money_CNY = $money*0.2;
                    break;
                default:
                    $money_CNY = $money;
                    break;
            }

            return $money_CNY;
        }
    }