<?php 
    // IT桔子>36kr>拉勾网>天天投>创业邦>猎云>虎嗅>天使汇>创投圈
    class Nuts_project_tags{

        public function go(){
            $target_db = $this->databaseObj('nuts_tool');
            //IT桔子
            //$this->syncCommon($target_db, 'itjuzi_project','itjuzi_project','project_name,tags');
            
            //36kr
            //$this->syncCommon($target_db, '36kr_project','36kr_project','project_name,tags');
            
            //天天投
            //$this->syncCommon($target_db,'evervc_project','evervc_project','project_name,tags');
            
            //创业邦
            //$this->syncCommon2($target_db,'cyzone_project','cyzone_project','project_name,industry');
            
            //虎嗅网
            //$this->syncHuxiu($target_db,'other_project','huxiu_project','project_name,tag');
            
            //天使汇
            //$this->syncAngel($target_db,'angel_project','angel_project','proj_name,industry');
            
            //拉勾网
            //$this->syncCommon2($target_db,'lagou_project','lagou_project','project_name,industry');
            //
            //创投圈
            $this->syncCommon2($target_db,'vc_project','vc_project','project_name,industry');
        }

/*
 * --------------------------------------------分割线------------------------------------------------------
 * 自定义相关函数
 */
        public function syncCommon($target_db, $dbname, $table, $field, $type = PDO::FETCH_ASSOC){
            $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field,'',$type);

            $sql = "INSERT INTO company_project_tag(project_id,tag_id) VALUES(?,?)";
            $st = $target_db->prepare($sql);
            foreach ($data as $d) {
                if(empty($d['project_name']) || empty($d['tags'])) continue;
                
                $proj = $target_db->query("SELECT id FROM company_project WHERE project_name='".addslashes($d['project_name'])."'")->fetchAll(PDO::FETCH_COLUMN);
                if(empty($proj)) continue;

                $project_id = $proj[0];

                $tags = explode(',', $d['tags']);
                foreach ($tags as $tag) {
                    $t = $target_db->query("SELECT id FROM tags WHERE name='".addslashes($tag)."'")->fetchAll(PDO::FETCH_COLUMN);
                    if(empty($t)) continue;

                    $tag_id = $t[0];
                    $st->bindParam(1,$project_id,PDO::PARAM_INT);
                    $st->bindParam(2,$tag_id,PDO::PARAM_INT);
                    $st->execute();
                    echo "id : ".$target_db->lastInsertId()."\r\n";
                } 
            }
            echo "===============\r\n";
        }

        public function syncCommon2($target_db, $dbname, $table, $field, $type = PDO::FETCH_ASSOC){
            $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field,'',$type);

            $sql = "INSERT INTO company_project_tag(project_id,tag_id) VALUES(?,?)";
            $st = $target_db->prepare($sql);
            foreach ($data as $d) {
                if(empty($d['project_name']) || empty($d['industry'])) continue;
                
                $proj = $target_db->query("SELECT id FROM company_project WHERE project_name='".addslashes($d['project_name'])."'")->fetchAll(PDO::FETCH_COLUMN);
                if(empty($proj)) continue;

                $project_id = $proj[0];

                $tags = explode(',', $d['industry']);
                foreach ($tags as $tag) {
                    $t = $target_db->query("SELECT id FROM tags WHERE name='".addslashes($tag)."'")->fetchAll(PDO::FETCH_COLUMN);
                    if(empty($t)) continue;

                    $tag_id = $t[0];
                    $st->bindParam(1,$project_id,PDO::PARAM_INT);
                    $st->bindParam(2,$tag_id,PDO::PARAM_INT);
                    $st->execute();
                    echo "id : ".$target_db->lastInsertId()."\r\n";
                } 
            }
            echo "===============\r\n";
        }

        public function syncHuxiu($target_db, $dbname, $table, $field, $type = PDO::FETCH_ASSOC){
            $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field,'',$type);

            $sql = "INSERT INTO company_project_tag(project_id,tag_id) VALUES(?,?)";
            $st = $target_db->prepare($sql);
            foreach ($data as $d) {
                if(empty($d['project_name']) || empty($d['tag'])) continue;
                
                $proj = $target_db->query("SELECT id FROM company_project WHERE project_name='".addslashes($d['project_name'])."'")->fetchAll(PDO::FETCH_COLUMN);
                if(empty($proj)) continue;

                $project_id = $proj[0];

                $tags = explode(',', $d['tag']);
                foreach ($tags as $tag) {
                    $t = $target_db->query("SELECT id FROM tags WHERE name='".addslashes($tag)."'")->fetchAll(PDO::FETCH_COLUMN);
                    if(empty($t)) continue;

                    $tag_id = $t[0];
                    $st->bindParam(1,$project_id,PDO::PARAM_INT);
                    $st->bindParam(2,$tag_id,PDO::PARAM_INT);
                    $st->execute();
                    echo "id : ".$target_db->lastInsertId()."\r\n";
                } 
            }
            echo "===============\r\n";
        }
    
        public function syncAngel($target_db, $dbname, $table, $field, $type = PDO::FETCH_ASSOC){
           $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field,'',$type);

            $sql = "INSERT INTO company_project_tag(project_id,tag_id) VALUES(?,?)";
            $st = $target_db->prepare($sql);
            foreach ($data as $d) {
                if(empty($d['proj_name']) || empty($d['industry'])) continue;
                
                $proj = $target_db->query("SELECT id FROM company_project WHERE project_name='".addslashes($d['proj_name'])."'")->fetchAll(PDO::FETCH_COLUMN);
                if(empty($proj)) continue;

                $project_id = $proj[0];

                $tags = explode(' · ', $d['industry']);
                foreach ($tags as $tag) {
                    $t = $target_db->query("SELECT id FROM tags WHERE name='".addslashes($tag)."'")->fetchAll(PDO::FETCH_COLUMN);
                    if(empty($t)) continue;

                    $tag_id = $t[0];
                    $st->bindParam(1,$project_id,PDO::PARAM_INT);
                    $st->bindParam(2,$tag_id,PDO::PARAM_INT);
                    $st->execute();
                    echo "id : ".$target_db->lastInsertId()."\r\n";
                } 
            }
            echo "===============\r\n";
        }
    
        public function databaseObj($dbname,$host = '127.0.0.1',$user = 'root',$password = 'root'){
            $db=new PDO('mysql:dbname='.$dbname.';host='.$host,$user,$password);
            $db->exec("set names utf8");

            return $db;
        }

        public function selectData($db, $table, $field, $where = '', $type = PDO::FETCH_COLUMN){
            $data = $db->query("SELECT ".$field." FROM ".$table." ".$where)->fetchAll($type); 
            
            return $data;
        }
    }