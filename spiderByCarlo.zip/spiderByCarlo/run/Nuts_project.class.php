<?php 
    // IT桔子>36kr>拉勾网>天天投>创业邦>猎云>虎嗅>天使汇>创投圈
    class Nuts_project{

        public function go(){
            $target_db = $this->databaseObj('nuts_tool');
            //IT桔子
            $this->syncITjuzi($target_db, 'itjuzi_project','itjuzi_project','project_name,logo,intro,industry,location,stage,url,picshow_url,company');
           
            //36kr
            $this->sync36kr($target_db, '36kr_project','36kr_project','project_name,logo,intro,industry,address1,address2,pictures,website,funding,company_info');

            //天天投
            $this->syncEvervc($target_db,'evervc_project','evervc_project','project_name,logo,intro,pic,tags,location,stage,company,url');
            
            //创业邦
            $this->syncCyzone($target_db,'cyzone_project','cyzone_project','project_name,company_name,icon,info_img,url,location,financing_stage,industry,intro');
            
            //猎云网
            //$this->syncLieyun($target_db,'other_project','lieyun_project','company');
            
            //虎嗅网
            $this->syncHuxiu($target_db,'other_project','huxiu_project','project_name,icon,tag,intro_info,gallery_list,url,financing_stage,company_name,location');
            
            //天使汇
            $this->syncAngel($target_db,'angel_project','angel_project','proj_name,industry,province,city,logo_id,description,org_name,url,pic');
            
            //创投圈
            $this->syncVc($target_db,'vc_project','vc_project','project_name,logo,intro,pic,industry,local,stage,url');

            //拉勾网
            $this->syncLagou($target_db,'lagou_project','lagou_project','project_name,logo,intro,industry,location,stage,url,company');
        }

        public function debug(){
            $target_db = $this->databaseObj('nuts_tool');
            $this->syncVc($target_db,'vc_project','vc_project','project_name,logo,intro,pic,industry,local,stage,url');
        }

/*
 * --------------------------------------------分割线------------------------------------------------------
 * 自定义相关函数
 */
    
        public function syncITjuzi($target_db, $dbname, $table, $field, $type = PDO::FETCH_ASSOC){
            $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field,'',$type);

            $sql = "INSERT INTO company_project(company_id,project_name,fund_status_id,industry,location,province_id,city_id,icon,url,main_pic,info,update_time) VALUES(?,?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE company_id=VALUES(company_id),fund_status_id=VALUES(fund_status_id),industry=VALUES(industry),location=VALUES(location),province_id=VALUES(province_id),city_id=VALUES(city_id),icon=VALUES(icon),url=VALUES(url),main_pic=VALUES(main_pic),info=VALUES(info),update_time=VALUES(update_time)";
            $st = $target_db->prepare($sql);

            foreach ($data as $d) {
                $result = $target_db->query("SELECT id FROM company WHERE company_name='".addslashes($d['company'])."'")->fetchAll(PDO::FETCH_COLUMN);
                if($result){
                    $com_id = $result[0];
                }else{
                    $com_id = 0;
                }

                $fund_status = $this->fundStatusNum($d['stage']);

                if(empty($d['location'])){
                    $province_id = 0;
                    $city_id = 0;
                }else{
                    if(!mb_strpos($d['location'], '·') && !empty($d['location'])) $d['location'] = $d['location'].'·'.$d['location'];
                    $local = explode('·', $d['location']);
                    $province = $target_db->query("SELECT province_id FROM province WHERE province_name like '".$local[0]."%'")->fetchAll(PDO::FETCH_COLUMN);

                    $province_id = empty($province) ? 35 : $province[0];

                    if(in_array($local[0], array('北京','上海','天津','重庆','香港','澳门'))){
                        $local[1] = $local[0];
                    }
                    $city = $target_db->query("SELECT city_id FROM city WHERE city_name like '".$local[1]."%'")->fetchAll(PDO::FETCH_COLUMN);
                    $city_id = empty($city) ? 0 : $city[0];
                    if($province_id == 35) $city_id = -1;
                }

                $url = trim($d['url'],'/');
                $date = date('Y-m-d H:i:s');
                
                $st->bindParam(1,$com_id,PDO::PARAM_INT);
                $st->bindParam(2,$d['project_name'],PDO::PARAM_STR);
                $st->bindParam(3,$fund_status,PDO::PARAM_INT);
                $st->bindParam(4,$d['industry'],PDO::PARAM_STR);
                $st->bindParam(5,$d['location'],PDO::PARAM_STR);
                $st->bindParam(6,$province_id,PDO::PARAM_INT);
                $st->bindParam(7,$city_id,PDO::PARAM_INT);
                $st->bindParam(8,$d['logo'],PDO::PARAM_STR);
                $st->bindParam(9,$url,PDO::PARAM_STR);
                $st->bindParam(10,$d['picshow_url'],PDO::PARAM_STR);
                $st->bindParam(11,$d['intro'],PDO::PARAM_STR);
                $st->bindParam(12,$date,PDO::PARAM_STR);
                $st->execute(); 
                echo "Id : ".$target_db->lastInsertId()."\r\n";
            }

            echo "===============\r\n";
        }

        public function sync36kr($target_db, $dbname, $table, $field, $type = PDO::FETCH_ASSOC){
            $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field,'',$type);

            $sql = "INSERT INTO company_project(company_id,project_name,fund_status_id,industry,location,province_id,city_id,icon,url,main_pic,info,update_time) VALUES(?,?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE company_id=VALUES(company_id),fund_status_id=VALUES(fund_status_id),industry=VALUES(industry),location=VALUES(location),province_id=VALUES(province_id),city_id=VALUES(city_id),icon=VALUES(icon),url=VALUES(url),main_pic=VALUES(main_pic),info=VALUES(info),update_time=VALUES(update_time)";
            $st = $target_db->prepare($sql);

            foreach ($data as $d) {
                $com_info = json_decode($d['company_info'],true);
                if(empty($com_info)){
                    $com_id = 0;
                }else{
                    if(!isset($com_info['Name']) || empty($com_info['Name'])){
                        $com_id = 0;
                    }else{
                        $result = $target_db->query("SELECT id FROM company WHERE company_name='".addslashes($com_info['Name'])."'")->fetchAll(PDO::FETCH_COLUMN);
                        if($result){
                            $com_id = $result[0];
                        }else{
                            $com_id = 0;
                        }
                    }
                }

                $exists = $target_db->query("SELECT company_id,url FROM company_project WHERE project_name='".addslashes($d['project_name'])."'")->fetchAll(PDO::FETCH_ASSOC);
                if($exists && ($exists[0]['company_id'] == $com_id || $exists[0]['url'] == $d['website'])) continue;

                $funding = json_decode($d['funding'],true);
                if(empty($funding)){
                    $fund_status = 0;
                }else{
                    $fund_status = $this->fundStatusFor36kr($funding[0]['stage']);
                }

                if(empty($d['address1'])){
                    $province_id = 0;
                    $city_id = 0;
                    $location = '';
                }else{
                    if($d['address1'] == '大连市'){
                        $d['address1'] == '辽宁省';
                        $d['address2'] == '大连市';
                    }
                    $location = $d['address1'].'·'.$d['address2'];
                    if(empty($d['address2'])) $location = $d['address1'];

                    $province = $target_db->query("SELECT province_id FROM province WHERE province_name like '".$d['address1']."%'")->fetchAll(PDO::FETCH_COLUMN);

                    $province_id = empty($province) ? 35 : $province[0];

                    if(in_array($d['address1'], array('北京市','上海市','天津市','重庆市','香港','澳门'))){
                        $d['address2'] = $d['address1'];
                    }
                    $city = $target_db->query("SELECT city_id FROM city WHERE city_name like '".$d['address2']."%'")->fetchAll(PDO::FETCH_COLUMN);
                    $city_id = empty($city) ? 0 : $city[0];
                    if(empty($d['address2'])) $city_id = 0;
                    if($province_id == 35) $city_id = -1;
                }

                $url = trim($d['website'],'/');
                $date = date('Y-m-d H:i:s');

                $exists = $target_db->query("SELECT * FROM company_project WHERE project_name='".addslashes($d['project_name'])."'")->fetchAll(PDO::FETCH_ASSOC);
                if($exists){
                    $com_id = $exists[0]['company_id'] == 0 ? $com_id : $exists[0]['company_id'];
                    $fund_status = $exists[0]['fund_status_id'] == 0 ? $fund_status : $exists[0]['fund_status_id'];
                    $d['industry'] = empty($exists[0]['industry']) ? $d['industry'] : $exists[0]['industry'];
                    $d['location'] = empty($exists[0]['location']) ? $d['location'] : $exists[0]['location'];
                    $province_id = $exists[0]['province_id'] == 0 ? $province_id : $exists[0]['province_id'];
                    $city_id = $exists[0]['city_id'] == 0 ? $city_id : $exists[0]['city_id'];
                    $d['logo'] = empty($exists[0]['icon']) ? $d['logo'] : $exists[0]['icon'];
                    $url = empty($exists[0]['url']) ? $d['website'] : $exists[0]['url'];
                    $d['pictures'] = empty($exists[0]['main_pic']) ? $d['pictures'] : $exists[0]['main_pic'];
                    $d['intro'] = empty($exists[0]['intro']) ? $d['intro'] : $exists[0]['intro'];
                }
                
                $st->bindParam(1,$com_id,PDO::PARAM_INT);
                $st->bindParam(2,$d['project_name'],PDO::PARAM_STR);
                $st->bindParam(3,$fund_status,PDO::PARAM_INT);
                $st->bindParam(4,$d['industry'],PDO::PARAM_STR);
                $st->bindParam(5,$location,PDO::PARAM_STR);
                $st->bindParam(6,$province_id,PDO::PARAM_INT);
                $st->bindParam(7,$city_id,PDO::PARAM_INT);
                $st->bindParam(8,$d['logo'],PDO::PARAM_STR);
                $st->bindParam(9,$url,PDO::PARAM_STR);
                $st->bindParam(10,$d['pictures'],PDO::PARAM_STR);
                $st->bindParam(11,$d['intro'],PDO::PARAM_STR);
                $st->bindParam(12,$date,PDO::PARAM_STR);
                $st->execute(); 
                echo "Id : ".$target_db->lastInsertId()."\r\n";
            }
            echo "===============\r\n";
        }

        public function syncLagou($target_db, $dbname, $table, $field, $type = PDO::FETCH_ASSOC){
            $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field,'',$type);

            $sql = "INSERT INTO company_project(company_id,project_name,fund_status_id,industry,location,province_id,city_id,icon,url,info,update_time) VALUES(?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE company_id=VALUES(company_id),fund_status_id=VALUES(fund_status_id),industry=VALUES(industry),location=VALUES(location),province_id=VALUES(province_id),city_id=VALUES(city_id),icon=VALUES(icon),url=VALUES(url),info=VALUES(info),update_time=VALUES(update_time)";
            $st = $target_db->prepare($sql);

            foreach ($data as $d) {
                if(empty($d['company'])){
                    $com_id = 0;
                }else{
                    $result = $target_db->query("SELECT id FROM company WHERE company_name='".addslashes($d['company'])."'")->fetchAll(PDO::FETCH_COLUMN);
                    if($result){
                        $com_id = $result[0];
                    }else{
                        $com_id = 0;
                    }  
                }

                $fund_status = $this->fundStatusForLagou($d['stage']);

                if(empty($d['location'])){
                    $province_id = 0;
                    $city_id = 0;
                }else{
                    $city = $target_db->query("SELECT city_id,province_id FROM city WHERE city_name like '".$d['location']."%'")->fetchAll(PDO::FETCH_ASSOC);
                    $city_id = empty($city) ? 0 : $city[0]['city_id'];
                    $province_id = empty($city) ? 0 : $city[0]['province_id'];
                }

                $url = trim($d['url'],'/');
                $date = date('Y-m-d H:i:s');

                $exists = $target_db->query("SELECT * FROM company_project WHERE project_name='".addslashes($d['project_name'])."'")->fetchAll(PDO::FETCH_ASSOC);
                if($exists){
                    $com_id = $exists[0]['company_id'] == 0 ? $com_id : $exists[0]['company_id'];
                    $fund_status = $exists[0]['fund_status_id'] == 0 ? $fund_status : $exists[0]['fund_status_id'];
                    $d['industry'] = empty($exists[0]['industry']) ? $d['industry'] : $exists[0]['industry'];
                    $d['location'] = empty($exists[0]['location']) ? $d['location'] : $exists[0]['location'];
                    $province_id = $exists[0]['province_id'] == 0 ? $province_id : $exists[0]['province_id'];
                    $city_id = $exists[0]['city_id'] == 0 ? $city_id : $exists[0]['city_id'];
                    $d['logo'] = empty($exists[0]['icon']) ? $d['logo'] : $exists[0]['icon'];
                    $url = empty($exists[0]['url']) ? $d['url'] : $exists[0]['url'];
                    $d['intro'] = empty($exists[0]['intro']) ? $d['intro'] : $exists[0]['intro'];
                }
                
                $st->bindParam(1,$com_id,PDO::PARAM_INT);
                $st->bindParam(2,$d['project_name'],PDO::PARAM_STR);
                $st->bindParam(3,$fund_status,PDO::PARAM_INT);
                $st->bindParam(4,$d['industry'],PDO::PARAM_STR);
                $st->bindParam(5,$d['location'],PDO::PARAM_STR);
                $st->bindParam(6,$province_id,PDO::PARAM_INT);
                $st->bindParam(7,$city_id,PDO::PARAM_INT);
                $st->bindParam(8,$d['logo'],PDO::PARAM_STR);
                $st->bindParam(9,$url,PDO::PARAM_STR);
                $st->bindParam(10,$d['intro'],PDO::PARAM_STR);
                $st->bindParam(11,$date,PDO::PARAM_STR);
                $st->execute(); 
                echo "Id : ".$target_db->lastInsertId()."\r\n";
            }

            echo "===============\r\n";
        }

        public function syncEvervc($target_db, $dbname, $table, $field, $type = PDO::FETCH_ASSOC){
            $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field,'',$type);

            $sql = "INSERT INTO company_project(company_id,project_name,fund_status_id,industry,location,province_id,city_id,icon,url,main_pic,info,update_time) VALUES(?,?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE company_id=VALUES(company_id),fund_status_id=VALUES(fund_status_id),industry=VALUES(industry),location=VALUES(location),province_id=VALUES(province_id),city_id=VALUES(city_id),icon=VALUES(icon),url=VALUES(url),main_pic=VALUES(main_pic),info=VALUES(info),update_time=VALUES(update_time)";
            $st = $target_db->prepare($sql);

            foreach ($data as $d) {
                if(empty($d['company'])){
                    $com_id = 0;
                }else{
                    $result = $target_db->query("SELECT id FROM company WHERE company_name='".addslashes($d['company'])."'")->fetchAll(PDO::FETCH_COLUMN);
                    if($result){
                        $com_id = $result[0];
                    }else{
                        $com_id = 0;
                    }  
                }

                $fund_status = $this->fundStatusForEvervc($d['stage']);

                if(empty($d['location'])){
                    $province_id = 0;
                    $city_id = 0;
                }else{
                    $city = $target_db->query("SELECT city_id,province_id FROM city WHERE city_name like '".$d['location']."%'")->fetchAll(PDO::FETCH_ASSOC);
                    $city_id = empty($city) ? 0 : $city[0]['city_id'];
                    $province_id = empty($city) ? 0 : $city[0]['province_id'];
                }

                $d['pic'] = json_decode($d['pic'],true);
                if($d['pic']){
                    $d['pic'] = implode(',', $d['pic']);
                }else{
                    $d['pic'] = '';
                }

                $url = trim($d['url'],'/');
                $date = date('Y-m-d H:i:s');

                $exists = $target_db->query("SELECT * FROM company_project WHERE project_name='".addslashes($d['project_name'])."'")->fetchAll(PDO::FETCH_ASSOC);
                if($exists){
                    $com_id = $exists[0]['company_id'] == 0 ? $com_id : $exists[0]['company_id'];
                    $fund_status = $exists[0]['fund_status_id'] == 0 ? $fund_status : $exists[0]['fund_status_id'];
                    $d['tags'] = empty($exists[0]['industry']) ? $d['tags'] : $exists[0]['industry'];
                    $d['location'] = empty($exists[0]['location']) ? $d['location'] : $exists[0]['location'];
                    $province_id = $exists[0]['province_id'] == 0 ? $province_id : $exists[0]['province_id'];
                    $city_id = $exists[0]['city_id'] == 0 ? $city_id : $exists[0]['city_id'];
                    $d['logo'] = empty($exists[0]['icon']) ? $d['logo'] : $exists[0]['icon'];
                    $d['url'] = empty($exists[0]['url']) ? $d['url'] : $exists[0]['url'];
                    $d['intro'] = empty($exists[0]['intro']) ? $d['intro'] : $exists[0]['intro'];
                    $d['pic'] = empty($exists[0]['main_pic']) ? $d['pic'] : $exists[0]['main_pic'];
                }

                $st->bindParam(1,$com_id,PDO::PARAM_INT);
                $st->bindParam(2,$d['project_name'],PDO::PARAM_STR);
                $st->bindParam(3,$fund_status,PDO::PARAM_INT);
                $st->bindParam(4,$d['tags'],PDO::PARAM_STR);
                $st->bindParam(5,$d['location'],PDO::PARAM_STR);
                $st->bindParam(6,$province_id,PDO::PARAM_INT);
                $st->bindParam(7,$city_id,PDO::PARAM_INT);
                $st->bindParam(8,$d['logo'],PDO::PARAM_STR);
                $st->bindParam(9,$url,PDO::PARAM_STR);
                $st->bindParam(10,$d['pic'],PDO::PARAM_STR);
                $st->bindParam(11,$d['intro'],PDO::PARAM_STR);
                $st->bindParam(12,$date,PDO::PARAM_STR);
                $st->execute();

                echo "Id : ".$target_db->lastInsertId()."\r\n";
            }

            echo "===============\r\n";
        }

        public function syncCyzone($target_db, $dbname, $table, $field, $type = PDO::FETCH_ASSOC){
            $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field,'',$type);

            $sql = "INSERT INTO company_project(company_id,project_name,fund_status_id,industry,location,province_id,city_id,icon,url,main_pic,info,update_time) VALUES(?,?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE company_id=VALUES(company_id),fund_status_id=VALUES(fund_status_id),industry=VALUES(industry),location=VALUES(location),province_id=VALUES(province_id),city_id=VALUES(city_id),icon=VALUES(icon),url=VALUES(url),main_pic=VALUES(main_pic),info=VALUES(info),update_time=VALUES(update_time)";
            $st = $target_db->prepare($sql);

            foreach ($data as $d) {
                if(empty($d['company_name'])){
                    $com_id = 0;
                }else{
                    $result = $target_db->query("SELECT id FROM company WHERE company_name='".addslashes($d['company_name'])."'")->fetchAll(PDO::FETCH_COLUMN);
                    if($result){
                        $com_id = $result[0];
                    }else{
                        $com_id = 0;
                    }  
                }

                $fund_status = $this->fundStatusForCyzone($d['financing_stage']);

                if(empty($d['location'])){
                    $province_id = 0;
                    $city_id = 0;
                }else{
                    if(mb_strpos($d['location'], ',') === false){
                        $city = $target_db->query("SELECT city_id,province_id FROM city WHERE city_name like '".$d['location']."%'")->fetchAll(PDO::FETCH_ASSOC);
                        $city_id = empty($city) ? 0 : $city[0]['city_id'];
                        $province_id = empty($city) ? 0 : $city[0]['province_id'];
                    }else{
                        $local = explode(',', $d['location']);
                        $province = $target_db->query("SELECT province_id FROM province WHERE province_name like '".$local[0]."%'")->fetchAll(PDO::FETCH_COLUMN);

                        $province_id = empty($province) ? 35 : $province[0];

                        if(in_array($local[0], array('北京','北京市','上海','上海市','天津','天津市','重庆','重庆市','香港','澳门'))){
                            $local[1] = $local[0];
                        }
                        $city = $target_db->query("SELECT city_id FROM city WHERE city_name like '".$local[1]."%'")->fetchAll(PDO::FETCH_COLUMN);
                        $city_id = empty($city) ? 0 : $city[0];
                        if($province_id == 35) $city_id = -1;

                        $d['location'] = str_replace(',','·', $d['location']);
                    } 
                }

                $url = trim($d['url'],'/');
                $date = date('Y-m-d H:i:s');

                $exists = $target_db->query("SELECT * FROM company_project WHERE project_name='".addslashes($d['project_name'])."'")->fetchAll(PDO::FETCH_ASSOC);
                if($exists){
                    $com_id = $exists[0]['company_id'] == 0 ? $com_id : $exists[0]['company_id'];
                    $fund_status = $exists[0]['fund_status_id'] == 0 ? $fund_status : $exists[0]['fund_status_id'];
                    $d['industry'] = empty($exists[0]['industry']) ? $d['industry'] : $exists[0]['industry'];
                    $d['location'] = empty($exists[0]['location']) ? $d['location'] : $exists[0]['location'];
                    $province_id = $exists[0]['province_id'] == 0 ? $province_id : $exists[0]['province_id'];
                    $city_id = $exists[0]['city_id'] == 0 ? $city_id : $exists[0]['city_id'];
                    $d['icon'] = empty($exists[0]['icon']) ? $d['icon'] : $exists[0]['icon'];
                    $d['url'] = empty($exists[0]['url']) ? $d['url'] : $exists[0]['url'];
                    $d['intro'] = empty($exists[0]['intro']) ? $d['intro'] : $exists[0]['intro'];
                    $d['info_img'] = empty($exists[0]['main_pic']) ? $d['info_img'] : $exists[0]['main_pic'];
                }

                $st->bindParam(1,$com_id,PDO::PARAM_INT);
                $st->bindParam(2,$d['project_name'],PDO::PARAM_STR);
                $st->bindParam(3,$fund_status,PDO::PARAM_INT);
                $st->bindParam(4,$d['industry'],PDO::PARAM_STR);
                $st->bindParam(5,$d['location'],PDO::PARAM_STR);
                $st->bindParam(6,$province_id,PDO::PARAM_INT);
                $st->bindParam(7,$city_id,PDO::PARAM_INT);
                $st->bindParam(8,$d['icon'],PDO::PARAM_STR);
                $st->bindParam(9,$url,PDO::PARAM_STR);
                $st->bindParam(10,$d['info_img'],PDO::PARAM_STR);
                $st->bindParam(11,$d['intro'],PDO::PARAM_STR);
                $st->bindParam(12,$date,PDO::PARAM_STR);
                $st->execute();

                echo "Id : ".$target_db->lastInsertId()."\r\n";
            }

            echo "===============\r\n";
        }

        /*public function syncLieyun($target_db, $dbname, $table, $field, $type = PDO::FETCH_ASSOC){
            $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field,'',$type);

            $sql = "INSERT INTO company_project(company_id,project_name,fund_status_id,industry,location,province_id,city_id,icon,url,main_pic,info,update_time) VALUES(?,?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE fund_status_id=VALUES(fund_status_id),industry=VALUES(industry),location=VALUES(location),province_id=VALUES(province_id),city_id=VALUES(city_id),icon=VALUES(icon),url=VALUES(url),main_pic=VALUES(main_pic),info=VALUES(info),update_time=VALUES(update_time)";
            $st = $target_db->prepare($sql);

            foreach ($data as $d) {

                print_r($d);
                die();
                if(empty($d['company'])){
                    $com_id = 0;
                }else{
                    $result = $target_db->query("SELECT id FROM company WHERE company_name='".addslashes($d['company'])."'")->fetchAll(PDO::FETCH_COLUMN);
                    if($result){
                        $com_id = $result[0];
                    }else{
                        $com_id = 0;
                    }  
                }

                $fund_status = $this->fundStatusForCyzone($d['financing_stage']);

                if(empty($d['location'])){
                    $province_id = 0;
                    $city_id = 0;
                }else{
                    if(mb_strpos($d['location'], ',') === false){
                        $city = $target_db->query("SELECT city_id,province_id FROM city WHERE city_name like '".$d['location']."%'")->fetchAll(PDO::FETCH_ASSOC);
                        $city_id = empty($city) ? 0 : $city[0]['city_id'];
                        $province_id = empty($city) ? 0 : $city[0]['province_id'];
                    }else{
                        $local = explode(',', $d['location']);
                        $province = $target_db->query("SELECT province_id FROM province WHERE province_name like '".$local[0]."%'")->fetchAll(PDO::FETCH_COLUMN);

                        $province_id = empty($province) ? 35 : $province[0];

                        if(in_array($local[0], array('北京','北京市','上海','上海市','天津','天津市','重庆','重庆市','香港','澳门'))){
                            $local[1] = $local[0];
                        }
                        $city = $target_db->query("SELECT city_id FROM city WHERE city_name like '".$local[1]."%'")->fetchAll(PDO::FETCH_COLUMN);
                        $city_id = empty($city) ? 0 : $city[0];
                        if($province_id == 35) $city_id = -1;

                        $d['location'] = str_replace(',','·', $d['location']);
                    } 
                }

                $url = trim($d['url'],'/');
                $date = date('Y-m-d H:i:s');

                $exists = $target_db->query("SELECT * FROM company_project WHERE project_name='".addslashes($d['project_name'])."'")->fetchAll(PDO::FETCH_ASSOC);
                if($exists && ($exists[0]['company_id'] == $com_id || $exists[0]['url'] == $d['url'])){
                    $fund_status = $exists[0]['fund_status_id'] == 0 ? $fund_status : $exists[0]['fund_status_id'];
                    $d['location'] = empty($exists[0]['location']) ? $d['location'] : $exists[0]['location'];
                    $province_id = $exists[0]['province_id'] == 0 ? $province_id : $exists[0]['province_id'];
                    $city_id = $exists[0]['city_id'] == 0 ? $city_id : $exists[0]['city_id'];
                    $d['icon'] = empty($exists[0]['icon']) ? $d['icon'] : $exists[0]['icon'];
                    $d['url'] = empty($exists[0]['url']) ? $d['url'] : $exists[0]['url'];
                    $d['intro'] = empty($exists[0]['intro']) ? $d['intro'] : $exists[0]['intro'];
                    $d['info_img'] = empty($exists[0]['main_pic']) ? $d['info_img'] : $exists[0]['main_pic'];
                }

                $st->bindParam(1,$com_id,PDO::PARAM_INT);
                $st->bindParam(2,$d['project_name'],PDO::PARAM_STR);
                $st->bindParam(3,$fund_status,PDO::PARAM_INT);
                $st->bindParam(4,$d['industry'],PDO::PARAM_STR);
                $st->bindParam(5,$d['location'],PDO::PARAM_STR);
                $st->bindParam(6,$province_id,PDO::PARAM_INT);
                $st->bindParam(7,$city_id,PDO::PARAM_INT);
                $st->bindParam(8,$d['icon'],PDO::PARAM_STR);
                $st->bindParam(9,$url,PDO::PARAM_STR);
                $st->bindParam(10,$d['info_img'],PDO::PARAM_STR);
                $st->bindParam(11,$d['intro'],PDO::PARAM_STR);
                $st->bindParam(12,$date,PDO::PARAM_STR);
                $st->execute();

                echo "Id : ".$target_db->lastInsertId()."\r\n";
            }

            echo "===============\r\n";
        }*/

        public function syncHuxiu($target_db, $dbname, $table, $field, $type = PDO::FETCH_ASSOC){
            $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field,'',$type);

            $sql = "INSERT INTO company_project(company_id,project_name,fund_status_id,industry,location,province_id,city_id,icon,url,main_pic,info,update_time) VALUES(?,?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE company_id=VALUES(company_id),fund_status_id=VALUES(fund_status_id),industry=VALUES(industry),location=VALUES(location),province_id=VALUES(province_id),city_id=VALUES(city_id),icon=VALUES(icon),url=VALUES(url),main_pic=VALUES(main_pic),info=VALUES(info),update_time=VALUES(update_time)";
            $st = $target_db->prepare($sql);

            foreach ($data as $d) {
                if(empty($d['company_name'])){
                    $com_id = 0;
                }else{
                    $result = $target_db->query("SELECT id FROM company WHERE company_name='".addslashes($d['company_name'])."'")->fetchAll(PDO::FETCH_COLUMN);
                    if($result){
                        $com_id = $result[0];
                    }else{
                        $com_id = 0;
                    }  
                }

                $fund_status = $this->fundStatusForHuxiu($d['financing_stage']);

                if(empty($d['location']) || $d['location'] == '暂无'){
                    $province_id = 0;
                    $city_id = 0;
                }else{
                    if(mb_strpos($d['location'], ' ') === false){
                        $city = $target_db->query("SELECT city_id,province_id FROM city WHERE city_name like '".$d['location']."%'")->fetchAll(PDO::FETCH_ASSOC);
                        $city_id = empty($city) ? 0 : $city[0]['city_id'];
                        $province_id = empty($city) ? 0 : $city[0]['province_id'];
                    }else{
                        $local = explode(' ', $d['location']);
                        $province = $target_db->query("SELECT province_id FROM province WHERE province_name like '".$local[0]."%'")->fetchAll(PDO::FETCH_COLUMN);

                        $province_id = empty($province) ? 35 : $province[0];

                        if(in_array($local[0], array('北京','北京市','上海','上海市','天津','天津市','重庆','重庆市','香港','澳门'))){
                            $local[1] = $local[0];
                        }
                        $city = $target_db->query("SELECT city_id FROM city WHERE city_name like '".$local[1]."%'")->fetchAll(PDO::FETCH_COLUMN);
                        $city_id = empty($city) ? 0 : $city[0];

                        $d['location'] = str_replace(' ','·', $d['location']);
                    }
                      
                }

                $pic = json_decode($d['gallery_list'],true);
                if($pic){
                    $pic = implode(',', $pic);
                }else{
                    $pic = '';
                }

                $url = trim($d['url'],'/');
                $date = date('Y-m-d H:i:s');

                $exists = $target_db->query("SELECT * FROM company_project WHERE project_name='".addslashes($d['project_name'])."'")->fetchAll(PDO::FETCH_ASSOC);
                if($exists){
                    $com_id = $exists[0]['company_id'] == 0 ? $com_id : $exists[0]['company_id'];
                    $fund_status = $exists[0]['fund_status_id'] == 0 ? $fund_status : $exists[0]['fund_status_id'];
                    $d['tag'] = empty($exists[0]['industry']) ? $d['tag'] : $exists[0]['industry'];
                    $d['location'] = empty($exists[0]['location']) ? $d['location'] : $exists[0]['location'];
                    $province_id = $exists[0]['province_id'] == 0 ? $province_id : $exists[0]['province_id'];
                    $city_id = $exists[0]['city_id'] == 0 ? $city_id : $exists[0]['city_id'];
                    $d['icon'] = empty($exists[0]['icon']) ? $d['icon'] : $exists[0]['icon'];
                    $d['url'] = empty($exists[0]['url']) ? $d['url'] : $exists[0]['url'];
                    $d['intro_info'] = empty($exists[0]['intro']) ? $d['intro_info'] : $exists[0]['intro'];
                    $pic = empty($exists[0]['main_pic']) ? $pic : $exists[0]['main_pic'];
                }

                $st->bindParam(1,$com_id,PDO::PARAM_INT);
                $st->bindParam(2,$d['project_name'],PDO::PARAM_STR);
                $st->bindParam(3,$fund_status,PDO::PARAM_INT);
                $st->bindParam(4,$d['tag'],PDO::PARAM_STR);
                $st->bindParam(5,$d['location'],PDO::PARAM_STR);
                $st->bindParam(6,$province_id,PDO::PARAM_INT);
                $st->bindParam(7,$city_id,PDO::PARAM_INT);
                $st->bindParam(8,$d['icon'],PDO::PARAM_STR);
                $st->bindParam(9,$url,PDO::PARAM_STR);
                $st->bindParam(10,$pic,PDO::PARAM_STR);
                $st->bindParam(11,$d['intro_info'],PDO::PARAM_STR);
                $st->bindParam(12,$date,PDO::PARAM_STR);
                $st->execute();

                echo "Id : ".$target_db->lastInsertId()."\r\n";
            }

            echo "===============\r\n";
        }

        public function syncAngel($target_db, $dbname, $table, $field, $type = PDO::FETCH_ASSOC){
            $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field,'',$type);

            $sql = "INSERT INTO company_project(company_id,project_name,industry,location,province_id,city_id,icon,url,main_pic,info,update_time) VALUES(?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE company_id=VALUES(company_id),industry=VALUES(industry),location=VALUES(location),province_id=VALUES(province_id),city_id=VALUES(city_id),icon=VALUES(icon),url=VALUES(url),main_pic=VALUES(main_pic),info=VALUES(info),update_time=VALUES(update_time)";
            $st = $target_db->prepare($sql);

            foreach ($data as $d) {
                if(empty($d['org_name'])){
                    $com_id = 0;
                }else{
                    $result = $target_db->query("SELECT id FROM company WHERE company_name='".addslashes($d['org_name'])."'")->fetchAll(PDO::FETCH_COLUMN);
                    if($result){
                        $com_id = $result[0];
                    }else{
                        $com_id = 0;
                    }  
                }

                if(empty($d['province'])){
                    $province_id = 0;
                    $city = 0;
                    if(!empty($d['city'])){
                        $city = $target_db->query("SELECT city_id,province_id FROM city WHERE city_name like '".$d['city']."%'")->fetchAll(PDO::FETCH_ASSOC);
                        $city_id = empty($city) ? 0 : $city[0]['city_id'];
                        $province_id = empty($city) ? 0 : $city[0]['province_id'];
                    }

                    $location = !empty($d['city']) ? $d['city'] : '';
                }else{
                    $province = $target_db->query("SELECT province_id FROM province WHERE province_name like '".$d['province']."%'")->fetchAll(PDO::FETCH_COLUMN);

                    $province_id = empty($province) ? 35 : $province[0];

                    if(in_array($d['province'], array('北京','北京市','上海','上海市','天津','天津市','重庆','重庆市','香港','澳门'))){
                        $city = $target_db->query("SELECT city_id FROM city WHERE city_name like '".$d['province']."%'")->fetchAll(PDO::FETCH_COLUMN);
                    }else{
                        $city = $target_db->query("SELECT city_id FROM city WHERE city_name like '".$d['city']."%'")->fetchAll(PDO::FETCH_COLUMN);
                    }
                    $city_id = empty($city) ? 0 : $city[0];

                    $location = $d['province'].'·'.$d['city'];    
                }


                $logo = $d['logo_id'] ? 'http://fs.angelcrunch.com/IMG/'.$d['logo_id'] : '';
                $pic = json_decode($d['pic'],true);
                if($pic){
                    $pic_file = array_column($pic,'filename');
                    foreach ($pic_file as $k=> $v) {
                        $pic_file[$k] = 'http://fs.angelcrunch.com/IMG/'.$v;
                    }

                    $pic = implode(',', $pic_file);
                }else{
                    $pic = '';
                }

                $url = trim($d['url'],'/');
                $date = date('Y-m-d H:i:s');

                $exists = $target_db->query("SELECT * FROM company_project WHERE project_name='".addslashes($d['proj_name'])."'")->fetchAll(PDO::FETCH_ASSOC);
                if($exists){
                    $com_id = $exists[0]['company_id'] == 0 ? $com_id : $exists[0]['company_id'];
                    $d['industry'] = empty($exists[0]['industry']) ? $d['industry'] : $exists[0]['industry'];
                    $location = empty($exists[0]['location']) ? $location : $exists[0]['location'];
                    $province_id = $exists[0]['province_id'] == 0 ? $province_id : $exists[0]['province_id'];
                    $city_id = $exists[0]['city_id'] == 0 ? $city_id : $exists[0]['city_id'];
                    $logo = empty($exists[0]['icon']) ? $logo : $exists[0]['icon'];
                    $d['url'] = empty($exists[0]['url']) ? $d['url'] : $exists[0]['url'];
                    $d['description'] = empty($exists[0]['intro']) ? $d['description'] : $exists[0]['intro'];
                    $pic = empty($exists[0]['main_pic']) ? $pic : $exists[0]['main_pic'];
                }

                $st->bindParam(1,$com_id,PDO::PARAM_INT);
                $st->bindParam(2,$d['proj_name'],PDO::PARAM_STR);
                $st->bindParam(3,$d['industry'],PDO::PARAM_STR);
                $st->bindParam(4,$location,PDO::PARAM_STR);
                $st->bindParam(5,$province_id,PDO::PARAM_INT);
                $st->bindParam(6,$city_id,PDO::PARAM_INT);
                $st->bindParam(7,$logo,PDO::PARAM_STR);
                $st->bindParam(8,$url,PDO::PARAM_STR);
                $st->bindParam(9,$pic,PDO::PARAM_STR);
                $st->bindParam(10,$d['description'],PDO::PARAM_STR);
                $st->bindParam(11,$date,PDO::PARAM_STR);
                $st->execute();

                echo "Id : ".$target_db->lastInsertId()."\r\n";
            }

            echo "===============\r\n";
        }

        public function syncVc($target_db, $dbname, $table, $field, $type = PDO::FETCH_ASSOC){
            $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field,'',$type);

            $sql = "INSERT INTO company_project(company_id,project_name,fund_status_id,industry,location,province_id,city_id,icon,url,main_pic,info,update_time) VALUES(?,?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE company_id=VALUES(company_id),fund_status_id=VALUES(fund_status_id),industry=VALUES(industry),location=VALUES(location),province_id=VALUES(province_id),city_id=VALUES(city_id),icon=VALUES(icon),url=VALUES(url),main_pic=VALUES(main_pic),info=VALUES(info),update_time=VALUES(update_time)";
            $st = $target_db->prepare($sql);

            foreach ($data as $d) {
                if(empty($d['company_name'])){
                    $com_id = 0;
                }else{
                    $result = $target_db->query("SELECT id FROM company WHERE company_name='".addslashes($d['company_name'])."'")->fetchAll(PDO::FETCH_COLUMN);
                    if($result){
                        $com_id = $result[0];
                    }else{
                        $com_id = 0;
                    }  
                }

                $fund_status = $this->fundStatusNum($d['stage']);

                if(empty($d['local'])){
                    $province_id = 0;
                    $city_id = 0;
                }else{
                    if(mb_strpos($d['local'], ' · ') === false){
                        $province = $target_db->query("SELECT province_id FROM province WHERE province_name like '".$d['local']."%'")->fetchAll(PDO::FETCH_COLUMN);

                        $province_id = empty($province) ? 35 : $province[0];

                        if(in_array($d['local'], array('北京','北京市','上海','上海市','天津','天津市','重庆','重庆市','香港','澳门'))){
                            $city = $target_db->query("SELECT city_id FROM city WHERE city_name like '".$d['local']."%'")->fetchAll(PDO::FETCH_COLUMN);
                            $city_id = empty($city) ? 0 : $city[0];
                        }
                        
                    }else{
                        $local = explode(' · ', $d['local']);
                        $province = $target_db->query("SELECT province_id FROM province WHERE province_name like '".$local[0]."%'")->fetchAll(PDO::FETCH_COLUMN);

                        $province_id = empty($province) ? 35 : $province[0];

                        if(in_array($local[0], array('北京','北京市','上海','上海市','天津','天津市','重庆','重庆市','香港','澳门'))){
                            $local[1] = $local[0];
                        }
                        $city = $target_db->query("SELECT city_id FROM city WHERE city_name like '".$local[1]."%'")->fetchAll(PDO::FETCH_COLUMN);
                        $city_id = empty($city) ? 0 : $city[0];
                    }
                      
                }

                $pic = json_decode($d['pic'],true);
                if($pic){
                    $pic = implode(',', $pic);
                }else{
                    $pic = '';
                }

                $url = trim($d['url'],'/');
                $date = date('Y-m-d H:i:s');

                $exists = $target_db->query("SELECT * FROM company_project WHERE project_name='".addslashes($d['project_name'])."'")->fetchAll(PDO::FETCH_ASSOC);
                if($exists){
                    $com_id = $exists[0]['company_id'] == 0 ? $com_id : $exists[0]['company_id'];
                    $fund_status = $exists[0]['fund_status_id'] == 0 ? $fund_status : $exists[0]['fund_status_id'];
                    $d['industry'] = empty($exists[0]['industry']) ? $d['industry'] : $exists[0]['industry'];
                    $d['local'] = empty($exists[0]['location']) ? $d['local'] : $exists[0]['location'];
                    $province_id = $exists[0]['province_id'] == 0 ? $province_id : $exists[0]['province_id'];
                    $city_id = $exists[0]['city_id'] == 0 ? $city_id : $exists[0]['city_id'];
                    $d['logo'] = empty($exists[0]['icon']) ? $d['logo'] : $exists[0]['icon'];
                    $d['url'] = empty($exists[0]['url']) ? $d['url'] : $exists[0]['url'];
                    $d['intro'] = empty($exists[0]['intro']) ? $d['intro'] : $exists[0]['intro'];
                    $pic = empty($exists[0]['main_pic']) ? $pic : $exists[0]['main_pic'];
                }

                $st->bindParam(1,$com_id,PDO::PARAM_INT);
                $st->bindParam(2,$d['project_name'],PDO::PARAM_STR);
                $st->bindParam(3,$fund_status,PDO::PARAM_INT);
                $st->bindParam(4,$d['industry'],PDO::PARAM_STR);
                $st->bindParam(5,$d['local'],PDO::PARAM_STR);
                $st->bindParam(6,$province_id,PDO::PARAM_INT);
                $st->bindParam(7,$city_id,PDO::PARAM_INT);
                $st->bindParam(8,$d['logo'],PDO::PARAM_STR);
                $st->bindParam(9,$url,PDO::PARAM_STR);
                $st->bindParam(10,$pic,PDO::PARAM_STR);
                $st->bindParam(11,$d['intro'],PDO::PARAM_STR);
                $st->bindParam(12,$date,PDO::PARAM_STR);
                $st->execute();

                echo "Id : ".$target_db->lastInsertId()."\r\n";
            }

            echo "===============\r\n";
        }
    
        public function databaseObj($dbname,$host = '127.0.0.1',$user = 'root',$password = 'root'){
            $db=new PDO('mysql:dbname='.$dbname.';host='.$host,$user,$password);
            $db->exec("set names utf8");

            return $db;
        }

        public function selectData($db, $table, $field, $where = '', $type = PDO::FETCH_COLUMN){
            $data = $db->query("SELECT ".$field." FROM ".$table." ".$where)->fetchAll($type); 
            
            return $data;
        }

        //获取获投状态
        private function fundStatusNum($fund_status){
            switch ($fund_status) {
                case '尚未获投':
                    return 1;
                    break;
                case '种子轮':
                    return 2;
                    break;
                case '天使轮':
                    return 3;
                    break;
                case 'Pre-A轮':
                    return 4;
                    break;
                case 'A轮':
                    return 5;
                    break;
                case 'A+轮':
                    return 6;
                    break;
                case 'Pre-B轮':
                    return 7;
                    break;
                case 'B轮':
                    return 8;
                    break;
                case 'B+轮':
                    return 9;
                    break;
                case 'C轮':
                    return 10;
                    break;
                case 'D轮':
                    return 11;
                    break;
                case 'E轮':
                    return 12;
                    break;
                case 'F轮-上市前':
                    return 13;
                    break;
                case '已上市':
                    return 14;
                    break;
                case '已被收购':
                    return 15;
                    break;
                default:
                    return 0;
                    break;
            }
        }

        //获取获投36KR状态
        private function fundStatusFor36kr($fund_status){

            switch ($fund_status) {
                case '未融资':
                    return 1;
                    break;
                case '种子轮':
                    return 2;
                    break;
                case '天使轮':
                    return 3;
                    break;
                case 'Pre-A轮':
                    return 4;
                    break;
                case 'A轮':
                    return 5;
                    break;
                case 'A+轮':
                    return 6;
                    break;
                case 'Pre-B轮':
                    return 7;
                    break;
                case 'B轮':
                    return 8;
                    break;
                case 'B+轮':
                    return 9;
                    break;
                case 'C轮':
                    return 10;
                    break;
                case 'D轮':
                    return 11;
                    break;
                case 'E轮及以后':
                    return 12;
                    break;
                case 'F轮-上市前':
                    return 13;
                    break;
                case '上市':
                    return 14;
                    break;
                case '并购':
                    return 15;
                    break;
                default:
                    return 0;
                    break;
            }
        }

        //获取获投拉勾网状态
        private function fundStatusForLagou($fund_status){

            switch ($fund_status) {
                case '未融资':
                    return 1;
                    break;
                case '不需要融资':
                    return 1;
                    break;
                case 'No financing':
                    return 1;
                    break;
                case '种子轮':
                    return 2;
                    break;
                case '天使轮':
                    return 3;
                    break;
                case 'Angel round':
                    return 3;
                    break;
                case 'Pre-A轮':
                    return 4;
                    break;
                case 'A轮':
                    return 5;
                    break;
                case 'A round':
                    return 5;
                    break;
                case 'A+轮':
                    return 6;
                    break;
                case 'Pre-B轮':
                    return 7;
                    break;
                case 'B轮':
                    return 8;
                    break;
                case 'B 轮':
                    return 8;
                    break;
                case 'B+轮':
                    return 9;
                    break;
                case 'C轮':
                    return 10;
                    break;
                case 'D轮及以上':
                    return 11;
                    break;
                case 'E轮及以后':
                    return 12;
                    break;
                case 'F轮-上市前':
                    return 13;
                    break;
                case '上市公司':
                    return 14;
                    break;
                case '并购':
                    return 15;
                    break;
                default:
                    return 0;
                    break;
            }
        }

        //获取获投天天投状态
        private function fundStatusForEvervc($fund_status){
            switch ($fund_status) {
                case '未融资':
                    return 1;
                    break;
                case '种子轮':
                    return 2;
                    break;
                case '天使轮':
                    return 3;
                    break;
                case 'Pre-A轮':
                    return 4;
                    break;
                case 'A轮':
                    return 5;
                    break;
                case 'A+轮':
                    return 6;
                    break;
                case 'Pre-B轮':
                    return 7;
                    break;
                case 'B轮':
                    return 8;
                    break;
                case 'B+轮':
                    return 9;
                    break;
                case 'C轮':
                    return 10;
                    break;
                case 'D轮':
                    return 11;
                    break;
                case 'E轮':
                    return 12;
                    break;
                case 'F轮':
                    return 13;
                    break;
                case 'F轮':
                    return 13;
                    break;
                case 'PreIPO':
                    return 13;
                    break;
                case 'IPO及以后':
                    return 14;
                    break;
                case '被收购':
                    return 15;
                    break;
                default:
                    return 0;
                    break;
            }
        }

        //获取获投创业邦状态
        private function fundStatusForCyzone($fund_status){
            switch ($fund_status) {
                case '尚未获投':
                    return 1;
                    break;
                case '种子轮':
                    return 2;
                    break;
                case '天使轮':
                    return 3;
                    break;
                case 'Pre-A':
                    return 4;
                    break;
                case 'A轮':
                    return 5;
                    break;
                case 'A+轮':
                    return 6;
                    break;
                case 'Pre-B轮':
                    return 7;
                    break;
                case 'B轮':
                    return 8;
                    break;
                case 'B+轮':
                    return 9;
                    break;
                case 'C轮':
                    return 10;
                    break;
                case 'D轮':
                    return 11;
                    break;
                case 'E轮':
                    return 12;
                    break;
                case 'Pre-IPO':
                    return 13;
                    break;
                case 'IPO':
                    return 14;
                    break;
                case '并购':
                    return 15;
                    break;
                default:
                    return 0;
                    break;
            }
        }

        //获取获投创业邦状态
        private function fundStatusForHuxiu($fund_status){
            switch ($fund_status) {
                case '未融资':
                    return 1;
                    break;
                case '种子轮':
                    return 2;
                    break;
                case '天使轮':
                    return 3;
                    break;
                case 'Pre-A':
                    return 4;
                    break;
                case 'A轮':
                    return 5;
                    break;
                case 'A+轮':
                    return 6;
                    break;
                case 'Pre-B轮':
                    return 7;
                    break;
                case 'B轮':
                    return 8;
                    break;
                case 'B+轮':
                    return 9;
                    break;
                case 'C轮':
                    return 10;
                    break;
                case 'D轮':
                    return 11;
                    break;
                case 'E轮':
                    return 12;
                    break;
                case 'Pre-IPO':
                    return 13;
                    break;
                case 'IPO':
                    return 14;
                    break;
                case '并购':
                    return 15;
                    break;
                default:
                    return 0;
                    break;
            }
        }
    }