<?php
    class Evervc{
        public function project(){
            $db=new PDO('mysql:dbname=evervc_project;host=127.0.0.1','root','root');
            $db->exec("set names utf8");

            $cache = CACHE_PATH . '/evervc/project/';

            $ids = $db->query("SELECT DISTINCT url FROM evervc_url_list ORDER BY id ASC")->fetchAll(PDO::FETCH_COLUMN);

            $sql = "INSERT INTO evervc_project(project_html_id,project_name,logo,intro,pic,tags,location,status,stage,company,company_info,url,address,video,funding,team,milestone,update_time) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE update_time=VALUES(update_time)";
            $st = $db->prepare($sql);

            foreach ($ids as $k => $i) {
                $arr = explode('/', $i);
                $file = $cache.end($arr).'.html';

                $html = toUtf8(read($file));
                $info = $this->getProjectInfo($html);

                if(!isset($info['tags'])) continue;
                 
                $id = end($arr);
                $pic = json_encode($info['pic']);
                $tags = implode(',', $info['tags']);

                $team = json_encode($info['team']);
                $milestone = json_encode($info['milestone']);
                $financing = json_encode($info['funding']);
                $date = date('Y-m-d H:i:s');

                $st->bindParam(1,$id,PDO::PARAM_INT);
                $st->bindParam(2,$info['project_name'],PDO::PARAM_STR);
                $st->bindParam(3,$info['logo'],PDO::PARAM_STR);
                $st->bindParam(4,$info['intro'],PDO::PARAM_STR);
                $st->bindParam(5,$pic,PDO::PARAM_STR);
                $st->bindParam(6,$tags,PDO::PARAM_STR);
                $st->bindParam(7,$info['location'],PDO::PARAM_STR);
                $st->bindParam(8,$info['status'],PDO::PARAM_STR);
                $st->bindParam(9,$info['stage'],PDO::PARAM_STR);
                $st->bindParam(10,$info['company'],PDO::PARAM_STR);
                $st->bindParam(11,$info['company_info'],PDO::PARAM_STR);
                $st->bindParam(12,$info['url'],PDO::PARAM_STR);
                $st->bindParam(13,$info['address'],PDO::PARAM_STR);
                $st->bindParam(14,$info['video'],PDO::PARAM_STR);
                $st->bindParam(15,$financing,PDO::PARAM_STR);
                $st->bindParam(16,$team,PDO::PARAM_STR);
                $st->bindParam(17,$milestone,PDO::PARAM_STR);
                $st->bindParam(18,$date,PDO::PARAM_STR);

                $st->execute();
                $return = $db->lastInsertId();
                echo "id : ".$return."\r\n";

            }
        }

        public function invest(){
            $db=new PDO('mysql:dbname=evervc_project;host=127.0.0.1','root','root');
            $db->exec("set names utf8");
            $cache = CACHE_PATH . '/evervc/invest/';

            $sql = "INSERT INTO invest(project_name,industry,stage,amount,investors,update_time) VALUES(:pro,:ind,:sta,:amo,:inv,:upd) ON DUPLICATE KEY UPDATE industry=VALUES(industry),stage=VALUES(stage),amount=VALUES(amount),investors=VALUES(investors),update_time=VALUES(update_time)";

            $st = $db->prepare($sql);

            $res = $db->query("SELECT * FROM invest_list ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);

            foreach ($res as $re) {
                for($i = 1; $i <= $re['page']; $i ++) {
                    $file = $cache.$re['cate_id'].'_'.$i.'.html';
                    if(!file_exists($file)) continue;

                    $html = toUtf8(read($file));
                    $info = $this->getInvestList($html);
                    
                    foreach ($info as $in) {
                        $st->bindParam(':pro',$in['project_name']);
                        $st->bindParam(':ind',$re['name']);
                        $st->bindParam(':sta',$in['stage']);
                        $st->bindParam(':amo',$in['amount']);
                        $st->bindParam(':inv',$in['investors']);
                        $st->bindParam(':upd',$in['date']);

                        $st->execute();
                        $return = $db->lastInsertId();
                        echo "id : ".$return."\r\n";
                    }
                }
            }
        }

        //提取信息
        private function getProjectInfo($html){
            $info = array();
            $dom = phpQuery::newDocumentHTML($html);

            $info['project_name'] = trim(pq($dom['a.projectTitle'])->text());
            $info['intro'] = trim(pq($dom['p.projectTip'])->text());
            $info['logo'] = trim(pq($dom['.projectLogo img'])->attr('src'));
            
            $tags = $dom['.headTagUl li'];
            foreach ($tags as $tag) {
                $info['tags'][] = trim(pq($tag)->find('a')->text());
            }

            $info['location'] = trim(pq($dom['p.location a'])->text());

            $info['video'] = pq($dom['li .p_btn_product_video_thumb'])->attr('href');

            $imgs = $dom['ul.thumbnailUL li'];
            $info['pic'] = array();
            foreach ($imgs as $img) {
                $info['pic'][] = pq($img)->find('a')->attr('href');
            }

            $info['status'] = trim(pq($dom['.stageInfo h2'])->text());
            $info['stage'] = '';
            $info['company'] = trim(pq($dom['#panel_company h3:eq(1)'])->text());
            $info['company_info'] = trim(pq($dom['#panel_company p'])->text());
            $info['url'] = trim(pq($dom['#panel_company span.companySpan a'])->attr('href'));

            $address = trim(pq($dom['#panel_company span.companySpan:first'])->text());
            $info['address'] = mb_strpos($address, '公司地址：') !== false ? trim($address,'公司地址：') : '';

            $list = $dom['.funding-info tbody tr'];
            $info['funding'] = array();
            foreach ($list as $k => $li) {
                $info['funding'][$k]['stage'] = trim(pq($li)->find('td:first')->text());
                $info['funding'][$k]['amount'] = trim(pq($li)->find('td.amount')->text());

                if($k == 0) $info['stage'] = $info['funding'][$k]['stage'];

                $investors = pq($li)->find('td.investor a');
                $info['funding'][$k]['investor'] = array();
                foreach ($investors as $investor) {
                    $info['funding'][$k]['investor'][] = trim(pq($investor)->text()); 
                }
                $info['funding'][$k]['investor'] = $info['funding'][$k]['investor'] ? implode('、',$info['funding'][$k]['investor']) : '未公开';
                $info['funding'][$k]['date'] = date('Y.m.d',strtotime(trim(pq($li)->find('td.date')->text())));
            }


            $list = $dom['.teamCon .membersList'];
            $info['team'] = array();
            foreach ($list as $k => $li) {
                $info['team'][$k]['name'] = trim(pq($li)->find('.membersInfo h3')->text());
                $info['team'][$k]['job'] = trim(pq($li)->find('.membersInfo p.title')->text());
                $info['team'][$k]['info'] = trim(pq($li)->find('.membersInfo p.txt')->text());
                $info['team'][$k]['photo'] = trim(pq($li)->find('.membersPhoto img')->attr('src'));
            }

            $list = $dom['#panel_milestone div.timelineGroup'];
            foreach ($list as $k => $li) {
                $info['milestone'][$k]['title'] = trim(pq($li)->find('div.timelineInfo')->text());
                $info['milestone'][$k]['type'] = trim(pq($li)->find('div.iconOther')->attr('title'));
                $info['milestone'][$k]['time'] = $this->string2Dot(trim(pq($li)->find('div.time')->text()));
            }
            $info['milestone'] = isset($info['milestone']) ? $info['milestone'] : '';

            $dom -> unloadDocument();

            return $info;
        }

        //提取融资事件列表
        private function getInvestList($html){
            $info = array();
            $dom = phpQuery::newDocumentHTML($html);

            $list = $dom['ul.eventset-list li'];
            foreach ($list as $k => $li) {
                $info[$k]['date'] = trim(pq($li)->find('i.date')->text());
                $info[$k]['project_name'] = trim(pq($li)->find('.commpany span.name')->text());
                $info[$k]['stage'] = trim(pq($li)->find('i.round')->text());
                     
                $info[$k]['amount'] = trim(pq($li)->find('i.amount')->text());

                $info[$k]['investors'] = [];
                $investors = pq($li)->find('i.investor a');
                foreach ($investors as $investor) {
                    $info[$k]['investors'][] = trim(pq($investor)->text());
                }

                $info[$k]['investors'] = $info[$k]['investors'] ? implode(',', $info[$k]['investors']) : NULL;
            }
            $dom -> unloadDocument();

            return $info; 
        }

        private function string2Dot($str){
            $arr = array(
                    '年' => '.',
                    '月' => '.',
                    '日' => ''
                );
            return strtr($str,$arr);
        }
    }