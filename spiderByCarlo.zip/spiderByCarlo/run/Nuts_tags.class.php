<?php 
    // IT桔子>36kr>拉勾网>天天投>创业邦>猎云>虎嗅>天使汇>创投圈
    class Nuts_tags{

        public function go(){
            $target_db = $this->databaseObj('nuts_tool');
            //IT桔子
            $this->syncCommon($target_db, 'itjuzi_project','itjuzi_project','tags');
           
            //36kr
            $this->syncCommon($target_db, '36kr_project','36kr_project','tags');

            //天天投
            $this->syncCommon($target_db,'evervc_project','evervc_project','tags');
            
            //创业邦
            $this->syncCommon($target_db,'cyzone_project','cyzone_project','industry');
            
            //猎云网
            $this->syncCommon($target_db,'other_project','lieyun_project','domain_name');
            
            //虎嗅网
            $this->syncCommon($target_db,'other_project','huxiu_project','tag');
            
            //天使汇
            $this->syncAngel($target_db,'angel_project','angel_project','industry');
            
            //创投圈
            $this->syncCommon($target_db,'vc_project','vc_project','industry');
            
            //拉勾网
            $this->syncCommon($target_db,'lagou_project','lagou_project','industry');
        }

/*
 * --------------------------------------------分割线------------------------------------------------------
 * 自定义相关函数
 */
        public function syncCommon($target_db, $dbname, $table, $field, $type = PDO::FETCH_COLUMN){
            $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field,'',$type);

            $sql = "INSERT INTO tags(name) VALUES(?)";
            $st = $target_db->prepare($sql);
            foreach ($data as $d) {
                if(empty($d)) continue;
                $tags = explode(',', $d);

                foreach ($tags as $tag) {
                    $result = $target_db->query("SELECT id FROM tags WHERE name='".addslashes($tag)."'")->fetchAll(PDO::FETCH_COLUMN);
                    if($result) continue;
                    if(preg_match("/^\d*$/",$tag)) continue;

                    $st->bindParam(1,$tag,PDO::PARAM_STR);
                    $st->execute();
                    echo "id : ".$target_db->lastInsertId()."\r\n";
                } 
            }
            echo "===============\r\n";
        }
    
        public function syncAngel($target_db, $dbname, $table, $field, $type = PDO::FETCH_COLUMN){
            $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field,'',$type);

            $sql = "INSERT INTO tags(name) VALUES(?)";
            $st = $target_db->prepare($sql);
            foreach ($data as $d) {
                if(empty($d)) continue;
                $tags = explode(' · ', $d);

                foreach ($tags as $tag) {
                    $result = $target_db->query("SELECT id FROM tags WHERE name='".addslashes($tag)."'")->fetchAll(PDO::FETCH_COLUMN);
                    if($result) continue;
                    if(preg_match("/^\d*$/",$tag)) continue;

                    $st->bindParam(1,$tag,PDO::PARAM_STR);
                    $st->execute();
                    echo "id : ".$target_db->lastInsertId()."\r\n";
                } 
            }
            echo "===============\r\n";
        }
    
        public function databaseObj($dbname,$host = '127.0.0.1',$user = 'root',$password = 'root'){
            $db=new PDO('mysql:dbname='.$dbname.';host='.$host,$user,$password);
            $db->exec("set names utf8");

            return $db;
        }

        public function selectData($db, $table, $field, $where = '', $type = PDO::FETCH_COLUMN){
            $data = $db->query("SELECT ".$field." FROM ".$table." ".$where)->fetchAll($type); 
            
            return $data;
        }
    }