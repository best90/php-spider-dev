<?php
    class Kr36{
        public function project(){
            $db=new PDO('mysql:dbname=36kr_project;host=127.0.0.1','root','root');
            $db->exec("set names utf8");

            $cache = CACHE_PATH . '/36kr/company/';

            $founder_cache = CACHE_PATH . '/36kr/founder/';
            $finance_cache = CACHE_PATH . '/36kr/finance/';
            $former_cache = CACHE_PATH . '/36kr/member/';
            $team_cache = CACHE_PATH . '/36kr/employee/';
            $feed_cache = CACHE_PATH . '/36kr/feed/';
            $com_cache = CACHE_PATH . '/36kr/qichacha/';

            $config = array(
                    'industry' => '[{"desc":"电子商务","id":1,"value":"E_COMMERCE"},{"desc":"社交网络","id":2,"value":"SOCIAL_NETWORK"},{"desc":"智能硬件","id":5,"value":"INTELLIGENT_HARDWARE"},{"desc":"媒体门户","id":6,"value":"MEDIA"},{"desc":"工具软件","id":7,"value":"SOFTWARE"},{"desc":"消费生活","id":8,"value":"CONSUMER_LIFESTYLE"},{"desc":"金融","id":9,"value":"FINANCE"},{"desc":"医疗健康","id":10,"value":"MEDICAL_HEALTH"},{"desc":"企业服务","id":11,"value":"SERVICE_INDUSTRIES"},{"desc":"旅游户外","id":12,"value":"TRAVEL_OUTDOORS"},{"desc":"房产家居","id":13,"value":"PROPERTY_AND_HOME_FURNISHINGS"},{"desc":"数字娱乐","id":14,"value":"CULTURE_SPORTS_ART"},{"desc":"在线教育","id":15,"value":"EDUCATION_TRAINING"},{"desc":"汽车交通","id":16,"value":"AUTO"},{"desc":"移动互联网","id":17,"value":"MOBILE_INTERNET"},{"desc":"O2O","id":18,"value":"O2O"},{"desc":"物流","id":19,"value":"LOGISTICS"},{"desc":"其他","id":0,"value":"OTHER"},{"desc":"电子商务","id":1,"value":"E_COMMERCE"},{"desc":"社交网络","id":2,"value":"SOCIAL_NETWORK"},{"desc":"智能硬件","id":5,"value":"INTELLIGENT_HARDWARE"},{"desc":"媒体门户","id":6,"value":"MEDIA"},{"desc":"工具软件","id":7,"value":"SOFTWARE"},{"desc":"消费生活","id":8,"value":"CONSUMER_LIFESTYLE"},{"desc":"金融","id":9,"value":"FINANCE"},{"desc":"医疗健康","id":10,"value":"MEDICAL_HEALTH"},{"desc":"企业服务","id":11,"value":"SERVICE_INDUSTRIES"},{"desc":"旅游户外","id":12,"value":"TRAVEL_OUTDOORS"},{"desc":"房产家居","id":13,"value":"PROPERTY_AND_HOME_FURNISHINGS"},{"desc":"数字娱乐","id":14,"value":"CULTURE_SPORTS_ART"},{"desc":"在线教育","id":15,"value":"EDUCATION_TRAINING"},{"desc":"汽车交通","id":16,"value":"AUTO"},{"desc":"其他","id":0,"value":"OTHER"},{"desc":"物流","id":19,"value":"LOGISTICS"},{"desc":"非TMT","id":20,"value":"NON_TMT"}]',
                    'type' => '[{"desc":"创始人","id":"101","value":"FOUNDER"},{"desc":"联合创始人","id":"102","value":"CO_FOUNDER"},{"desc":"技术","id":"103","value":"TECH"},{"desc":"设计","id":"104","value":"DESIGN"},{"desc":"产品","id":"105","value":"PRODUCT"},{"desc":"运营","id":"106","value":"OPERATOR"},{"desc":"市场与销售","id":"107","value":"SALE"},{"desc":"行政、人事及财务","id":"108","value":"HR"},{"desc":"投资和并购","id":"109","value":"INVEST"},{"desc":"其他","id":"110","value":"OTHER"}]',
                    'stage' => '[{"desc":"未知轮次","id":"-100","value":"UNKNOWN"},{"desc":"非正式轮次","id":"-50","value":"INFORMAL"},{"desc":"未融资","id":"0","value":"NONE"},{"desc":"天使轮","id":"10","value":"ANGEL"},{"desc":"Pre-A轮","id":"20","value":"PRE_A"},{"desc":"A轮","id":"30","value":"A"},{"desc":"A+轮","id":"35","value":"A_PLUS"},{"desc":"B轮","id":"40","value":"B"},{"desc":"B+轮","id":"45","value":"B_PLUS"},{"desc":"C轮","id":"50","value":"C"},{"desc":"D轮","id":"60","value":"D"},{"desc":"E轮及以后","id":"70","value":"E"},{"desc":"并购","id":"100","value":"ACQUIRED"},{"desc":"上市","id":"110","value":"IPO"}]',
                    'feedType' => '[{"key":"0","value":"全部"},{"key":"201","value":"资本"},{"key":"205","value":"产品"},{"key":"204","value":"人员"},{"key":"202","value":"数据"},{"key":"203","value":"报道"}]',
                );
            $type = $this->getMap($config['type']);
            $industry = $this->getMap($config['industry']);
            $stage = $this->getMap($config['stage']);
            $feedType = $this->getMap($config['feedType'], 'key','value');

            $res = $db->query("SELECT id,name FROM 36kr_city_data ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);
            $city = array();
            foreach ($res as $re) {
                $city[$re['id']] = $re['name'];
            }

            $ids = $db->query("SELECT company_id FROM 36kr_list ORDER BY id ASC")->fetchAll(PDO::FETCH_COLUMN);

            $sql = "INSERT INTO 36kr_project(project_html_id,project_name,logo,brief,intro,industry,address1,address2,address3,tags,pictures,com_type,advantage,data_light,story,website,weblink,weixin,weibo,iphone,ipad,android,founder,team,former_member,funding,news,company_info,update_time) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE project_name=VALUES(project_name),logo=VALUES(logo),brief=VALUES(brief),intro=VALUES(intro),industry=VALUES(industry),address1=VALUES(address1),address2=VALUES(address2),address3=VALUES(address3),tags=VALUES(tags),pictures=VALUES(pictures),com_type=VALUES(com_type),advantage=VALUES(advantage),data_light=VALUES(data_light),story=VALUES(story),website=VALUES(website),weblink=VALUES(weblink),weixin=VALUES(weixin),weibo=VALUES(weibo),iphone=VALUES(iphone),ipad=VALUES(ipad),android=VALUES(android),founder=VALUES(founder),team=VALUES(team),former_member=VALUES(former_member),funding=VALUES(funding),news=VALUES(news),company_info=VALUES(company_info),update_time=VALUES(update_time)";
            $st = $db->prepare($sql);

            foreach ($ids as $i) {
                $file = $cache.$i.'.txt';
                $finance_file = $finance_cache.$i.'.txt';
                $founder_file = $founder_cache.$i.'.txt';
                $former_file = $former_cache.$i.'.txt';
                $feed_file = $feed_cache.$i.'.txt';
                $com_file = $com_cache.$i.'.txt';
                $team_file = $team_cache.$i.'.txt';

                if(!file_exists($file)) continue;
                $company_text = file_get_contents($file);
                $finance_text = file_get_contents($finance_file);
                $founder_text = file_get_contents($founder_file);
                $former_text = file_get_contents($former_file);
                $feed_text = file_get_contents($feed_file);
                $com_text = file_get_contents($com_file);
                $team_text = file_exists($team_file) ? file_get_contents($team_file) : '';

                $info = json_decode($company_text, true);
                if($info['code'] != 0) continue;

                $finance_info = json_decode($finance_text, true);
                $founder_info = json_decode($founder_text, true);
                $former_info = json_decode($former_text, true);
                $feed_info = json_decode($feed_text, true);
                $com_info = json_decode($com_text, true);
                $team_info = json_decode($team_text, true);

                $financing = array();
                if($finance_info['data']['data']){
                    foreach ($finance_info['data']['data'] as $k => $finance) {
                        $financing[$k]['stage'] = $stage[$finance['phase']];
                        if(!isset($finance['financeAmount'])) $finance['financeAmount'] = '';
                        $financing[$k]['amount'] = $finance['financeAmountUnit'].$finance['financeAmount'];
                        $financing[$k]['investors'] = isset($finance['participants']) && !empty($finance['participants']) ? implode('、', array_column($finance['participants'],'name')) : '';
                        $financing[$k]['date'] = date('Y.m.d', substr($finance['financeDate'], 0,10));
                    }
                }

                $founder = array();
                if($founder_info['data']['data']){
                    foreach ($founder_info['data']['data'] as $k => $person) {
                        $founder[$k]['name'] = $person['name'];
                        $founder[$k]['type'] = $type[$person['type']];
                        $founder[$k]['avatar'] = isset($person['avatar']) ? $person['avatar'] : '';
                        $founder[$k]['intro'] = isset($person['intro']) ? $person['intro'] : '';
                    }
                }

                $former = array();
                if($former_info['data']['data']){
                    foreach ($former_info['data']['data'] as $k => $person) {
                        $former[$k]['name'] = $person['name'];
                        $former[$k]['position'] = isset($person['position']) ? $person['position'] : '';
                        $former[$k]['avatar'] = isset($person['avatar']) ? $person['avatar'] : '';
                        $former[$k]['intro'] = isset($person['intro']) ? $person['intro'] : '';
                    }
                }

                $feed = array();
                if($feed_info['data']['data']){
                    foreach ($feed_info['data']['data'] as $k => $news) {
                        $feed[$k]['title'] = strip_tags($news['content']);
                        $feed[$k]['type'] = $feedType[$news['feedTypeId']];
                        $feed[$k]['date'] = date('Y.m.d',strtotime($news['feedTime']));
                    }
                }

                $com = $com_info['data'];

                $team = array();
                if($team_info['data']['data']){
                    foreach ($team_info['data']['data'] as $k => $person) {
                        $team[$k]['name'] = $person['name'];
                        $team[$k]['position'] = isset($person['position']) ? $person['position'] : '';
                        $team[$k]['avatar'] = isset($person['avatar']) ? $person['avatar'] : '';
                        $team[$k]['intro'] = isset($person['intro']) ? $person['intro'] : '';
                    }
                }

                $data = $info['data']['company'];
                if(!isset($data['industry'])) continue;
                $tags = array_column($info['data']['tags'],'name');
                $tags = implode(',', $tags);

                if(!isset($data['iphoneAppstoreLink']) || strpos($data['iphoneAppstoreLink'], 'http') === false) $data['iphoneAppstoreLink'] = '';
                if(!isset($data['projectAdvantage'])) $data['projectAdvantage'] = '';
                if(!isset($data['dataLights'])) $data['dataLights'] = '';

                if(!isset($data['address1'])) $data['address1'] = 0;
                if(!isset($data['address2'])) $data['address2'] = 0;
                if(!isset($data['address3'])) $data['address3'] = 0;

                $indust = $industry[$data['industry']];

                if(!isset($city[0])) $city[0] = '';
                $addr1 = $city[$data['address1']];
                $addr2 = $city[$data['address2']];
                $addr3 = $city[$data['address3']];

                $founder = json_encode($founder);
                $team = json_encode($team);
                $former = json_encode($former);
                $financing = json_encode($financing);
                $feed = json_encode($feed);
                $com = json_encode($com);
                $date = date('Y-m-d H:i:s');

                $st->bindParam(1,$i,PDO::PARAM_INT);
                $st->bindParam(2,$data['name'],PDO::PARAM_STR);
                $st->bindParam(3,$data['logo'],PDO::PARAM_STR);
                $st->bindParam(4,$data['brief'],PDO::PARAM_STR);
                $st->bindParam(5,$data['intro'],PDO::PARAM_STR);
                $st->bindParam(6,$indust,PDO::PARAM_STR);
                $st->bindParam(7,$addr1,PDO::PARAM_STR);
                $st->bindParam(8,$addr2,PDO::PARAM_STR);
                $st->bindParam(9,$addr3,PDO::PARAM_STR);
                $st->bindParam(10,$tags,PDO::PARAM_STR);
                $st->bindParam(11,$data['pictures'],PDO::PARAM_STR);
                $st->bindParam(12,$data['companyType'],PDO::PARAM_STR);
                $st->bindParam(13,$data['projectAdvantage'],PDO::PARAM_STR);
                $st->bindParam(14,$data['dataLights'],PDO::PARAM_STR);
                $st->bindParam(15,$data['story'],PDO::PARAM_STR);
                $st->bindParam(16,$data['website'],PDO::PARAM_STR);
                $st->bindParam(17,$data['webLink'],PDO::PARAM_STR);
                $st->bindParam(18,$data['weixin'],PDO::PARAM_STR);
                $st->bindParam(19,$data['weibo'],PDO::PARAM_STR);
                $st->bindParam(20,$data['iphoneAppstoreLink'],PDO::PARAM_STR);
                $st->bindParam(21,$data['ipadAppstoreLink'],PDO::PARAM_STR);
                $st->bindParam(22,$data['androidLink'],PDO::PARAM_STR);
                $st->bindParam(23,$founder,PDO::PARAM_STR);
                $st->bindParam(24,$team,PDO::PARAM_STR);
                $st->bindParam(25,$former,PDO::PARAM_STR);
                $st->bindParam(26,$financing,PDO::PARAM_STR);
                $st->bindParam(27,$feed,PDO::PARAM_STR);
                $st->bindParam(28,$com,PDO::PARAM_STR);
                $st->bindParam(29,$date,PDO::PARAM_STR);
                

                $st->execute();
                $return = $db->lastInsertId();
                echo "id : ".$return."\r\n";

            }
        }

        //获取对应Map
        private function getMap($json,$key = 'value',$value = 'desc'){
            $info = json_decode($json, true);

            $map = array();
            foreach ($info as $in) {
                $map[$in[$key]] = $in[$value];
            }

            return $map;
        }
    }