<?php 
    // IT桔子>36kr>拉勾网>天天投>创业邦>猎云>虎嗅>天使汇>创投圈
    class Nuts_milestone{

        public function go(){
            $target_db = $this->databaseObj('nuts_tool');
            //IT桔子
            //$this->syncITjuzi($target_db, 'itjuzi_project','itjuzi_project','project_name,milestone');
    
            //天天投
            //$this->syncEvervc($target_db,'evervc_project','evervc_project','project_name,milestone');

            //拉勾网
            //$this->syncLagou($target_db,'lagou_project','lagou_project','project_name,milestone');
    
            //创业邦
            //$this->syncCyzone($target_db,'cyzone_project','cyzone_project','project_name,trends');
            
            //天使汇
            $this->syncAngel($target_db,'angel_project','angel_project','proj_name,milestone');
            
            //创投圈
            //$this->syncVc($target_db,'vc_project','vc_project','project_name,milestone');
        }

/*
 * --------------------------------------------分割线------------------------------------------------------
 * 自定义相关函数
 */
    
        public function syncITjuzi($target_db, $dbname, $table, $field, $type = PDO::FETCH_ASSOC){
            $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field,'',$type);

            $sql = "INSERT INTO company_milestone(project_id,event,event_date) VALUES(?,?,?)";
            $st = $target_db->prepare($sql);

            foreach ($data as $d) {
                if(empty($d['project_name'])) continue;
                if($d['milestone'] == '""') continue;
                $result = $target_db->query("SELECT id FROM company_project WHERE project_name='".addslashes($d['project_name'])."'")->fetchAll(PDO::FETCH_COLUMN);
                if(empty($result)) continue;

                $project_id = $result[0];
                $exists = $target_db->query("SELECT id FROM company_milestone WHERE project_id='".$project_id."'")->fetchAll(PDO::FETCH_COLUMN);
                if($exists) continue;

                $list = json_decode($d['milestone'],true);
                if(empty($list)) continue;
                foreach ($list as $li) {
                    if(empty($li['event'])) continue;
                    $date = $this->string2Date($li['date']);

                    $st->bindParam(1,$project_id,PDO::PARAM_INT);
                    $st->bindParam(2,$li['event'],PDO::PARAM_STR);
                    $st->bindParam(3,$date,PDO::PARAM_STR);
                    $st->execute();
                    echo "id : ".$target_db->lastInsertId()."\r\n";
                }
            }

            echo "===============\r\n";
        }

        public function syncEvervc($target_db, $dbname, $table, $field, $type = PDO::FETCH_ASSOC){
            $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field,'',$type);

            $sql = "INSERT INTO company_milestone(project_id,event,type,event_date) VALUES(?,?,?,?)";
            $st = $target_db->prepare($sql);

            foreach ($data as $d) {
                if(empty($d['project_name'])) continue;
                if($d['milestone'] == '""') continue;
                $result = $target_db->query("SELECT id FROM company_project WHERE project_name='".addslashes($d['project_name'])."'")->fetchAll(PDO::FETCH_COLUMN);
                if(empty($result)) continue;

                $project_id = $result[0];
                $exists = $target_db->query("SELECT id FROM company_milestone WHERE project_id='".$project_id."'")->fetchAll(PDO::FETCH_COLUMN);
                if($exists) continue;

                $list = json_decode($d['milestone'],true);
                if(empty($list)) continue;
                foreach ($list as $li) {
                    if(empty($li['title'])) continue;
                    $time = explode('.', $li['time']);
                    $date = $time[0].'.'.$time[1];

                    $st->bindParam(1,$project_id,PDO::PARAM_INT);
                    $st->bindParam(2,$li['title'],PDO::PARAM_STR);
                    $st->bindParam(3,$li['type'],PDO::PARAM_STR);
                    $st->bindParam(4,$date,PDO::PARAM_STR);
                    $st->execute();
                    echo "id : ".$target_db->lastInsertId()."\r\n";
                }
            }

            echo "===============\r\n";
        }

        public function syncCyzone($target_db, $dbname, $table, $field, $type = PDO::FETCH_ASSOC){
            $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field,'',$type);

            $sql = "INSERT INTO company_milestone(project_id,event,event_date) VALUES(?,?,?)";
            $st = $target_db->prepare($sql);

            foreach ($data as $d) {
                if(empty($d['project_name'])) continue;
                if($d['trends'] == '""') continue;
                $result = $target_db->query("SELECT id FROM company_project WHERE project_name='".addslashes($d['project_name'])."'")->fetchAll(PDO::FETCH_COLUMN);
                if(empty($result)) continue;

                $project_id = $result[0];
                $exists = $target_db->query("SELECT id FROM company_milestone WHERE project_id='".$project_id."'")->fetchAll(PDO::FETCH_COLUMN);
                if($exists) continue;

                $list = json_decode($d['trends'],true);
                if(empty($list)) continue;
                foreach ($list as $li) {
                    if(empty($li['title'])) continue;
                    $time = explode('-', $li['time']);
                    $date = empty($time) ? '' : $time[0].'.'.$time[1];

                    $st->bindParam(1,$project_id,PDO::PARAM_INT);
                    $st->bindParam(2,$li['title'],PDO::PARAM_STR);
                    $st->bindParam(3,$date,PDO::PARAM_STR);
                    $st->execute();
                    echo "id : ".$target_db->lastInsertId()."\r\n";
                }
            }

            echo "===============\r\n";
        }

        public function syncAngel($target_db, $dbname, $table, $field, $type = PDO::FETCH_ASSOC){
            $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field,'',$type);

            $sql = "INSERT INTO company_milestone(project_id,event,type,event_date) VALUES(?,?,?,?)";
            $st = $target_db->prepare($sql);

            foreach ($data as $d) {
                if(empty($d['proj_name'])) continue;
                if($d['milestone'] == '""') continue;
                $result = $target_db->query("SELECT id FROM company_project WHERE project_name='".addslashes($d['proj_name'])."'")->fetchAll(PDO::FETCH_COLUMN);
                if(empty($result)) continue;

                $project_id = $result[0];
                $exists = $target_db->query("SELECT id FROM company_milestone WHERE project_id='".$project_id."'")->fetchAll(PDO::FETCH_COLUMN);
                if($exists) continue;  

                $list = json_decode($d['milestone'],true);
                if(empty($list)) continue;
                foreach ($list as $li) {
                    if(empty($li['title'])) continue;
                    $time = explode('.', $li['time']);
                    $date = $time[0].'.'.$time[1];

                    $st->bindParam(1,$project_id,PDO::PARAM_INT);
                    $st->bindParam(2,$li['title'],PDO::PARAM_STR);
                    $st->bindParam(3,$li['type'],PDO::PARAM_STR);
                    $st->bindParam(4,$date,PDO::PARAM_STR);
                    $st->execute();
                    echo "id : ".$target_db->lastInsertId()."\r\n";
                }
            }

            echo "===============\r\n";
        }

        public function syncVc($target_db, $dbname, $table, $field, $type = PDO::FETCH_ASSOC){
            $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field,'',$type);

            $sql = "INSERT INTO company_milestone(project_id,event,type,event_date) VALUES(?,?,?,?)";
            $st = $target_db->prepare($sql);

            foreach ($data as $d) {
                if(empty($d['project_name'])) continue;
                if($d['milestone'] == '""') continue;
                $result = $target_db->query("SELECT id FROM company_project WHERE project_name='".addslashes($d['project_name'])."'")->fetchAll(PDO::FETCH_COLUMN);
                if(empty($result)) continue;

                $project_id = $result[0];
                $exists = $target_db->query("SELECT id FROM company_milestone WHERE project_id='".$project_id."'")->fetchAll(PDO::FETCH_COLUMN);
                if($exists) continue;  

                $list = json_decode($d['milestone'],true);
                if(empty($list)) continue;
                foreach ($list as $li) {
                    if(empty($li['title'])) continue;

                    $st->bindParam(1,$project_id,PDO::PARAM_INT);
                    $st->bindParam(2,$li['title'],PDO::PARAM_STR);
                    $st->bindParam(3,$li['type'],PDO::PARAM_STR);
                    $st->bindParam(4,$li['time'],PDO::PARAM_STR);
                    $st->execute();
                    echo "id : ".$target_db->lastInsertId()."\r\n";
                }
            }

            echo "===============\r\n";
        }

        public function syncLagou($target_db, $dbname, $table, $field, $type = PDO::FETCH_ASSOC){
            $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field,'',$type);

            $sql = "INSERT INTO company_milestone(project_id,event,type,event_date) VALUES(?,?,?,?)";
            $st = $target_db->prepare($sql);

            foreach ($data as $d) {
                if(empty($d['project_name'])) continue;
                if($d['milestone'] == '""') continue;
                $result = $target_db->query("SELECT id FROM company_project WHERE project_name='".addslashes($d['project_name'])."'")->fetchAll(PDO::FETCH_COLUMN);
                if(empty($result)) continue;

                $project_id = $result[0];
                $exists = $target_db->query("SELECT id FROM company_milestone WHERE project_id='".$project_id."'")->fetchAll(PDO::FETCH_COLUMN);
                if($exists) continue;

                $list = json_decode($d['milestone'],true);
                if(empty($list)) continue;
                foreach ($list as $li) {
                    if(empty($li['title'])) continue;
                    $time = explode('.', $li['time']);
                    $date = empty($time) ? '' : $time[0].'.'.$time[1];

                    $st->bindParam(1,$project_id,PDO::PARAM_INT);
                    $st->bindParam(2,$li['title'],PDO::PARAM_STR);
                    $st->bindParam(3,$li['type'],PDO::PARAM_STR);
                    $st->bindParam(4,$date,PDO::PARAM_STR);
                    $st->execute();
                    echo "id : ".$target_db->lastInsertId()."\r\n";
                }
            }

            echo "===============\r\n";
        }
    
        public function databaseObj($dbname,$host = '127.0.0.1',$user = 'root',$password = 'root'){
            $db=new PDO('mysql:dbname='.$dbname.';host='.$host,$user,$password);
            $db->exec("set names utf8");

            return $db;
        }

        public function selectData($db, $table, $field, $where = '', $type = PDO::FETCH_COLUMN){
            $data = $db->query("SELECT ".$field." FROM ".$table." ".$where)->fetchAll($type); 
            
            return $data;
        }

        //日期转换
        private function string2Date($date){
            $arr = array(
                    '.10' => '.10',
                    '.11' => '.11',
                    '.12' => '.12',
                    '.1' => '.01',
                    '.2' => '.02',
                    '.3' => '.03',
                    '.4' => '.04',
                    '.5' => '.05',
                    '.6' => '.06',
                    '.7' => '.07',
                    '.8' => '.08',
                    '.9' => '.09'
                );
            return strtr($date,$arr);
        }
    }