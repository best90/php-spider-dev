<?php
    class Qichacha{
        public function getList(){
            $db=new PDO('mysql:dbname=company;host=127.0.0.1','root','root');
            $db->exec("set names utf8");

            $cache = CACHE_PATH . '/qichacha/list/';

            $res = $db->query("SELECT id FROM company ORDER BY id ASC")->fetchAll(PDO::FETCH_COLUMN);

            $sql = "UPDATE qichacha SET url=:u,name=:n,status=:s,location=:l,founder=:f,amount=:am,reg_date=:r,address=:a,former_name=:fn WHERE id=:id";
            $st = $db->prepare($sql);

            foreach ($res as $i) {
                $file = $cache.$i.'.html';
                if(!file_exists($file)) continue;

                $html = toUtf8(read($file));
                $info = $this->getUrlList($html);
                if(empty($info)) continue;
                $list = $info[0];

                $st->bindParam(':u',$list['url']);
                $st->bindParam(':n',$list['name']);
                $st->bindParam(':s',$list['status']);
                $st->bindParam(':l',$list['location']);
                $st->bindParam(':f',$list['user']);
                $st->bindParam(':am',$list['amount']);
                $st->bindParam(':r',$list['date']);
                $st->bindParam(':a',$list['address']);
                $st->bindParam(':fn',$list['former_name']);
                $st->bindParam(':id',$i);

                $st->execute();
                $st->errorInfo();
                echo "update_id : ".$i."\r\n";
            }
        }

        //企业基础信息
        public function info(){
            $db=new PDO('mysql:dbname=company;host=127.0.0.1','root','root');
            $db->exec("set names utf8");

            $cache = CACHE_PATH . '/qichacha/firm/';

            $res = $db->query("SELECT id FROM company ORDER BY id ASC")->fetchAll(PDO::FETCH_COLUMN);

            $sql = "UPDATE qichacha_company SET credit_code=:cr,org_code=:org,status=:st,type=:ty,foud_date=:fo,corporation=:co,capital=:ca,period=:pe,institution=:inst,issue_date=:is,scale=:sc,industry=:ind,address=:ad,scope=:sco,data=:data WHERE id=:id";
            $st = $db->prepare($sql);

            foreach ($res as $i) {
                $file = $cache.$i.'.html';
                if(!file_exists($file)) continue;

                $html = toUtf8(read($file));
                $info = $this->getCompanyInfo($html);
                if(empty($info)) continue;

                $data = array(
                    'shareholder' => isset($info['shareholder']) ? $info['shareholder'] : array(),
                    'member' => isset($info['member']) ? $info['member'] : array(),
                    'update_log' => isset($info['update_log']) ? $info['update_log'] : array(),
                    'intro' => isset($info['intro']) ? $info['intro'] : '',
                    );

                $data = json_encode($data);

                $st->bindParam(':cr',$info['credit_code']);
                $st->bindParam(':org',$info['org_code']);
                $st->bindParam(':st',$info['status']);
                $st->bindParam(':ty',$info['type']);
                $st->bindParam(':fo',$info['found_date']);
                $st->bindParam(':co',$info['corporation']);
                $st->bindParam(':ca',$info['capital']);
                $st->bindParam(':pe',$info['period']);
                $st->bindParam(':inst',$info['institution']);
                $st->bindParam(':is',$info['issue_date']);
                $st->bindParam(':sc',$info['scale']);
                $st->bindParam(':ind',$info['industry']);
                $st->bindParam(':ad',$info['address']);
                $st->bindParam(':sco',$info['scope']);
                $st->bindParam(':data',$data);
                $st->bindParam(':id',$i);

                $st->execute();
                $st->errorInfo();
                echo "update_id : ".$i."\r\n";
                //die;
            }
        }

        //法律诉讼信息
        public function susong(){
            $db=new PDO('mysql:dbname=company;host=127.0.0.1','root','root');
            $db->exec("set names utf8");

            $cache = CACHE_PATH . '/qichacha/susong/';

            $res = $db->query("SELECT id FROM company ORDER BY id ASC")->fetchAll(PDO::FETCH_COLUMN);

            $sql = "UPDATE qichacha_company SET susong=:su WHERE id=:id";
            $st = $db->prepare($sql);

            foreach ($res as $i) {
                $file = $cache.$i.'.html';
                if(!file_exists($file)) continue;

                $html = toUtf8(read($file));
                $info = $this->getSusongInfo($html);
                if(empty($info)) continue;

                $data = json_encode($info);
        
                $st->bindParam(':su',$data);
                $st->bindParam(':id',$i);

                $st->execute();
                echo "update_id : ".$i."\r\n";
                //die;
            }
        }

        //对外投资
        public function touzi(){
            $db=new PDO('mysql:dbname=company;host=127.0.0.1','root','root');
            $db->exec("set names utf8");

            $cache = CACHE_PATH . '/qichacha/touzi/';

            $res = $db->query("SELECT id FROM company ORDER BY id ASC")->fetchAll(PDO::FETCH_COLUMN);

            $sql = "UPDATE qichacha_company SET touzi=:to WHERE id=:id";
            $st = $db->prepare($sql);

            foreach ($res as $i) {
                $file = $cache.$i.'.html';
                if(!file_exists($file)) continue;

                $html = toUtf8(read($file));
                $info = $this->getTouziInfo($html);
                if(empty($info)) continue;

                $data = json_encode($info);
        
                $st->bindParam(':to',$data);
                $st->bindParam(':id',$i);

                $return = $st->execute();
                if($return){
                    echo "update_id : ".$i."\r\n";
                }else{
                    print_r($st->errorInfo());
                    //echo $text."\n";
                    echo $i."\n";
                    die;
                }
                //die;
            }
        }

        //企业关系图谱数据 sql长度限制
        public function relation(){
            $db=new PDO('mysql:dbname=company;host=127.0.0.1','root','root');
            $db->exec("set names utf8");

            $cache = CACHE_PATH . '/qichacha/relation/';

            $res = $db->query("SELECT id FROM company ORDER BY id ASC")->fetchAll(PDO::FETCH_COLUMN);

            $sql = "UPDATE qichacha_company SET relation=:re WHERE id=:id";
            $st = $db->prepare($sql);

            foreach ($res as $i) {
                $file = $cache.$i.'.txt';
                if(!file_exists($file)) continue;

                $text = read($file);
                if(empty($text)) continue;

                $st->bindParam(':re',$text);
                $st->bindParam(':id',$i);

                $return = $st->execute();
                if($return){
                    echo "update_id : ".$i."\r\n";
                }else{
                    print_r($st->errorInfo());
                    //echo $text."\n";
                    echo strlen($text)."\n";
                    echo $i."\n";
                    die;
                }
                //die;
            }
        }

        //企业幕后关系图谱数据
        public function muhou(){
            $db=new PDO('mysql:dbname=company;host=127.0.0.1','root','root');
            $db->exec("set names utf8");

            $cache = CACHE_PATH . '/qichacha/muhou/';

            $res = $db->query("SELECT id FROM company ORDER BY id ASC")->fetchAll(PDO::FETCH_COLUMN);

            $sql = "UPDATE qichacha_company SET muhou=:mu WHERE id=:id";
            $st = $db->prepare($sql);

            foreach ($res as $i) {
                $file = $cache.$i.'.txt';
                if(!file_exists($file)) continue;

                $text = read($file);
                if(empty($text)) continue;

                $st->bindParam(':mu',$text);
                $st->bindParam(':id',$i);

                $return = $st->execute();
                if($return){
                    echo "update_id : ".$i."\r\n";
                }else{
                    print_r($st->errorInfo());
                    echo $i."\n";
                    die;
                }
            }
        }

        //提取url信息
        private function getUrlList($html){
            $info = array();
            $dom = phpQuery::newDocumentHTML($html);

            $list = $dom['#searchlist'];
            foreach ($list as $k => $li) {
                $info[$k]['name'] = trim(pq($li)->find('span.name')->text());
                $info[$k]['url'] = trim(pq($li)->find('a.list-group-item')->attr('href'));
                $info[$k]['status'] = trim(pq($li)->find('span.label')->text());
                $info[$k]['location'] = trim(pq($li)->find('.btn-link')->text());
                $str = trim(pq($li)->find('small.text-muted:first')->text());
                $array = explode('  ', $str);
                $info[$k]['user'] = $array[0];
                $info[$k]['date'] = isset($array[1]) ? $array[1] : '';
                $info[$k]['amount'] = isset($array[2]) ? $array[2] : '';
                $info[$k]['address'] = trim(pq($li)->find('small.text-muted:last')->text());

                $info[$k]['former_name'] = trim(pq($li)->find('span button.btn-sm')->text());
            }

            $dom -> unloadDocument();
            return $info;
        }

        //提取company base信息
        private function getCompanyInfo($html){
            $info = array();
            $dom = phpQuery::newDocumentHTML($html);

            $list = $dom['ul.company-base li'];
            foreach ($list as $k => $li) {
                $text = trim(pq($li)->find('label')->text());
                $li_info = trim(pq($li)->text());
                $value = trim(str_replace($text,'',$li_info));

                switch ($text) {
                    case '统一社会信用代码：':
                        $info['credit_code'] = $value;
                        break;
                    case '注册号：':
                        $info['credit_code'] = $value;
                        break;
                    case '组织机构代码：':
                        $info['org_code'] = $value;
                        break;
                    case '经营状态：':
                        $info['status'] = $value;
                        break;
                    case '公司类型：':
                        $info['type'] = $value;
                        break;
                    case '成立日期：':
                        $info['found_date'] = $value;
                        break;
                    case '法定代表：':
                        $info['corporation'] = $value;
                        break;
                    case '注册资本：':
                        $info['capital'] = $value;
                        break;
                    case '营业期限：':
                        $info['period'] = $value;
                        break;
                    case '登记机关：':
                        $info['institution'] = $value;
                        break;
                    case '发照日期：':
                        $info['issue_date'] = $value;
                        break;
                    case '公司规模：':
                        $info['scale'] = $value;
                        break;           
                    case '所属行业：':
                        $info['industry'] = $value;
                        break;
                    case '企业地址：':
                        $info['address'] = str_replace(' 查看地图','',$value);
                        break;
                    case '经营范围：':
                        $info['scope'] = $value;
                        break;    
                    default:
                        # code...
                        break;
                }

            }

            $divs = $dom['section.b-a'];
            foreach ($divs as $div) {
                $title = trim(pq($div)->find('.panel-heading span.font-bold')->text());
                switch ($title) {
                    case '股东信息':
                        $info['shareholder'] = array();
                        $list = pq($div)->find('div.col-md-6');
                        foreach ($list as $k => $li) {
                            $info['shareholder'][$k]['name'] = trim(pq($li)->find('.panel-body .clear a')->text());
                            $info['shareholder'][$k]['type'] = trim(pq($li)->find('.panel-body .clear small.text-ellipsis')->text());

                            $amount = trim(pq($li)->find('.panel-body .clear small.block span.black-6')->text());
                            if(!empty($amount)) $info['shareholder'][$k]['amount'] = $amount; 
                        }
                        break;
                    case '主要人员':
                        $info['member'] = array();
                        $list = pq($div)->find('div.col-md-3');
                        foreach ($list as $k => $li) {
                            $info['member'][$k]['name'] = trim(pq($li)->find('.panel-body .clear a')->text());
                            $info['member'][$k]['type'] = trim(pq($li)->find('.panel-body .clear small')->text());
                        }
                        break;
                    case '变更记录':
                        $info['update_log'] = array();
                        $list = pq($div)->find('div.col-md-12');
                        foreach ($list as $k => $li) {
                            $info['update_log'][$k]['project'] = trim(pq($li)->find('div.col-md-6:eq(0) span.black-6')->text());
                            $info['update_log'][$k]['date'] = trim(pq($li)->find('div.col-md-6:eq(1) span.black-6')->text());
                            $info['update_log'][$k]['before'] = trim(pq($li)->find('div.col-md-6:eq(2) span.black-6')->text());
                            $info['update_log'][$k]['after'] = trim(pq($li)->find('div.col-md-6:eq(3) span.black-6')->text());
                        }
                        break;
                    case '公司简介':
                        $info['intro'] = trim(pq($div)->find('div.panel-body')->text());
                        break;
                    default:
                        # code...
                        break;
                }
            }
            $dom -> unloadDocument();
            return $info;
        }

        //提取诉讼信息
        private function getSusongInfo($html){
            $info = array();
            $dom = phpQuery::newDocumentHTML($html);

            $list = $dom['#zhixinglist div.col-md-6'];
            foreach ($list as $k => $li) {
                $info['zhixing'][$k]['number'] = trim(pq($li)->find('span.text-lg')->text());
                
                $smalls = pq($li)->find('small.block');
                foreach ($smalls as $sma) {
                    $text = trim(pq($sma)->text());
                    $text = explode('：', $text);

                    $value = trim(pq($sma)->find('span.black-6')->text());
                    switch ($text[0]) {
                        case '立案时间':
                            $info['zhixing'][$k]['date'] = $value;
                            break;
                        case '执行法院':
                            $info['zhixing'][$k]['court'] = $value;
                            break;
                        case '执行标的':
                            $info['zhixing'][$k]['target'] = $value;
                            break;
                        case '案件状态':
                            $info['zhixing'][$k]['status'] = $value;
                            break;
                        default:
                            # code...
                            break;
                    }
                }
            }

            $sx_list = $dom['#shixinlist section'];
            foreach ($sx_list as $k => $sx) {
                $info['shixing'][$k]['number'] = trim(pq($sx)->find('span.text-lg')->text());
                
                $smalls = pq($sx)->find('small.block');
                foreach ($smalls as $sma) {
                    $text = trim(pq($sma)->text());
                    $text = explode('：', $text);

                    $value = trim(pq($sma)->find('span.black-6')->text());
                    switch ($text[0]) {
                        case '立案时间':
                            $info['shixing'][$k]['date'] = $value;
                            break;
                        case '执行依据文号':
                            $info['shixing'][$k]['base_number'] = $value;
                            break;
                        case '公布时间':
                            $info['shixing'][$k]['publish'] = $value;
                            break;
                        case '执行法院':
                            $info['shixing'][$k]['court'] = $value;
                            break;
                        case '被执行人的履行情况':
                            $info['shixing'][$k]['status'] = $value;
                            break;
                        case '执行法院':
                            $info['shixing'][$k]['court'] = $value;
                            break;
                        case '法律生效文书确定的义务':
                            $info['shixing'][$k]['duty'] = $value;
                        default:
                            # code...
                            break;
                    }
                }
            }

            $wenshu_list = $dom['#wenshulist section'];
            foreach ($wenshu_list as $k => $ws) {
                $info['wenshu'][$k]['title'] = trim(pq($ws)->find('div.clear a')->text());

                $smalls = pq($ws)->find('small.block');
                foreach ($smalls as $sma) {

                    $ws_text = trim(pq($sma)->text());
                    $ws_text = explode('：', $ws_text);

                    $value = trim(pq($sma)->find('span.black-6')->text());
                    switch ($ws_text[0]) {
                        case '发布时间':
                            $info['wenshu'][$k]['date'] = $value;
                            break;
                        case '案件编号':
                            $info['wenshu'][$k]['number'] = $value;
                            break;
                        case '执行法院':
                            $info['wenshu'][$k]['court'] = $value;
                            break;
                        default:
                            # code...
                            break;
                    }
                }
            }

            $gonggao_list = $dom['#gonggaolist section'];
            foreach ($gonggao_list as $k => $gg) {
                $info['gonggao'][$k]['title'] = trim(pq($gg)->find('p.text-lg')->text());
                $info['gonggao'][$k]['date'] = trim(pq($gg)->find('small.block span:first')->text());
                $info['gonggao'][$k]['court'] = trim(pq($gg)->find('small.block span:eq(1)')->text());
                $info['gonggao'][$k]['type'] = trim(pq($gg)->find('small.block span:eq(2)')->text());
                $info['gonggao'][$k]['litigant'] = trim(pq($gg)->find('small.block span:eq(3)')->text());
            }

            $dom -> unloadDocument();
            return $info;
        }

        //提取对外投资信息
        private function getTouziInfo($html){
            $info = array();
            $dom = phpQuery::newDocumentHTML($html);

            $list = $dom['ul.list-group a'];
            foreach ($list as $k => $li) {
                $info[$k]['company'] = trim(pq($li)->find('span.clear span.text-lg')->text());
                $string = trim(pq($li)->find('span.clear small.m-t-xs')->text());
                $name = mb_substr($string,3,mb_strpos($string, '成立')-3);
                $date = mb_substr($string,mb_strpos($string, '成立日期：')+5,mb_strpos($string, '注册资本')-mb_strpos($string, '成立日期：')-5);
                $amount = mb_substr($string,mb_strpos($string,'注册资本：')+5);
                $info[$k]['name'] = trim($name);
                $info[$k]['date'] = trim($date);
                $info[$k]['amount'] = trim($amount);
                $info[$k]['address'] =  trim(str_replace(' 地址：', '', pq($li)->find('span.clear small:last')->text()));
            }
            
            $dom -> unloadDocument();
            return $info;
        }
    }