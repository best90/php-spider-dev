<?php

/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2016/6/30
 * Time: 9:09
 */
class Complete{
    public $db;

    public function __construct(){
        $this->db = new PDO('mysql:dbname=complete;host=127.0.0.1','root','root');
        $this->db->exec("set names utf8");
    }

    public function urlFromBaidu(){
        $cache = CACHE_PATH . '/complete/urlFromBaidu/';

        $sql = "UPDATE url SET url=:url,url_list=:ulist,update_time=:utime WHERE id=:id";
        $st = $this->db->prepare($sql);

        $res = $this->db->query("SELECT * FROM url WHERE status = 1 LIMIT 100")->fetchAll(PDO::FETCH_ASSOC);

        while (count($res) > 0) {
            while (count($res) > 0){
                $re = array_shift($res);

                $file = $cache.$re['id'].'.html';
                if(!file_exists($file)){
                    $this->db->exec("UPDATE url SET status=0 WHERE id=".$re['id']);
                    continue;
                }

                $html = toUtf8(read($file));
                if(!$this->checkFile($html)){
                    $this->db->exec("UPDATE url SET status=0 WHERE id=".$re['id']);
                    continue;
                }

                $info = $this->getUrlFromBaidu($html);

                $list = [];
                foreach ($info as $in) {
                    if(mb_strpos($in['title'], $re['project_name']) !== false && strpos($in['url'],'...') === false && strpos($in['url'],'.baidu.com') === false){
                        if($this->isCompanyUrl($in['url'])) $list[] = $in['url'];
                    }
                }
                $url = $list ? $list[0] : NULL;
                $list = json_encode($list);

                $date = date('Y-m-d H:i:s');
                $st->bindParam(':id',$re['id']);
                $st->bindParam(':url',$url);
                $st->bindParam(':ulist',$list);
                $st->bindParam(':utime',$date);

                $st->execute();
                echo "Update Url Id : ".$re['id']."\r\n";

                $this->db->exec("UPDATE url SET status=2 WHERE id=".$re['id']);
            }

            $res = $this->db->query("SELECT * FROM url WHERE status = 1 LIMIT 100")->fetchAll(PDO::FETCH_ASSOC);
        }
    }

    //新芽数据迁入
    public function NewseedTocompany(){
        $newseed = new PDO('mysql:dbname=newseed_project;host=127.0.0.1','root','root');
        $newseed->exec("set names utf8");

        $sql = "UPDATE company SET company_name=:com WHERE id=:id";
        $st = $this->db->prepare($sql);

        $id = 0;
        $res = $this->db->query("SELECT * FROM company WHERE id>".$id." ORDER BY id ASC LIMIT 100")->fetchAll(PDO::FETCH_ASSOC);

        while (count($res) > 0) {
            while (count($res) > 0){
                $re = array_shift($res);

                $com = $newseed->query("SELECT company FROM newseed_project WHERE project_name='".addslashes($re['project_name'])."'")->fetchAll(PDO::FETCH_COLUMN);
                if(empty($com)) continue;

                $st->bindParam(':id',$re['id']);
                $st->bindParam(':com',$com[0]);

                $st->execute();
                echo "Update Company Id : ".$re['id']."\r\n";
            }
            $id = $re['id'];
            $res = $this->db->query("SELECT * FROM company WHERE id>".$id." ORDER BY id ASC LIMIT 100")->fetchAll(PDO::FETCH_ASSOC);
        }
    }

    //合并url_newseed到url表
    public function NewseedToUrl(){
        $sql = "UPDATE url SET url=:url WHERE id=:id";
        $st = $this->db->prepare($sql);

        $id = 0;
        $res = $this->db->query("SELECT * FROM url_newseed WHERE id>".$id." AND url !='' ORDER BY id ASC LIMIT 100")->fetchAll(PDO::FETCH_ASSOC);

        while (count($res) > 0) {
            while (count($res) > 0){
                $re = array_shift($res);

                $st->bindParam(':url',$re['url']);
                $st->bindParam(':id',$re['id']);

                $st->execute();
                echo "Update URL Id : ".$re['id']."\r\n";
            }
            $id = $re['id'];
            $res = $this->db->query("SELECT * FROM url_newseed WHERE id>".$id." AND url !='' ORDER BY id ASC LIMIT 100")->fetchAll(PDO::FETCH_ASSOC);
        }
    }

    //合并url到company_project表
    public function urlToProject(){
        $pro = new PDO('mysql:dbname=nuts_tool;host=127.0.0.1','root','root');
        $pro->exec("set names utf8");

        $sql = "UPDATE company_project SET url=:url WHERE id=:id";
        $st = $pro->prepare($sql);

        $id = 0;
        $res = $this->db->query("SELECT * FROM url WHERE id>".$id." AND url !='' ORDER BY id ASC LIMIT 100")->fetchAll(PDO::FETCH_ASSOC);

        while (count($res) > 0) {
            while (count($res) > 0){
                $re = array_shift($res);

                $st->bindParam(':url',$re['url']);
                $st->bindParam(':id',$re['id']);

                $st->execute();
                echo "Update Company_project URL Id : ".$re['id']."\r\n";
            }
            $id = $re['id'];
            $res = $this->db->query("SELECT * FROM url WHERE id>".$id." AND url !='' ORDER BY id ASC LIMIT 100")->fetchAll(PDO::FETCH_ASSOC);
        }
    }

    //校验文件
    private function checkFile($html){
        if(mb_strpos($html,'百度搜索</title>') === false || mb_strpos($html,'</html>') === false) return false;
        return true;
    }

    //判断是否是官网
    private function isCompanyUrl($url){
        $url = trim($url,'/');
        $url_arr = explode('/',$url);
        if(count($url_arr) > 1) return false;
        if(strpos($url,'www') !== false){
            if(substr_count($url,'.') > 3) return false;
        }else{
            if(substr_count($url,'.') > 2) return false;
        }

        $url_info = parseUrl($url);
        if(isset($url_info['prefix']) && $url_info['prefix'] != 'www') return false;

        return true;
    }

    /**
     * 提取百度搜索结果页url
     * @param string $html
     * @return array
     */
    private function getUrlFromBaidu($html){
        $info = [];
        $dom = phpQuery::newDocumentHTML($html);

        $list = $dom['#content_left .result'];
        foreach ($list as $k => $li){
            $info[$k]['title'] = trim(pq($li)->find('h3 a')->text());
            $info[$k]['url'] = trim(str_replace(' ','',pq($li)->find('.f13 .c-showurl')->text()));
        }

        $dom->unloadDocument();
        return $info;
    }
}