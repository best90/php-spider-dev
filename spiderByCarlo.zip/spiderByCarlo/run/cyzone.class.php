<?php
    class Cyzone{
        public function project(){
            $db=new PDO('mysql:dbname=cyzone_project;host=127.0.0.1','root','root');
            $db->exec("set names utf8");

            $cache = CACHE_PATH . '/cyzone/project/';

            $sql = "INSERT INTO cyzone_project(project_html_id,project_name,company_name,icon,info_img,url,found_time,location,financing_stage,industry,intro,team,trends,news,financing,company_info,update_time) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE update_time=VALUES(update_time)";
            $st = $db->prepare($sql);

            for ($i=1; $i <= 30000; $i++) { 
                $file = $cache.$i.'.html';
                if(!file_exists($file)) continue;

                $html = toUtf8(read($file));
                if(mb_strpos($html, '<title>404')) continue;
                $info = $this->getProjectInfo($html);
                //print_r($info);

                $team = json_encode($info['team']);
                $milestone = json_encode($info['trends']);
                $news = json_encode($info['news']);
                $financing = json_encode($info['financing']);
                $com_info = json_encode($info['com_info']);
                $date = date('Y-m-d H:i:s');

                $st->bindParam(1,$i,PDO::PARAM_INT);
                $st->bindParam(2,$info['project_name'],PDO::PARAM_STR);
                $st->bindParam(3,$info['company_name'],PDO::PARAM_STR);
                $st->bindParam(4,$info['icon'],PDO::PARAM_STR);
                $st->bindParam(5,$info['info_img'],PDO::PARAM_STR);
                $st->bindParam(6,$info['url'],PDO::PARAM_STR);
                $st->bindParam(7,$info['found_time'],PDO::PARAM_STR);
                $st->bindParam(8,$info['location'],PDO::PARAM_STR);
                $st->bindParam(9,$info['financing_stage'],PDO::PARAM_STR);
                $st->bindParam(10,$info['industry'],PDO::PARAM_STR);
                $st->bindParam(11,$info['intro'],PDO::PARAM_STR);
                $st->bindParam(12,$team,PDO::PARAM_STR);
                $st->bindParam(13,$milestone,PDO::PARAM_STR);
                $st->bindParam(14,$news,PDO::PARAM_STR);
                $st->bindParam(15,$financing,PDO::PARAM_STR);
                $st->bindParam(16,$com_info,PDO::PARAM_STR);
                $st->bindParam(17,$date,PDO::PARAM_STR);
              

                $st->execute();
                $return = $db->lastInsertId();
                echo "id : ".$return."\r\n";

            }
        }

        //提取信息
        private function getProjectInfo($html){
            $info = array();
            $dom = phpQuery::newDocumentHTML($html);

            $info['project_name'] = trim(pq($dom['.top-info ul li.name h1'])->text());
            $info['company_name'] = str_replace("公司全称：",'',trim(pq($dom['.top-info ul li.time'])->text()));
            $info['icon'] = trim(pq($dom['.ti-left img'])->attr('src'));
            $info['url'] = trim(pq($dom['.top-info ul li.add a'])->attr('href'));
            $info['info_img'] = trim(pq($dom['.info-img img'])->attr('src'));
            $info['found_time'] = trim(pq($dom['div.info-tag ul li i.i1'])->_next()->text());
            $info['location'] = trim(pq($dom['div.info-tag ul li i.i2'])->_next()->text());
            $info['financing_stage'] = trim(pq($dom['div.info-tag ul li i.i3'])->_next()->text());
            $info['industry'] = trim(pq($dom['div.info-tag ul li i.i6'])->_next()->text());

            $info['intro'] = trim(pq($dom['.info-box'])->text());

            $trends_list = $dom['.trends div.item'];
            foreach ($trends_list as $k => $li) {
                $info['trends'][$k]['title'] = trim(pq($li)->find('div.content')->text());
                $info['trends'][$k]['time'] = trim(pq($li)->find('.time-block .time')->text());
            }
            $info['trends'] = isset($info['trends']) ? $info['trends'] : array();

            $team_list = $dom['.team ul li'];
            foreach ($team_list as $k => $li) {
                $info['team'][$k]['name'] = trim(pq($li)->find('p.name')->text());
                $info['team'][$k]['img'] = trim(pq($li)->find('.team-img img')->attr('src')) == 'http://css.cyzone.cn/statics/images/nopic.gif' ? '' : trim(pq($li)->find('.team-img img')->attr('src'));
                $info['team'][$k]['job'] = trim(pq($li)->find('p.job')->text());
                $info['team'][$k]['url'] = trim(pq($li)->find('p.name a')->attr('href'));
            }
            $info['team'] = isset($info['team']) ? $info['team'] : array();

            $list = $dom['.live tr:gt(0)'];
            foreach ($list as $k => $li) {
                $info['financing'][$k]['stage'] = trim(pq($li)->find('td:first')->text());
                $info['financing'][$k]['amount'] = trim(pq($li)->find('td:eq(1)')->text());
                $info['financing'][$k]['investors'] = trim(pq($li)->find('td:eq(2)')->text());
                $info['financing'][$k]['time'] = trim(pq($li)->find('td:eq(3)')->text());
            }
            $info['financing'] = isset($info['financing']) ? $info['financing'] : array();

            $news_list = $dom['.about ul li'];
            foreach ($news_list as $k => $li) {
                $info['news'][$k]['title'] = trim(pq($li)->find('.info a')->text());
                $info['news'][$k]['url'] = trim(pq($li)->find('.info a')->attr('href'));
                $info['news'][$k]['time'] = trim(pq($li)->find('span.time')->text());
            }
            $info['news'] = isset($info['news']) ? $info['news'] : array();

            $com = $dom['div.qcc p'];
            foreach ($com as $k => $li) {
                $type = trim(pq($li)->find('.name')->text());
                switch ($type) {
                    case '注册号:':
                        $info['com_info']['reg_num'] = trim(pq($li)->text(), $type);
                        break;
                    case '经营状态:':
                        $info['com_info']['status'] = trim(pq($li)->text(), $type);
                        break;
                    case '法定代表:':
                        $info['com_info']['founder'] = trim(pq($li)->text(), $type);
                        break;
                    case '公司类型:':
                        $info['com_info']['type'] = trim(pq($li)->text(), $type);
                        break;
                    case '成立日期:':
                        $info['com_info']['found_time'] = trim(pq($li)->text(), $type);
                        break;
                    case '注册资本:':
                        $info['com_info']['reg_money'] = trim(pq($li)->text(), $type);
                        break;
                    case '住所:':
                        $info['com_info']['address'] = trim(pq($li)->text(), $type);
                        break;
                    default:
                        
                        break;
                }
            }
            $info['com_info'] = isset($info['com_info']) ? $info['com_info'] : array();

            $dom -> unloadDocument();

            return $info;
        }
    }