<?php
    class Itjuzi{
        //项目信息提取
        public function project(){
            $db=new PDO('mysql:dbname=itjuzi_project;host=127.0.0.1','root','root');
            $db->exec("set names utf8");
            $cache = CACHE_PATH . '/itjuzi/company/';

            $sql = "INSERT INTO itjuzi_project(project_html_id,project_name,logo,intro,industry,location,status,stage,url,tags,picshow_url,company,email,phone,address,product,team,funding,milestone,news,update_time) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE update_time=VALUES(update_time)";

            $st = $db->prepare($sql);
                
            for($i = 1; $i <= 35000; $i ++) {
                $file = $cache.$i.'.html';
                if(!file_exists($file)) continue;

                $html = toUtf8(read($file));
                if(!$this->checkFile($html)){
                    unlink($file);
                    continue;
                }

                $info = $this->getInfo($html);
                if(isset($info['tags']) && !empty($info['tags'])){
                    $tags = implode(',', $info['tags']);
                }else{
                    $tags = '';
                }

                $product = json_encode($info['product']);
                $team = json_encode($info['team']);
                $financing = json_encode($info['financing']);
                $milestone = json_encode($info['milestone']);
                $news = json_encode($info['news']);
                $date = date('Y-m-d H:i:s');

                $st->bindParam(1,$i,PDO::PARAM_INT);
                $st->bindParam(2,$info['project']['name'],PDO::PARAM_STR);
                $st->bindParam(3,$info['project']['icon_url'],PDO::PARAM_STR);
                $st->bindParam(4,$info['project']['info'],PDO::PARAM_STR);
                $st->bindParam(5,$info['industry'],PDO::PARAM_STR);
                $st->bindParam(6,$info['project']['location'],PDO::PARAM_STR);
                $st->bindParam(7,$info['project']['status'],PDO::PARAM_STR);
                $st->bindParam(8,$info['project']['fund_status'],PDO::PARAM_STR);
                $st->bindParam(9,$info['project']['url'],PDO::PARAM_STR);
                $st->bindParam(10,$tags,PDO::PARAM_STR);
                $st->bindParam(11,$info['project']['picshow_url'],PDO::PARAM_STR);
                $st->bindParam(12,$info['company']['name'],PDO::PARAM_STR);
                $st->bindParam(13,$info['company']['email'],PDO::PARAM_STR);
                $st->bindParam(14,$info['company']['phone'],PDO::PARAM_STR);
                $st->bindParam(15,$info['company']['address'],PDO::PARAM_STR);
                $st->bindParam(16,$product,PDO::PARAM_STR);
                $st->bindParam(17,$team,PDO::PARAM_STR);
                $st->bindParam(18,$financing,PDO::PARAM_STR);
                $st->bindParam(19,$milestone,PDO::PARAM_STR);
                $st->bindParam(20,$news,PDO::PARAM_STR);
                $st->bindParam(21,$date,PDO::PARAM_STR);

                $st->execute();
                $return = $db->lastInsertId();
                echo "id : ".$return."\r\n";
            }
        }

        //国内融资事件
        public function investevents(){
            $db=new PDO('mysql:dbname=itjuzi_project;host=127.0.0.1','root','root');
            $db->exec("set names utf8");
            $cache = CACHE_PATH . '/itjuzi/investevents/';

            $sql = "INSERT INTO investevents(project_name,industry,location,stage,amount,investors,update_time) VALUES(:pro,:ind,:loc,:sta,:amo,:inv,:upd) ON DUPLICATE KEY UPDATE industry=VALUES(industry),location=VALUES(location),stage=VALUES(stage),amount=VALUES(amount),investors=VALUES(investors)";

            $st = $db->prepare($sql);
                
            for($i = 1; $i <= 1400; $i ++) {
                $file = $cache.$i.'.html';
                if(!file_exists($file)) continue;

                $html = toUtf8(read($file));
                $info = $this->getEventsList($html,'invest');
                
                foreach ($info as $in) {
                    $st->bindParam(':pro',$in['project_name']);
                    $st->bindParam(':ind',$in['industry']);
                    $st->bindParam(':loc',$in['location']);
                    $st->bindParam(':sta',$in['stage']);
                    $st->bindParam(':amo',$in['amount']);
                    $st->bindParam(':inv',$in['investors']);
                    $st->bindParam(':upd',$in['date']);

                    $st->execute();
                    $return = $db->lastInsertId();
                    echo "id : ".$return."\r\n";
                }
            }
        }

        //国内并购事件
        public function merger(){
            $db=new PDO('mysql:dbname=itjuzi_project;host=127.0.0.1','root','root');
            $db->exec("set names utf8");
            $cache = CACHE_PATH . '/itjuzi/merger/';

            $sql = "INSERT INTO merger(project_name,industry,location,rate,amount,investors,update_time) VALUES(:pro,:ind,:loc,:rat,:amo,:inv,:upd) ON DUPLICATE KEY UPDATE industry=VALUES(industry),location=VALUES(location),rate=VALUES(rate),amount=VALUES(amount),investors=VALUES(investors)";

            $st = $db->prepare($sql);
                
            for($i = 1; $i <= 100; $i ++) {
                $file = $cache.$i.'.html';
                if(!file_exists($file)) continue;

                $html = toUtf8(read($file));
                $info = $this->getEventsList($html,'merger');
                
                foreach ($info as $in) {
                    $st->bindParam(':pro',$in['project_name']);
                    $st->bindParam(':ind',$in['industry']);
                    $st->bindParam(':loc',$in['location']);
                    $st->bindParam(':rat',$in['rate']);
                    $st->bindParam(':amo',$in['amount']);
                    $st->bindParam(':inv',$in['investors']);
                    $st->bindParam(':upd',$in['date']);

                    $st->execute();
                    $return = $db->lastInsertId();
                    echo "id : ".$return."\r\n";
                }
            }
        }

        //国外融资事件
        public function invest_foreign(){
            $db=new PDO('mysql:dbname=itjuzi_project;host=127.0.0.1','root','root');
            $db->exec("set names utf8");
            $cache = CACHE_PATH . '/itjuzi/investevents_foreign/';

            $sql = "INSERT INTO investevents_foreign(project_name,industry,location,stage,amount,investors,update_time) VALUES(:pro,:ind,:loc,:sta,:amo,:inv,:upd) ON DUPLICATE KEY UPDATE industry=VALUES(industry),location=VALUES(location),stage=VALUES(stage),amount=VALUES(amount),investors=VALUES(investors)";

            $st = $db->prepare($sql);
                
            for($i = 1; $i <= 1400; $i ++) {
                $file = $cache.$i.'.html';
                if(!file_exists($file)) continue;

                $html = toUtf8(read($file));
                $info = $this->getEventsList($html,'invest_foreign');
                
                foreach ($info as $in) {
                    $st->bindParam(':pro',$in['project_name']);
                    $st->bindParam(':ind',$in['industry']);
                    $st->bindParam(':loc',$in['location']);
                    $st->bindParam(':sta',$in['stage']);
                    $st->bindParam(':amo',$in['amount']);
                    $st->bindParam(':inv',$in['investors']);
                    $st->bindParam(':upd',$in['date']);

                    $st->execute();
                    $return = $db->lastInsertId();
                    echo "id : ".$return."\r\n";
                }
            }
        }

        //国外并购事件
        public function merger_foreign(){
            $db=new PDO('mysql:dbname=itjuzi_project;host=127.0.0.1','root','root');
            $db->exec("set names utf8");
            $cache = CACHE_PATH . '/itjuzi/merger_foreign/';

            $sql = "INSERT INTO merger_foreign(project_name,industry,location,rate,amount,investors,update_time) VALUES(:pro,:ind,:loc,:rat,:amo,:inv,:upd) ON DUPLICATE KEY UPDATE industry=VALUES(industry),location=VALUES(location),rate=VALUES(rate),amount=VALUES(amount),investors=VALUES(investors)";

            $st = $db->prepare($sql);
                
            for($i = 1; $i <= 100; $i ++) {
                $file = $cache.$i.'.html';
                if(!file_exists($file)) continue;

                $html = toUtf8(read($file));
                $info = $this->getEventsList($html,'merger');
                
                foreach ($info as $in) {
                    $st->bindParam(':pro',$in['project_name']);
                    $st->bindParam(':ind',$in['industry']);
                    $st->bindParam(':loc',$in['location']);
                    $st->bindParam(':rat',$in['rate']);
                    $st->bindParam(':amo',$in['amount']);
                    $st->bindParam(':inv',$in['investors']);
                    $st->bindParam(':upd',$in['date']);

                    $st->execute();
                    $return = $db->lastInsertId();
                    echo "id : ".$return."\r\n";
                }
            }
        }

        //检查文档是否正常
        private function checkFile($html){
            if(mb_strpos($html,'IT桔子') === false || mb_strpos($html, '<title>安全验证</title>')) return false;
            return true;
        }

        //提取信息
        private function getInfo($html, $config='company,project,tag,financing,team,product,news,milestone,industry'){
            if(!is_array($config)) $config = explode(',',$config);
            if(empty($config)) $config = array('company','project','tag','financing','team','product','news','milestone','industry');
            
            $info = array();
            $dom = phpQuery::newDocumentHTML($html);

            if(in_array('company', $config)){
                $companyInfo = array();

                $companyName = pq($dom['div.des-more div:eq(0) span'])->text();
                $companyInfo['name'] = trim(str_replace('公司全称：', '', $companyName));
                $companyInfo['name'] = ($companyInfo['name'] == '暂未收录') ? '' : $companyInfo['name'];

                $email = trim(pq($dom['ul.aboutus li i.fa-envelope'])->_next()->text());
                $phone = trim(pq($dom['ul.aboutus li i.fa-phone'])->_next()->text());
                $address = trim(pq($dom['ul.aboutus li i.fa-map-marker'])->_next()->text());
                $companyInfo['email'] = ($email == '暂未收录') ? '' : $email;
                $companyInfo['phone'] = ($phone == '暂未收录') ? '' : $phone;
                $companyInfo['address'] = ($address == '暂未收录') ? '' : $address;

                $info['company'] = $companyInfo;
                unset($companyInfo);
            }
            
            if(in_array('project', $config)){
                $projectInfo = array();

                $projectName =  pq($dom['title'])->text();
                $projectInfo['name'] = trim(str_replace('| IT桔子', '', $projectName));

                $projectInfo['fund_status'] = trim(pq($dom['.line-title b span'])->text());
                $projectInfo['fund_status'] = ltrim($projectInfo['fund_status'],'(');
                $projectInfo['fund_status'] = rtrim($projectInfo['fund_status'],')');
                $projectInfo['fund_status'] = trim($projectInfo['fund_status']);

                $projectInfo['location'] = trim(pq($dom['span.loca a:eq(0)'])->html());
                $city = trim(pq($dom['span.loca a:eq(1)'])->html());
                if($city) $projectInfo['location'] .= '·'.$city;

                $found_time = pq($dom['div.des-more div:eq(1) span'])->text();
                $projectInfo['found_time'] = trim(str_replace('成立时间：', '', $found_time));

                $status = pq($dom['div.des-more div:eq(2) span'])->text();
                $projectInfo['status'] = trim($status);

                $projectInfo['icon_url'] = trim(pq($dom['.rowhead div.pic img'])->attr('src'));
                $projectInfo['url'] = trim(pq($dom['.rowhead div.picinfo a.weblink'])->text());
                $projectInfo['picshow_url'] = trim(pq($dom['.block-inc-info div.picshow img'])->attr('src'));
                $projectInfo['info'] = trim(pq($dom['.block-inc-info div.des'])->text());

                $info['project'] = $projectInfo;
                unset($projectInfo);
            }

            if(in_array('tag', $config)){
                $tag_list = $dom['.rowfoot div.tagset a'];
                foreach ($tag_list as $tag) {
                    $info['tags'][] = trim(pq($tag)->text());
                }
            }

            if(in_array('financing', $config)){
                $info['financing'] = array();
                $list = $dom['.list-round-v2 tr'];
                foreach ($list as $k => $li) {
                    $info['financing'][$k]['date'] = trim(pq($li)->find('span.date')->text());
                    $info['financing'][$k]['round'] = trim(pq($li)->find('.mobile-none span.round')->text());
                    $info['financing'][$k]['finades'] = trim(pq($li)->find('span.finades a')->text());
                    $investors = pq($li)->find('td:last a');
                    foreach ($investors as $investor) {
                        $info['financing'][$k]['investors'][] = trim(pq($investor)->text());
                    }
                    if(isset($info['financing'][$k]['investors'])) {
                        $info['financing'][$k]['investors'] = implode('、',$info['financing'][$k]['investors']);
                    }else{
                        $info['financing'][$k]['investors'] = trim(pq($li)->find('td:last span')->text());
                    }
                }
            }

            if(in_array('team', $config)){
                $info['team'] = array();
                $list = $dom['ul.list-prodcase li'];
                foreach ($list as $k => $li) {       
                    $info['team'][$k]['name'] = trim(pq($li)->find('.person-name a b span.c')->text());
                    $info['team'][$k]['position'] = trim(pq($li)->find('.person-name a b span.c-gray')->text());
                    $info['team'][$k]['usericon'] = trim(pq($li)->find('span.usericon img')->attr('src'));
                    $info['team'][$k]['weibo'] = trim(pq($li)->find('.person-name span.links a')->attr('href'));

                    $info['team'][$k]['resume'] = trim(pq($li)->find('p.person-des')->text());
                }
            }

            if(in_array('product', $config)){
                $info['product'] = array();
                $list = $dom['ul.list-prod li'];
                foreach ($list as $k => $li) {
                    $info['product'][$k]['name'] = trim(pq($li)->find('h4 b')->text());
                    $info['product'][$k]['type'] = trim(pq($li)->find('h4 span.tag')->text());
                    $info['product'][$k]['info'] = trim(pq($li)->find('a p')->text());
                    $info['product'][$k]['url'] = trim(pq($li)->find('a')->attr('href'));
                }
            }

            if(in_array('news', $config)){
                $info['news'] = array();
                $list = $dom['ul.list-news li'];
                foreach ($list as $k => $li) {
                    $info['news'][$k]['title'] = trim(pq($li)->find('.title')->text());
                    $info['news'][$k]['type'] = trim(pq($li)->find('span.tag')->text());
                    $info['news'][$k]['url'] = trim(pq($li)->find('.title a')->attr('href'));
                    $info['news'][$k]['date'] = trim(pq($li)->find('span.t-small')->text());
                    $info['news'][$k]['source'] = trim(pq($li)->find('span.from')->text());
                }
            }

            if(in_array('milestone', $config)){
                $info['milestone'] = array();
                $list = $dom['ul.list-milestone li'];
                foreach ($list as $k => $li) {
                    $info['milestone'][$k]['event'] = trim(pq($li)->find('p:first')->text());
                    $info['milestone'][$k]['date'] = trim(pq($li)->find('p span')->text());
                }
            }

            if(in_array('industry', $config)){
                $info['industry'] = trim(pq($dom['span.scope a:last'])->text());
            }

            $dom -> unloadDocument();

            return $info;
        }

        //获取状态
        private function statusNum($status){
            switch ($status) {
                case '运营中':
                    return 1;
                    break;
                case '未上线':
                    return 2;
                    break;
                case '已关闭':
                    return 3;
                    break;
                case '已转型':
                    return 4;
                    break;
                default:
                    return 0;
                    break;
            }
        }

        //获取获投状态
        private function fundStatusNum($fund_status){
            switch ($fund_status) {
                case '尚未获投':
                    return 1;
                    break;
                case '种子轮':
                    return 2;
                    break;
                case '天使轮':
                    return 3;
                    break;
                case 'Pre-A轮':
                    return 4;
                    break;
                case 'A轮':
                    return 5;
                    break;
                case 'A+轮':
                    return 6;
                    break;
                case 'Pre-B轮':
                    return 7;
                    break;
                case 'B轮':
                    return 8;
                    break;
                case 'B+轮':
                    return 9;
                    break;
                case 'C轮':
                    return 10;
                    break;
                case 'D轮':
                    return 11;
                    break;
                case 'E轮':
                    return 12;
                    break;
                case 'F轮-上市前':
                    return 13;
                    break;
                case '已上市':
                    return 14;
                    break;
                case '已被收购':
                    return 15;
                    break;
                case '不明确':
                    return 16;
                    break;
                default:
                    return 0;
                    break;
            }
        }

        //获取事件List
        private function getEventsList($html,$type){
            $info = array();
            $dom = phpQuery::newDocumentHTML($html);

            $list = $dom['ul.list-main-eventset:not(.thead) li'];
            foreach ($list as $k => $li) {
                $info[$k]['date'] = str_replace('.','-',$this->string2Date(trim(pq($li)->find('i.round:first')->text())));
                $info[$k]['project_name'] = trim(pq($li)->find('.title span')->text());
                $info[$k]['industry'] = trim(pq($li)->find('p span.tags')->text());
                $info[$k]['location'] = trim(pq($li)->find('p span.loca')->text());

                switch ($type) {
                    case 'invest':
                        $info[$k]['stage'] = trim(pq($li)->find('i.round a span')->text());
                        break;
                    case 'merger':
                        $info[$k]['rate'] = trim(pq($li)->find('i.round span.tag')->text());
                        break;
                    case 'invest_foreign':
                        $info[$k]['stage'] = trim(pq($li)->find('i.round span.tag')->text());
                        break;
                    default:
                        # code...
                        break;
                }
                
                $info[$k]['amount'] = trim(pq($li)->find('i.fina')->text());

                $investors = pq($li)->find('i.date a');
                foreach ($investors as $investor) {
                    $info[$k]['investors'][] = trim(pq($investor)->text());
                }

                $investors = pq($li)->find('i.date span.c-gray');
                foreach ($investors as $investor) {
                    $info[$k]['investors'][] = trim(pq($investor)->text());
                }

                $info[$k]['investors'] = $info[$k]['investors'] ? implode(',', $info[$k]['investors']) : NULL;
            }

            $dom -> unloadDocument();

            return $info;
        }

        //日期转换
        private function string2Date($date){
            $arr = array(
                    '.10' => '.10',
                    '.11' => '.11',
                    '.12' => '.12',
                    '.13' => '.13',
                    '.14' => '.14',
                    '.15' => '.15',
                    '.16' => '.16',
                    '.17' => '.17',
                    '.18' => '.18',
                    '.19' => '.19',
                    '.20' => '.20',
                    '.21' => '.21',
                    '.22' => '.22',
                    '.23' => '.23',
                    '.24' => '.24',
                    '.25' => '.25',
                    '.26' => '.26',
                    '.27' => '.27',
                    '.28' => '.28',
                    '.29' => '.29',
                    '.30' => '.30',
                    '.31' => '.31',
                    '.1' => '.01',
                    '.2' => '.02',
                    '.3' => '.03',
                    '.4' => '.04',
                    '.5' => '.05',
                    '.6' => '.06',
                    '.7' => '.07',
                    '.8' => '.08',
                    '.9' => '.09',
                    '-' => '.',
                    '年' => '.',
                    '月' => '.',
                    '日' => '.'
                );
            return strtr($date,$arr);
        }
    }