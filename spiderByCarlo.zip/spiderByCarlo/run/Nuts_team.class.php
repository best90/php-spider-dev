<?php 
    // IT桔子>36kr>拉勾网>天天投>创业邦>猎云>虎嗅>天使汇>创投圈
    class Nuts_team{

        public function go(){
            $target_db = $this->databaseObj('nuts_tool');
            //IT桔子
            $this->syncITjuzi($target_db, 'itjuzi_project','itjuzi_project','project_name,team');
    
            //拉勾网
            $this->syncLagou($target_db,'lagou_project','lagou_project','project_name,team');

            //天天投
            $this->syncEvervc($target_db,'evervc_project','evervc_project','project_name,team');

            //36kr
            $this->sync36kr($target_db, '36kr_project','36kr_project','project_name,founder,team');
            
            //猎云网 无
            //$this->syncLieyun($target_db,'other_project','lieyun_project','company');
            
            //天使汇
            $this->syncAngel($target_db,'angel_project','angel_project','proj_name,team');

            //虎嗅网
            $this->syncHuxiu($target_db,'other_project','huxiu_project','project_name,team');

            //创业邦
            $this->syncCyzone($target_db,'cyzone_project','cyzone_project','project_name,team');
            
            //创投圈
            $this->syncVc($target_db,'vc_project','vc_project','project_name,team');
        }

/*
 * --------------------------------------------分割线------------------------------------------------------
 * 自定义相关函数
 */
        public function syncITjuzi($target_db, $dbname, $table, $field, $type = PDO::FETCH_ASSOC){
            $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field,'',$type);

            $sql = "INSERT INTO company_team(project_id,person_name,position,usericon,weibo,resume) VALUES(?,?,?,?,?,?)";
            $st = $target_db->prepare($sql);

            foreach ($data as $d) {
                if(empty($d['project_name'])) continue;
                if($d['team'] == '""') continue;
                $result = $target_db->query("SELECT id FROM company_project WHERE project_name='".addslashes($d['project_name'])."'")->fetchAll(PDO::FETCH_COLUMN);
                if(empty($result)) continue;

                $project_id = $result[0];
                $exists = $target_db->query("SELECT id FROM company_team WHERE project_id='".$project_id."'")->fetchAll(PDO::FETCH_COLUMN);
                if($exists) continue;

                $list = json_decode($d['team'],true);
                if(empty($list)) continue;
                foreach ($list as $li) {
                    if(empty($li['name'])) continue;

                    $st->bindParam(1,$project_id,PDO::PARAM_INT);
                    $st->bindParam(2,$li['name'],PDO::PARAM_STR);
                    $st->bindParam(3,$li['position'],PDO::PARAM_STR);
                    $st->bindParam(4,$li['usericon'],PDO::PARAM_STR);
                    $st->bindParam(5,$li['weibo'],PDO::PARAM_STR);
                    $st->bindParam(6,$li['resume'],PDO::PARAM_STR);
                    $st->execute();
                    echo "id : ".$target_db->lastInsertId()."\r\n";
                }
            }

            echo "===============\r\n";
        }

        public function sync36kr($target_db, $dbname, $table, $field, $type = PDO::FETCH_ASSOC){
            $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field,'',$type);

            $sql = "INSERT INTO company_team(project_id,person_name,position,usericon,resume) VALUES(?,?,?,?,?)";
            $st = $target_db->prepare($sql);

            foreach ($data as $d) {
                if(empty($d['project_name'])) continue;
                if($d['team'] == '""') continue;
                $result = $target_db->query("SELECT id FROM company_project WHERE project_name='".addslashes($d['project_name'])."'")->fetchAll(PDO::FETCH_COLUMN);
                if(empty($result)) continue;

                $project_id = $result[0];
                $exists = $target_db->query("SELECT id FROM company_team WHERE project_id='".$project_id."'")->fetchAll(PDO::FETCH_COLUMN);
                if($exists) continue;

                $founder = json_decode($d['founder'],true);
                if(!empty($founder)){

                    foreach ($founder as $f) {
                        if(empty($f['name'])) continue;

                        $st->bindParam(1,$project_id,PDO::PARAM_INT);
                        $st->bindParam(2,$f['name'],PDO::PARAM_STR);
                        $st->bindParam(3,$f['type'],PDO::PARAM_STR);
                        $st->bindParam(4,$f['avatar'],PDO::PARAM_STR);
                        $st->bindParam(5,$f['intro'],PDO::PARAM_STR);
                        $st->execute();
                        echo "id : ".$target_db->lastInsertId()."\r\n";
                    }
                }

                $team = json_decode($d['team'],true);
                if(!empty($team)){

                    foreach ($team as $t) {
                        if(empty($t['name'])) continue;
                        $st->bindParam(1,$project_id,PDO::PARAM_INT);
                        $st->bindParam(2,$t['name'],PDO::PARAM_STR);
                        $st->bindParam(3,$t['position'],PDO::PARAM_STR);
                        $st->bindParam(4,$t['avatar'],PDO::PARAM_STR);
                        $st->bindParam(5,$t['intro'],PDO::PARAM_STR);
                        $st->execute();
                        echo "id : ".$target_db->lastInsertId()."\r\n";
                    }
                }
                
            }

            echo "===============\r\n";
        }

        public function syncLagou($target_db, $dbname, $table, $field, $type = PDO::FETCH_ASSOC){
            $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field,'',$type);

            $sql = "INSERT INTO company_team(project_id,person_name,position,usericon,weibo,resume) VALUES(?,?,?,?,?,?)";
            $st = $target_db->prepare($sql);

            foreach ($data as $d) {
                if(empty($d['project_name'])) continue;
                if($d['team'] == '""') continue;
                $result = $target_db->query("SELECT id FROM company_project WHERE project_name='".addslashes($d['project_name'])."'")->fetchAll(PDO::FETCH_COLUMN);
                if(empty($result)) continue;

                $project_id = $result[0];
                $exists = $target_db->query("SELECT id FROM company_team WHERE project_id='".$project_id."'")->fetchAll(PDO::FETCH_COLUMN);
                if($exists) continue;

                $list = json_decode($d['team'],true);
                if(empty($list)) continue;
                foreach ($list as $li) {
                    if(empty($li['name'])) continue;

                    $st->bindParam(1,$project_id,PDO::PARAM_INT);
                    $st->bindParam(2,$li['name'],PDO::PARAM_STR);
                    $st->bindParam(3,$li['job'],PDO::PARAM_STR);
                    $st->bindParam(4,$li['photo'],PDO::PARAM_STR);
                    $st->bindParam(5,$li['weibo'],PDO::PARAM_STR);
                    $st->bindParam(6,$li['info'],PDO::PARAM_STR);
                    $st->execute();
                    echo "id : ".$target_db->lastInsertId()."\r\n";
                }
            }

            echo "===============\r\n";
        }

        public function syncEvervc($target_db, $dbname, $table, $field, $type = PDO::FETCH_ASSOC){
            $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field,'',$type);

            $sql = "INSERT INTO company_team(project_id,person_name,position,usericon,resume) VALUES(?,?,?,?,?)";
            $st = $target_db->prepare($sql);

            foreach ($data as $d) {
                if(empty($d['project_name'])) continue;
                if($d['team'] == '""') continue;
                $result = $target_db->query("SELECT id FROM company_project WHERE project_name='".addslashes($d['project_name'])."'")->fetchAll(PDO::FETCH_COLUMN);
                if(empty($result)) continue;

                $project_id = $result[0];
                $exists = $target_db->query("SELECT id FROM company_team WHERE project_id='".$project_id."'")->fetchAll(PDO::FETCH_COLUMN);
                if($exists) continue;

                $list = json_decode($d['team'],true);
                if(empty($list)) continue;
                foreach ($list as $li) {
                    if(empty($li['name'])) continue;

                    $st->bindParam(1,$project_id,PDO::PARAM_INT);
                    $st->bindParam(2,$li['name'],PDO::PARAM_STR);
                    $st->bindParam(3,$li['job'],PDO::PARAM_STR);
                    $st->bindParam(4,$li['photo'],PDO::PARAM_STR);
                    $st->bindParam(5,$li['info'],PDO::PARAM_STR);
                    $st->execute();
                    echo "id : ".$target_db->lastInsertId()."\r\n";
                }
            }

            echo "===============\r\n";
        }

        public function syncHuxiu($target_db, $dbname, $table, $field, $type = PDO::FETCH_ASSOC){
            $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field,'',$type);

            $sql = "INSERT INTO company_team(project_id,person_name,position,resume) VALUES(?,?,?,?)";
            $st = $target_db->prepare($sql);

            foreach ($data as $d) {
                if(empty($d['project_name'])) continue;
                if($d['team'] == '""') continue;
                $result = $target_db->query("SELECT id FROM company_project WHERE project_name='".addslashes($d['project_name'])."'")->fetchAll(PDO::FETCH_COLUMN);
                if(empty($result)) continue;

                $project_id = $result[0];
                $exists = $target_db->query("SELECT id FROM company_team WHERE project_id='".$project_id."'")->fetchAll(PDO::FETCH_COLUMN);
                if($exists) continue;

                $list = json_decode($d['team'],true);
                if(empty($list)) continue;
                foreach ($list as $li) {
                    if(empty($li['name'])) continue;

                    $st->bindParam(1,$project_id,PDO::PARAM_INT);
                    $st->bindParam(2,$li['name'],PDO::PARAM_STR);
                    $st->bindParam(3,$li['position'],PDO::PARAM_STR);
                    $st->bindParam(4,$li['intro'],PDO::PARAM_STR);
                    $st->execute();
                    echo "id : ".$target_db->lastInsertId()."\r\n";
                }
            }

            echo "===============\r\n";
        }

        public function syncAngel($target_db, $dbname, $table, $field, $type = PDO::FETCH_ASSOC){
            $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field,'',$type);

            $sql = "INSERT INTO company_team(project_id,person_name,position,usericon,resume) VALUES(?,?,?,?,?)";
            $st = $target_db->prepare($sql);

            foreach ($data as $d) {
                if(empty($d['proj_name'])) continue;
                if($d['team'] == '""') continue;
                $result = $target_db->query("SELECT id FROM company_project WHERE project_name='".addslashes($d['proj_name'])."'")->fetchAll(PDO::FETCH_COLUMN);
                if(empty($result)) continue;

                $project_id = $result[0];
                $exists = $target_db->query("SELECT id FROM company_team WHERE project_id='".$project_id."'")->fetchAll(PDO::FETCH_COLUMN);
                if($exists) continue;

                $list = json_decode($d['team'],true);
                if(empty($list)) continue;
                foreach ($list as $li) {
                    if(empty($li['name'])) continue;
                    $usericon = empty($li['avatar']) ? '' : 'http://fs.angelcrunch.com/IMG/'.$li['avatar'];

                    $st->bindParam(1,$project_id,PDO::PARAM_INT);
                    $st->bindParam(2,$li['name'],PDO::PARAM_STR);
                    $st->bindParam(3,$li['title'],PDO::PARAM_STR);
                    $st->bindParam(4,$usericon,PDO::PARAM_STR);
                    $st->bindParam(5,$li['desc'],PDO::PARAM_STR);
                    $st->execute();
                    echo "id : ".$target_db->lastInsertId()."\r\n";
                }
            }

            echo "===============\r\n";
        }

        public function syncCyzone($target_db, $dbname, $table, $field, $type = PDO::FETCH_ASSOC){
            $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field,'',$type);

            $sql = "INSERT INTO company_team(project_id,person_name,position,usericon) VALUES(?,?,?,?)";
            $st = $target_db->prepare($sql);

            foreach ($data as $d) {
                if(empty($d['project_name'])) continue;
                if($d['team'] == '""') continue;
                $result = $target_db->query("SELECT id FROM company_project WHERE project_name='".addslashes($d['project_name'])."'")->fetchAll(PDO::FETCH_COLUMN);
                if(empty($result)) continue;

                $project_id = $result[0];
                $exists = $target_db->query("SELECT id FROM company_team WHERE project_id='".$project_id."'")->fetchAll(PDO::FETCH_COLUMN);
                if($exists) continue;

                $list = json_decode($d['team'],true);
                if(empty($list)) continue;
                foreach ($list as $li) {
                    if(empty($li['name'])) continue;

                    $st->bindParam(1,$project_id,PDO::PARAM_INT);
                    $st->bindParam(2,$li['name'],PDO::PARAM_STR);
                    $st->bindParam(3,$li['job'],PDO::PARAM_STR);
                    $st->bindParam(4,$li['img'],PDO::PARAM_STR);
                    $st->execute();
                    echo "id : ".$target_db->lastInsertId()."\r\n";
                }
            }

            echo "===============\r\n";
        }

        public function syncVc($target_db, $dbname, $table, $field, $type = PDO::FETCH_ASSOC){
            $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field,'',$type);

            $sql = "INSERT INTO company_team(project_id,person_name,position,usericon,resume) VALUES(?,?,?,?,?)";
            $st = $target_db->prepare($sql);

            foreach ($data as $d) {
                if(empty($d['project_name'])) continue;
                if($d['team'] == '""') continue;
                $result = $target_db->query("SELECT id FROM company_project WHERE project_name='".addslashes($d['project_name'])."'")->fetchAll(PDO::FETCH_COLUMN);
                if(empty($result)) continue;

                $project_id = $result[0];
                $exists = $target_db->query("SELECT id FROM company_team WHERE project_id='".$project_id."'")->fetchAll(PDO::FETCH_COLUMN);
                if($exists) continue;

                $list = json_decode($d['team'],true);
                if(empty($list)) continue;
                if(empty($list['name'])) continue;
                $st->bindParam(1,$project_id,PDO::PARAM_INT);
                $st->bindParam(2,$list['name'],PDO::PARAM_STR);
                $st->bindParam(3,$list['job'],PDO::PARAM_STR);
                $st->bindParam(4,$list['avatar'],PDO::PARAM_STR);
                $st->bindParam(5,$list['info'],PDO::PARAM_STR);
                $st->execute();
                echo "id : ".$target_db->lastInsertId()."\r\n";
                
            }

            echo "===============\r\n";
        }
    
        public function databaseObj($dbname,$host = '127.0.0.1',$user = 'root',$password = 'root'){
            $db=new PDO('mysql:dbname='.$dbname.';host='.$host,$user,$password);
            $db->exec("set names utf8");

            return $db;
        }

        public function selectData($db, $table, $field, $where = '', $type = PDO::FETCH_COLUMN){
            $data = $db->query("SELECT ".$field." FROM ".$table." ".$where)->fetchAll($type); 
            
            return $data;
        }
    }