<?php
    class Huxiu{
        public function project(){
            $db=new PDO('mysql:dbname=other_project;host=127.0.0.1','root','root');
            $db->exec("set names utf8");

            $cache = CACHE_PATH . '/huxiu/project/';
            $com_cache = CACHE_PATH . '/huxiu/company_info/';

            $sql = "INSERT INTO huxiu_project(project_html_id,project_name,icon,tag,intro,intro_info,gallery_list,advantage,results,team,creator,url,financing_stage,investors,amount,member_num,company_name,location,com_info,news,update_time) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE update_time=VALUES(update_time)";
            $st = $db->prepare($sql);

            for($i = 1; $i <= 2500; $i++) {
                $file = $cache.$i.'.html';
                if(!file_exists($file)) continue;

                $html = toUtf8(read($file));

                if(mb_strpos($html, '<title>虎嗅网</title>') && mb_strpos($html, '<img src="/static/img/404.png" alt="404.png" />')){
                    unlink($file);
                    continue;
                }

                $info = $this->getProjectInfo($html);

                $com_file = $com_cache.$i.'.txt';
                $com_info = read($com_file);

                $tags = implode(',',$info['tag']);
                $gallery = json_encode($info['gallery']);

                $team = json_encode($info['team']);
                $news = json_encode($info['news']);
                $date = date('Y-m-d H:i:s');

                $st->bindParam(1,$i,PDO::PARAM_INT);
                $st->bindParam(2,$info['project_name'],PDO::PARAM_STR);
                $st->bindParam(3,$info['icon'],PDO::PARAM_STR);
                $st->bindParam(4,$tags,PDO::PARAM_STR);
                $st->bindParam(5,$info['intro'],PDO::PARAM_STR);
                $st->bindParam(6,$info['intro_info'],PDO::PARAM_STR);
                $st->bindParam(7,$gallery,PDO::PARAM_STR);
                $st->bindParam(8,$info['advantage'],PDO::PARAM_STR);
                $st->bindParam(9,$info['results'],PDO::PARAM_STR);
                $st->bindParam(10,$team,PDO::PARAM_STR);
                $st->bindParam(11,$info['creator'],PDO::PARAM_STR);
                $st->bindParam(12,$info['url'],PDO::PARAM_STR);
                $st->bindParam(13,$info['financing_stage'],PDO::PARAM_STR);
                $st->bindParam(14,$info['investors'],PDO::PARAM_STR);
                $st->bindParam(15,$info['amount'],PDO::PARAM_STR);
                $st->bindParam(16,$info['member_num'],PDO::PARAM_STR);
                $st->bindParam(17,$info['company_name'],PDO::PARAM_STR);
                $st->bindParam(18,$info['address'],PDO::PARAM_STR);
                $st->bindParam(19,$com_info,PDO::PARAM_STR);
                $st->bindParam(20,$news,PDO::PARAM_STR);
                $st->bindParam(21,$date,PDO::PARAM_STR);

                $st->execute();
                $return = $db->lastInsertId();
                echo "id : ".$return."\r\n";

            }
        }

        //提取信息
        private function getProjectInfo($html){
            $info = array();
            $dom = phpQuery::newDocumentHTML($html);

            $info['project_name'] = trim(pq($dom['.cy-cp-name div'])->text());
            $info['icon'] = trim(pq($dom['.cy-icon-box img'])->attr('src'));

            $tag_list = $dom['.cy-tag-list ul li'];
            foreach ($tag_list as $li) {
                $info['tag'][] = trim(pq($li)->text());
            }

            $info['intro'] = trim(pq($dom['.cy-cp-intro'])->text());
            $info['intro_info'] = trim(pq($dom['.cy-cp-intro-info'])->text());

            $list = $dom['ul.gallery-img-box li'];
            foreach ($list as $li) {
                $info['gallery'][] = pq($li)->find('img')->attr('src');
            }
            $info['gallery'] = isset($info['gallery']) ? $info['gallery'] : '';
            
            $info['advantage'] = trim(pq($dom['#advantage'])->_next()->text());
            $info['results'] = trim(pq($dom['#results'])->_next()->text());

            $team_list = $dom['ul.cy-cp-team li'];
            foreach ($team_list as $k => $li) {
                $info['team'][$k]['name'] = trim(pq($li)->find('.team-personnel-name')->text());
                $info['team'][$k]['position'] = trim(pq($li)->find('.team-personnel-position')->text());
                $info['team'][$k]['intro'] = trim(pq($li)->find('.team-personnel-intro')->text());
            }
            $info['team'] = isset($info['team']) ? $info['team'] : '';

            $news_list = $dom['.cy-section-warp section'];
            foreach ($news_list as $k => $li) {
                $info['news'][$k]['title'] = trim(pq($li)->find('.cy-inner-title')->text());
                $info['news'][$k]['url'] = trim(pq($li)->find('a')->attr('href'));
            }
            $info['news'] = isset($info['news']) ? $info['news'] : '';

            $info['creator'] = trim(pq($dom['.company-info:first ul li:first span'])->text());
            $info['url'] = trim(pq($dom['.company-info:first ul li span a'])->attr('href'));
            $info['financing_stage'] = trim(pq($dom['.company-info:first ul li:eq(2) span'])->text());

            $financing = trim(pq($dom['.company-info:first ul li.cy-special-li'])->text());
            if($financing){
                $financing = explode('|', $financing);
                $info['investors'] = $financing[0];
                $info['amount'] = $financing[1];
            }else{
                $info['investors'] = '';
                $info['amount'] = '';
            }
            
            $info['member_num'] = trim(pq($dom['.company-info:first ul li:last'])->prev()->find('span')->text());
            $info['address'] = trim(pq($dom['.company-info:first ul li:last span'])->text());

            $info['company_name'] = pq($dom['.get-company-box ul li #company_name'])->text();

            $dom -> unloadDocument();

            return $info;
        }
    }