<?php 
    // IT桔子>36kr>拉勾网>天天投>创业邦>猎云>虎嗅>天使汇>创投圈
    class Nuts_company{

        public function go(){
            $target_db = $this->databaseObj('nuts_tool');
            //IT桔子
            $this->syncITjuzi($target_db, 'itjuzi_project','itjuzi_project','company,email,phone,address');
           
            //36kr
            $this->sync36kr($target_db, '36kr_project','36kr_project','company_info');
    
            //拉勾网
            $this->syncLagou($target_db,'lagou_project','lagou_project','company,address');

            //天天投
            $this->syncEvervc($target_db,'evervc_project','evervc_project','company,address');
            
            //创业邦
            $this->syncCyzone($target_db,'cyzone_project','cyzone_project','company_name,company_info');
            
            //猎云网
            //$this->syncLieyun($target_db,'other_project','lieyun_project','company');
            
            //虎嗅网
            $this->syncHuxiu($target_db,'other_project','huxiu_project','company_name');
            
            //天使汇
            $this->syncAngel($target_db,'angel_project','angel_project','org_name');
            
            //创投圈
            $this->syncVc($target_db,'vc_project','vc_project','org_name');
        }

/*
 * --------------------------------------------分割线------------------------------------------------------
 * 自定义相关函数
 */
    
        public function syncITjuzi($target_db, $dbname, $table, $field, $type = PDO::FETCH_ASSOC){
            $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field,'',$type);

            foreach ($data as $d) {
                if(empty($d['company'])) continue;
                $result = $target_db->query("SELECT company_name,email,phone,address FROM company WHERE company_name='".addslashes($d['company'])."'")->fetchAll(PDO::FETCH_ASSOC);
                if($result){
                    $d['email'] = empty($d['email']) ? $result[0]['email'] : $d['email'];
                    $d['phone'] = empty($d['phone']) ? $result[0]['phone'] : $d['phone'];
                    $d['address'] = empty($d['address']) ? $result[0]['address'] : $d['address'];
                }

                $sql = "INSERT INTO company(company_name,email,phone,address) VALUES(?,?,?,?) ON DUPLICATE KEY UPDATE email=VALUES(email),phone=VALUES(phone),address=VALUES(address)";
                $st = $target_db->prepare($sql);
                $st->bindParam(1,$d['company'],PDO::PARAM_STR);
                $st->bindParam(2,$d['email'],PDO::PARAM_STR);
                $st->bindParam(3,$d['phone'],PDO::PARAM_STR);
                $st->bindParam(4,$d['address'],PDO::PARAM_STR);
                $st->execute(); 
            }

            echo "===============\r\n";
        }

        public function sync36kr($target_db, $dbname, $table, $field){
            $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field);

            foreach ($data as $d) {
                $d = json_decode($d,true);
                if(empty($d)) continue;

                $result = $target_db->query("SELECT company_name,address FROM company WHERE company_name='".addslashes($d['Name'])."'")->fetchAll(PDO::FETCH_ASSOC);
                if($result){
                    $d['Address'] = empty($d['Address']) ? $result[0]['address'] : $d['Address'];
                }

                $sql = "INSERT INTO company(company_name,address) VALUES(?,?) ON DUPLICATE KEY UPDATE address=VALUES(address)";
                $st = $target_db->prepare($sql);
                $st->bindParam(1,$d['Name'],PDO::PARAM_STR);
                $st->bindParam(2,$d['Address'],PDO::PARAM_STR);
                $st->execute(); 
            }
            echo "===============\r\n";
        }

        public function syncLagou($target_db, $dbname, $table, $field, $type = PDO::FETCH_ASSOC){
            $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field,'',$type);

            foreach ($data as $d) {
                if(empty($d['company'])) continue;
                $d['address'] = json_decode($d['address'],true);

                $result = $target_db->query("SELECT company_name,address FROM company WHERE company_name='".addslashes($d['company'])."'")->fetchAll(PDO::FETCH_ASSOC);
                if($result){
                    $d['address'] = (empty($d['address']) || mb_strlen($d['address'][0]) < mb_strlen($result[0]['address'])) ? $result[0]['address'] : $d['address'][0];
                }else{
                    $d['address'] = empty($d['address']) ? '': $d['address'][0];
                }

                $sql = "INSERT INTO company(company_name,address) VALUES(?,?) ON DUPLICATE KEY UPDATE address=VALUES(address)";
                $st = $target_db->prepare($sql);
                $st->bindParam(1,$d['company'],PDO::PARAM_STR);
                $st->bindParam(2,$d['address'],PDO::PARAM_STR);
                $st->execute();
                echo $target_db->lastInsertId()."\r\n";
            }

            echo "===============\r\n";
        }

        public function syncEvervc($target_db, $dbname, $table, $field, $type = PDO::FETCH_ASSOC){
            $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field,'',$type);

            foreach ($data as $d) {
                if(empty($d['company'])) continue;

                $result = $target_db->query("SELECT company_name,address FROM company WHERE company_name='".addslashes($d['company'])."'")->fetchAll(PDO::FETCH_ASSOC);
                if($result){
                    $d['address'] = (empty($d['address']) || mb_strlen($d['address']) < mb_strlen($result[0]['address'])) ? $result[0]['address'] : $d['address'];
                }

                $sql = "INSERT INTO company(company_name,address) VALUES(?,?) ON DUPLICATE KEY UPDATE address=VALUES(address)";
                $st = $target_db->prepare($sql);
                $st->bindParam(1,$d['company'],PDO::PARAM_STR);
                $st->bindParam(2,$d['address'],PDO::PARAM_STR);
                $st->execute();
                echo $target_db->lastInsertId()."\r\n";
            }

            echo "===============\r\n";
        }

        public function syncCyzone($target_db, $dbname, $table, $field, $type = PDO::FETCH_ASSOC){
            $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field,'',$type);

            foreach ($data as $d) {
                if(empty($d['company_name']) || $d['company_name'] == '无' || $d['company_name'] == '暂无') continue;
                $d['company_info'] = json_decode($d['company_info'],true);
                $d['address'] = isset($d['company_info']['address']) ? $d['company_info']['address'] : '';

                $result = $target_db->query("SELECT company_name,address FROM company WHERE company_name='".addslashes($d['company_name'])."'")->fetchAll(PDO::FETCH_ASSOC);
                if($result){
                    $d['address'] = (empty($d['address']) || mb_strlen($d['address']) < mb_strlen($result[0]['address'])) ? $result[0]['address'] : $d['address'];
                }

                $sql = "INSERT INTO company(company_name,address) VALUES(?,?) ON DUPLICATE KEY UPDATE address=VALUES(address)";
                $st = $target_db->prepare($sql);
                $st->bindParam(1,$d['company_name'],PDO::PARAM_STR);
                $st->bindParam(2,$d['address'],PDO::PARAM_STR);
                $st->execute();
                echo $target_db->lastInsertId()."\r\n";
            }

            echo "===============\r\n";
        }

        public function syncLieyun($target_db, $dbname, $table, $field, $type = PDO::FETCH_ASSOC){
            $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field,'',$type);

            foreach ($data as $d) {
                if(empty($d['company'])) continue;
                $result = $target_db->query("SELECT company_name FROM company WHERE company_name='".addslashes($d['company'])."'")->fetchAll(PDO::FETCH_ASSOC);
                if(!$result){
                    $sql = "INSERT INTO company(company_name) VALUES(?)";
                    $st = $target_db->prepare($sql);
                    $st->bindParam(1,$d['company'],PDO::PARAM_STR);
                    $st->execute(); 
                    echo $target_db->lastInsertId()."\r\n";
                }   
            }

            echo "===============\r\n";
        }

        public function syncHuxiu($target_db, $dbname, $table, $field, $type = PDO::FETCH_ASSOC){
            $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field,'',$type);

            foreach ($data as $d) {
                if(empty($d['company_name'])) continue;
                $result = $target_db->query("SELECT company_name FROM company WHERE company_name='".addslashes($d['company_name'])."'")->fetchAll(PDO::FETCH_ASSOC);
                if(!$result){
                    $sql = "INSERT INTO company(company_name) VALUES(?)";
                    $st = $target_db->prepare($sql);
                    $st->bindParam(1,$d['company_name'],PDO::PARAM_STR);
                    $st->execute(); 
                    echo $target_db->lastInsertId()."\r\n";
                }   
            }

            echo "===============\r\n";
        }

        public function syncAngel($target_db, $dbname, $table, $field, $type = PDO::FETCH_ASSOC){
            $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field,'',$type);

            foreach ($data as $d) {
                if(empty($d['org_name'])) continue;
                $result = $target_db->query("SELECT company_name FROM company WHERE company_name='".addslashes($d['org_name'])."'")->fetchAll(PDO::FETCH_ASSOC);
                if(!$result){
                    $sql = "INSERT INTO company(company_name) VALUES(?)";
                    $st = $target_db->prepare($sql);
                    $st->bindParam(1,$d['org_name'],PDO::PARAM_STR);
                    $st->execute(); 
                }   
            }

            echo "===============\r\n";
        }
    
        public function databaseObj($dbname,$host = '127.0.0.1',$user = 'root',$password = 'root'){
            $db=new PDO('mysql:dbname='.$dbname.';host='.$host,$user,$password);
            $db->exec("set names utf8");

            return $db;
        }

        public function selectData($db, $table, $field, $where = '', $type = PDO::FETCH_COLUMN){
            $data = $db->query("SELECT ".$field." FROM ".$table." ".$where)->fetchAll($type); 
            
            return $data;
        }
    }