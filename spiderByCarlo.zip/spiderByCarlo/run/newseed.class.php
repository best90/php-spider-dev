<?php

/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2016/6/30
 * Time: 11:08
 */
class Newseed
{
    public $db;
    
    public function __construct(){
        $this->db = new PDO('mysql:dbname=newseed_project;host=127.0.0.1','root','root');
        $this->db->exec("set names utf8");
    }

    public function project(){
        $cache = CACHE_PATH . '/newseed/project/';

        $sql = "INSERT INTO newseed_project(project_html_id,project_name,logo,intro,url,tags,company,team,funding,undefined,update_time) VALUES(:pid,:nam,:log,:intro,:url,:tag,:com,:tea,:fun,:unde,:utime) ON DUPLICATE KEY UPDATE update_time=VALUES(update_time)";

        $st = $this->db->prepare($sql);

        for($i = 1; $i <= 52000; $i ++) {
            $file = $cache . $i . '.html';
            if (!file_exists($file)) continue;

            $html = toUtf8(read($file));
            if (!$this->checkFile($html)) {
                unlink($file);
                continue;
            }

            $info = $this->getProjectInfo($html);

            $tags = implode(',',$info['tag']);
            $team = json_encode($info['team']);
            $funding = json_encode($info['funding']);
            $undefined = json_encode($info['other']);
            $date = date('Y-m-d H:i:s');

            $st->bindParam(':pid',$i);
            $st->bindParam(':nam',$info['project_name']);
            $st->bindParam(':log',$info['icon']);
            $st->bindParam(':intro',$info['intro']);
            $st->bindParam(':url',$info['url']);
            $st->bindParam(':tag',$tags);
            $st->bindParam(':com',$info['company']);
            $st->bindParam(':tea',$team);
            $st->bindParam(':fun',$funding);
            $st->bindParam(':unde',$undefined);
            $st->bindParam(':utime',$date);

            $st->execute();
            echo "Newseed Id : ".$this->db->lastInsertId()."\r\n";
        }
    }

    //校验文件
    private function checkFile($html){
        if(mb_strpos($html,'<title>页面没有找到</title>') || mb_strpos($html,'</html>') === false) return false;
        return true;
    }

    /**
     * 提取项目信息
     * @param string $html
     * @return array
     */
    private function getProjectInfo($html){
        $info = [];
        $dom = phpQuery::newDocumentHTML($html);
        $title = trim(pq($dom['.record .title'])->text());
        $info['project_name'] = trim(mb_substr($title,0,mb_strpos($title,'+')));

        $info['icon'] = pq($dom['.record .img img'])->attr('src');
        if($info['icon'] == 'http://pic.pedaily.cn/newseed/noproject.png'){
            $info['icon'] = NULL;
        }

        $info['intro'] = trim(pq($dom['.record .info p:last'])->text());
        $info['url'] = pq($dom['.record .info .link a'])->attr('href');

        $info['tag'] = [];
        $list = $dom['.record .info .keyword a'];
        foreach ($list as $li) {
            $info['tag'][] = trim(pq($li)->text());
        }

        $info['team'] = [];
        $team = $dom['ul.record li'];
        foreach ($team as $k => $t) {
            $name = trim(pq($t)->find('.title')->text());
            $position = trim(pq($t)->find('.title span')->text());
            $info['team'][$k]['name'] = trim(mb_substr($name,0,mb_strpos($name,$position)));
            $info['team'][$k]['avatar'] = pq($t)->find('.img img')->attr('src');
            $info['team'][$k]['position'] = $position;
            $info['team'][$k]['intro'] = trim(pq($t)->find('.info p')->text());
        }

        $info['company'] = trim(pq($dom['.company p a'])->text());

        $string = trim(pq($dom['.record .info p:first'])->text());
        $string = explode('/',$string);
        $info['other'] = array_map('trim', $string);

        $info['funding'] = [];
        $funding = $dom['.record-table tr'];
        foreach ($funding as $k => $f){
            $info['funding'][$k]['stage'] = trim(pq($f)->find('.td1 span')->text());
            $info['funding'][$k]['investors'] = trim(pq($f)->find('.td4')->text());
            $info['funding'][$k]['amount'] = trim(pq($f)->find('.td5')->text());
            $info['funding'][$k]['date'] = trim(pq($f)->find('.td2')->text());
        }

        $dom->unloadDocument();
        return $info;
    }
}