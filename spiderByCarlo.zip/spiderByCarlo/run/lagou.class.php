<?php
    class Lagou{
        public function project(){
            $db=new PDO('mysql:dbname=lagou_project;host=127.0.0.1','root','root');
            $db->exec("set names utf8");

            $cache = CACHE_PATH . '/lagou/company/';

            $sql = "INSERT INTO lagou_project(project_html_id,project_name,logo,intro,industry,location,scale,stage,url,company,company_info,address,company_img,product,team,milestone,update_time) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE update_time=VALUES(update_time)";
            $st = $db->prepare($sql);

            for ($i=1; $i <= 130000; $i++) {
                $file = $cache.$i.'.html';
                if(!file_exists($file)) continue;

                if(!$this->checkFile($file)){
                    unlink($file);
                    continue;
                }

                $html = toUtf8(read($file));
                $info = $this->getProjectInfo($html);

                $address = json_encode($info['address']);
                $pic = json_encode($info['company_img']);
                $product = json_encode($info['product']);
                $team = json_encode($info['team']);
                $milestone = json_encode($info['milestone']);
                $date = date('Y-m-d H:i:s');

                $st->bindParam(1,$i,PDO::PARAM_INT);
                $st->bindParam(2,$info['project_name'],PDO::PARAM_STR);
                $st->bindParam(3,$info['logo'],PDO::PARAM_STR);
                $st->bindParam(4,$info['intro'],PDO::PARAM_STR);
                $st->bindParam(5,$info['industry'],PDO::PARAM_STR);
                $st->bindParam(6,$info['location'],PDO::PARAM_STR);
                $st->bindParam(7,$info['scale'],PDO::PARAM_STR);
                $st->bindParam(8,$info['stage'],PDO::PARAM_STR);
                $st->bindParam(9,$info['url'],PDO::PARAM_STR);
                $st->bindParam(10,$info['company'],PDO::PARAM_STR);
                $st->bindParam(11,$info['company_info'],PDO::PARAM_STR);
                $st->bindParam(12,$address,PDO::PARAM_STR);
                $st->bindParam(13,$pic,PDO::PARAM_STR);
                $st->bindParam(14,$product,PDO::PARAM_STR);
                $st->bindParam(15,$team,PDO::PARAM_STR);
                $st->bindParam(16,$milestone,PDO::PARAM_STR);
                $st->bindParam(17,$date,PDO::PARAM_STR);
              

                $st->execute();
                $return = $db->lastInsertId();
                echo "id : ".$return."\r\n";

            }
        }

        //校验文件
        private function checkFile($file){
            if(filesize($file) <= 5120) return false;
            return true;
        }

        //提取信息
        private function getProjectInfo($html){
            $info = array();
            $dom = phpQuery::newDocumentHTML($html);

            $info['project_name'] = trim(pq($dom['.company_main h1'])->text());
            $info['intro'] = trim(pq($dom['.company_word'])->text());
            $info['logo'] = trim(pq($dom['.top_info_wrap>img'])->attr('src'));
            $info['industry'] = trim(pq($dom['.item_content ul li i.type'])->_next()->text());
            $info['location'] = trim(pq($dom['.item_content ul li i.address'])->_next()->text());
            $info['stage'] = trim(pq($dom['.item_content ul li i.process'])->_next()->text());
            $info['scale'] = trim(pq($dom['.item_content ul li i.number'])->_next()->text());

            $info['company'] = trim(pq($dom['.company_main h1 a'])->attr('title'));
            $info['company_info'] = trim(pq($dom['.company_intro_text .company_content'])->text());
            $info['url'] = trim(pq($dom['.company_main h1 a'])->attr('href'));

            $list = $dom['ul.con_mlist_ul li'];
            $info['address'] = array();
            foreach ($list as $li) {
                $info['address'][] = trim(pq($li)->find('.mlist_li_desc')->text());
            }

            $list = $dom['ul.company_img li'];
            $info['company_img'] = array();
            foreach ($list as $li) {
                $info['company_img'][] = trim(pq($li)->attr('data-item'));
            }

            $info['product'] = array();
            $list = $dom['#company_products .product_item'];
            foreach ($list as $k => $li) {
                $info['product'][$k]['product_name'] = trim(pq($li)->find('.product_url a.url_valid')->text());
                $info['product'][$k]['product_url'] = trim(pq($li)->find('.product_url a.url_valid')->attr('href'));

                $type = pq($li)->find('.product_details ul.clearfix li');
                foreach ($type as $t) {
                    $info['product'][$k]['type'][] = trim(pq($t)->text());
                }

                $info['product'][$k]['img'] = trim(pq($li)->find('.product_url a.url_valid')->attr('href'));
                $info['product'][$k]['intro'] = trim(pq($li)->find('.product_profile')->text());
            }

            $list = $dom['ul.manager_list li'];
            $info['team'] = array();
            foreach ($list as $k => $li) {
                $info['team'][$k]['name'] = trim(pq($li)->find('.item_manager_name span')->text());
                $info['team'][$k]['weibo'] = trim(pq($li)->find('.item_manager_name a')->attr('href'));
                $info['team'][$k]['job'] = trim(pq($li)->find('.item_manager_title')->text());
                $info['team'][$k]['info'] = trim(pq($li)->find('.item_manager_content')->text());
                $info['team'][$k]['photo'] = trim(pq($li)->find('img')->attr('src'));
                if(strpos($info['team'][$k]['photo'], 'Status 405')) $info['team'][$k]['photo'] = '';
            }

            $list = $dom['ul.history_ul li'];
            foreach ($list as $k => $li) {
                $info['milestone'][$k]['title'] = trim(pq($li)->find('p.desc_title a')->text());
                $info['milestone'][$k]['desc'] = trim(pq($li)->find('div.desc_intro')->text());
                $info['milestone'][$k]['type'] = trim(pq($li)->find('div.li_type_icon')->attr('title'));
                $year = trim(pq($li)->find('div.li_date .date_year')->text());
                $info['milestone'][$k]['time'] = $this->string2Date($year).trim(pq($li)->find('div.li_date .date_day')->text());
            }
            $info['milestone'] = isset($info['milestone']) ? $info['milestone'] : '';

            $dom -> unloadDocument();

            return $info;
        }

        //日期转换
        private function string2Date($string){
            $arr = array(
                    ' Jan' => '.01.',
                    ' Feb' => '.02.',
                    ' Mar' => '.03.',
                    ' Apr' => '.04.',
                    ' May' => '.05.',
                    ' June' => '.06.',
                    ' July' => '.07.',
                    ' Aug' => '.08.',
                    ' Sept' => '.09.',
                    ' Oct' => '.10.',
                    ' Nov' => '.11.',
                    ' Dec' => '.12.'
                );
            return strtr($string,$arr);
        }
    }