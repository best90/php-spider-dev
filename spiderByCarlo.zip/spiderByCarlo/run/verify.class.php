<?php
    require(ROOT_PATH . '/lib/smtp.class.php');
    /**
    *校验
    */
    class Verify{
        public function test(){
            $db=new PDO('mysql:dbname=investor_hub;host=127.0.0.1','root','root');
            $db->exec("set names utf8");

            $res = $db->query("SELECT id,email FROM investor ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);
            
            $i = 0;
            foreach ($res as $re) {
                if(empty($re['email'])) continue;

                $toEmail = $re['email'];
                $title = '节日快乐！';
                $result = $this->send_mail($toEmail,$title);
                $return = json_decode($result,true);
                if($return['message'] == 'success'){
                    $sql = "UPDATE investor set status=1 WHERE id=".$re['id'];
                    $return = $db->exec($sql);
                    echo $re['email']." : OK\r\n";
                }

                $i ++;
                if($i > 195) die;
                sleep(1);
            }
        }

        public function send(){
            $db=new PDO('mysql:dbname=investor_hub;host=127.0.0.1','root','root');
            $db->exec("set names utf8");

            $res = $db->query("SELECT id,email FROM investor ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);
            
            foreach ($res as $re) {
                if(empty($re['email'])) continue;

                $mailto= $re['email'];  //收件人
                $subject= "六一儿童节快乐！"; //邮件主题
                $body= '祝您节日快乐！';  //邮件内容
                $msg = $this->sendmailto($mailto,$subject,$body);
                sleep(1);
            }
        }

        private function sendMailTo($mailto, $mailsub, $mailbd){
            $smtpserver     = "smtp.126.com"; //SMTP服务器
            $smtpserverport = 25; //SMTP服务器端口
            $smtpusermail   = "php_mail@126.com"; //SMTP服务器的用户邮箱
            $smtpemailto    = $mailto;
            $smtpuser       = "php_mail@126.com"; //SMTP服务器的用户帐号
            $smtppass       = "7099793zx"; //SMTP服务器的用户密码
            $mailsubject    = $mailsub; //邮件主题
            $mailsubject    = "=?UTF-8?B?" . base64_encode($mailsubject) . "?="; //防止乱码
            $mailbody       = $mailbd; //邮件内容
            //$mailbody = "=?UTF-8?B?".base64_encode($mailbody)."?="; //防止乱码
            $mailtype       = "HTML"; //邮件格式（HTML/TXT）,TXT为文本邮件. 139邮箱的短信提醒要设置为HTML才正常
            ##########################################
            $smtp           = new smtp($smtpserver, $smtpserverport, true, $smtpuser, $smtppass); //这里面的一个true是表示使用身份验证,否则不使用身份验证.
            //$smtp->debug    = TRUE; //是否显示发送的调试信息
            $msg = $smtp->sendmail($smtpemailto, $smtpusermail, $mailsubject, $mailbody, $mailtype);
            return $msg;
        }

        //第三方邮件发送
        private function send_mail($toEmail,$subject='') {
            $url = 'http://sendcloud.sohu.com/webapi/mail.send.json';
            $API_USER = 'vip1991_test_4pvUIb';
            $API_KEY = 'YqleDtoM1UkZumZw';

            //不同于登录SendCloud站点的帐号，您需要登录后台创建发信子帐号，使用子帐号和密码才可以进行邮件的发送。
            $param = array(
                'api_user' => $API_USER,
                'api_key' => $API_KEY,
                'from' => 'service@taobao.com',
                'fromname' => '淘宝客服系统',
                'to' => $toEmail,
                'subject' => $subject,
                'html' => '你太棒了！你已成功的从SendCloud发送了一封测试邮件，接下来快登录前台去完善账户信息吧！',
                'resp_email_id' => 'true'
                );
              
            $data = http_build_query($param);

            $options = array(
                'http' => array(
                'method'  => 'POST',
                'header' => 'Content-Type: application/x-www-form-urlencoded',
                'content' => $data
            ));

            $context  = stream_context_create($options);
            $result = file_get_contents($url, false, $context);

            return $result;
        }
    } 