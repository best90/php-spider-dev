<?php
    class Sogou{
        public function zhihu(){
            $db=new PDO('mysql:dbname=industry;host=127.0.0.1','root','root');
            $db->exec("set names utf8");

            $cache = CACHE_PATH . '/sogou/zhihu/';

            $res = $db->query("SELECT id,name FROM zhihu")->fetchAll(PDO::FETCH_ASSOC);

            $sql = "UPDATE zhihu SET info=:info WHERE id=:id";
            $st = $db->prepare($sql);

            foreach ($res as $re) {
                $file = $cache.$re['id'].'.html';
                if(!file_exists($file)) continue;

                $html = toUtf8(read($file));
                $list = $this->getZhihuList($html);

                $info = json_encode($list);
                
                $st->bindParam(':id',$re['id']);
                $st->bindParam(':info',$info);

                $st->execute();
            }
        }

        public function weixin(){
            $db=new PDO('mysql:dbname=industry;host=127.0.0.1','root','root');
            $db->exec("set names utf8");

            $cache = CACHE_PATH . '/sogou/weixin/';

            $res = $db->query("SELECT id,name FROM weixin")->fetchAll(PDO::FETCH_ASSOC);

            $sql = "UPDATE weixin SET info=:info WHERE id=:id";
            $st = $db->prepare($sql);

            foreach ($res as $re) {
                $file = $cache.$re['id'].'.html';
                if(!file_exists($file)) continue;

                $html = toUtf8(read($file));
                $list = $this->getWeixinList($html);

                $info = json_encode($list);
                
                $st->bindParam(':id',$re['id']);
                $st->bindParam(':info',$info);

                $st->execute();
            }
        }

        //提取知乎信息
        private function getZhihuList($html){
            $info = array();
            $dom = phpQuery::newDocumentHTML($html);

            $list = $dom['div.box-result div.result-about-list'];
            foreach ($list as $k => $li) {
                $info[$k]['title'] = trim(pq($li)->find('.about-list-title')->text());
                $info[$k]['info'] = trim(pq($li)->find('p.about-text a')->text());
                $info[$k]['url'] = trim(pq($li)->find('.about-list-title a')->attr('href'));
            }

            $dom -> unloadDocument();
            return $info;
        }

        //提取微信文章信息
        private function getWeixinList($html){
            $info = array();
            $dom = phpQuery::newDocumentHTML($html);

            $list = $dom['div.results div.wx-rb'];
            foreach ($list as $k => $li) {
                $info[$k]['title'] = trim(pq($li)->find('h4 a')->text());
                $info[$k]['info'] = trim(pq($li)->find('.txt-box p')->text());
                $info[$k]['url'] = trim(pq($li)->find('h4 a')->attr('href'));
            }

            $dom -> unloadDocument();
            return $info;
        }
    }