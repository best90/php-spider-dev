<?php 
    // 图片整改成本地对应的文件
    class Nuts_image{

        public function icon(){
            $db = $this->databaseObj('nuts_tool');
            $data = $this->selectData($db,'company_project', 'id,icon','', PDO::FETCH_ASSOC);

            $cache = '/icon/';

            $sql = "UPDATE company_project SET icon = :icon WHERE id = :id";
            $st = $db->prepare($sql);
            foreach ($data as $d) {
                if(empty($d['icon'])) continue;
                
                $dirname = substr($d['id'], -4);
                $sub_dir = $cache.$dirname.'/';
                $file = $sub_dir.$d['id'].'.png';
                     
                echo $d['id']."\r\n";
                $st->bindParam(':icon',$file);
                $st->bindParam(':id',$d['id']);
                $st->execute();
            }
            echo "===============\r\n";
        }

        public function pic(){
            $db = $this->databaseObj('nuts_tool');
            $data = $this->selectData($db,'company_project', 'id,main_pic','', PDO::FETCH_ASSOC);

            $cache = '/main_pic/';

            $sql = "UPDATE company_project SET main_pic = :main_pic WHERE id = :id";
            $st = $db->prepare($sql);
            foreach ($data as $d) {
                if(empty($d['main_pic'])) continue;
                
                $dirname = substr($d['id'], -4);
                $sub_dir = $cache.$dirname.'/';

                $pic_list = explode(',', $d['main_pic']);
                $file = [];
                foreach ($pic_list as $k => $pic) {
                    $dir = CACHE_PATH.'/nuts_tool'.$sub_dir.$d['id'].'_'.$k.'.jpg';
                    if(!file_exists($dir)) continue;
                    $file[] = $sub_dir.$d['id'].'_'.$k.'.jpg';
                }
                $main_pic = implode(',', $file);
                
                echo $d['id'];
                echo "\r\n";
           
                $st->bindParam(':main_pic',$main_pic);
                $st->bindParam(':id',$d['id']);
                $st->execute();
            }
            echo "===============\r\n";
        }

        public function avatar(){
            $db = $this->databaseObj('nuts_tool');
            $data = $this->selectData($db,'company_team', 'id,usericon','', PDO::FETCH_ASSOC);

            $cache = '/avatar/';

            $sql = "UPDATE company_team SET usericon = :avatar WHERE id = :id";
            $st = $db->prepare($sql);
            foreach ($data as $d) {
                if(empty($d['usericon'])) continue;
                
                $dirname = substr($d['id'], -4);
                $sub_dir = $cache.$dirname.'/';
                $file = $sub_dir.$d['id'].'.png';
                     
                echo $d['id']."\r\n";
                $st->bindParam(':avatar',$file);
                $st->bindParam(':id',$d['id']);
                $st->execute();
            }
            echo "===============\r\n";
        }
    
        public function databaseObj($dbname,$host = '127.0.0.1',$user = 'root',$password = 'root'){
            $db=new PDO('mysql:dbname='.$dbname.';host='.$host,$user,$password);
            $db->exec("set names utf8");

            return $db;
        }

        public function selectData($db, $table, $field, $where = '', $type = PDO::FETCH_COLUMN){
            $data = $db->query("SELECT ".$field." FROM ".$table." ".$where)->fetchAll($type); 
            
            return $data;
        }
    }