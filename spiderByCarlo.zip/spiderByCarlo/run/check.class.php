<?php
    class Check{
        public function crawl36krEmployee(){
            $db=new PDO('mysql:dbname=36kr_project;host=127.0.0.1','root','root');
            $db->exec("set names utf8");

            $cache = CACHE_PATH . '/36kr/employee/';

            $ids = $db->query("SELECT company_id FROM 36kr_list WHERE employee_status != 1 ORDER BY id ASC")->fetchAll(PDO::FETCH_COLUMN);
            
            foreach ($ids as $i) {
                $file = $cache.$i.'.txt';
                if(file_exists($file)){
                    $content = file_get_contents($file);
                    $info = json_decode($content, true);

                    if($info['code'] != 0){

                        $status = $info['msg'] == '公司不存在' ? 2 : -1;
                        $sql = "UPDATE 36kr_list set employee_status=".$status." WHERE company_id=".$i;
                        $return = $db->exec($sql);
                        echo "Error : ".$return."\r\n";
                        unlink($file);
                    }else{
                        $status = $info['msg'] == '请登录后再访问' ? -1 : 1;
                        $sql = "UPDATE 36kr_list set employee_status=".$status." WHERE company_id=".$i;
                        $return = $db->exec($sql);
                        //echo "Crawl : ".$return."\r\n";
                        if($info['msg'] == '请登录后再访问') unlink($file);
                    }
                }  
            }
        }

        public function crawl36krCompany(){
            $db=new PDO('mysql:dbname=36kr_project;host=127.0.0.1','root','root');
            $db->exec("set names utf8");

            $cache = CACHE_PATH . '/36kr/company/';

            $ids = $db->query("SELECT company_id FROM 36kr_list WHERE status != 1 ORDER BY id ASC")->fetchAll(PDO::FETCH_COLUMN);
            
            foreach ($ids as $i) {
                $file = $cache.$i.'.txt';
                if(file_exists($file)){
                    $content = file_get_contents($file);

                    if(mb_strpos($content, '您请求的过于频繁，请稍后再试！') || (mb_strpos($content, '"code":0') === false && mb_strpos($content, '"code":404') === false)){
                        /*$sql = "UPDATE 36kr_list set status=-1 WHERE company_id=".$i;
                        $return = $db->exec($sql);
                        echo "Error : ".$return."\r\n";*/
                        unlink($file);
                    }else{
                        

                        $sql = "UPDATE 36kr_list set status=1 WHERE company_id=".$i;
                        $return = $db->exec($sql);
                        //echo "Crawl : ".$return."\r\n";
                        $info = json_decode($content,true);
                        if(!isset($info['data']['company']['pictures']) && $info['code'] != 404){
                           $row = $db->exec("UPDATE 36kr_list set status = -1 WHERE company_id=".$i);
                           echo 'error : '.$row."\r\n";
                           continue;
                        }
                    }
                }  
            }
        }
    }