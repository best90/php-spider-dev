<?php
    class Vc{
        public function project(){
            $db=new PDO('mysql:dbname=vc_project;host=127.0.0.1','root','root');
            $db->exec("set names utf8");

            $cache = CACHE_PATH . '/vc/project/';

            $ids = $db->query("SELECT url FROM vc_list ORDER BY id ASC")->fetchAll(PDO::FETCH_COLUMN);

            $sql = "INSERT INTO vc_project(project_html_id,project_name,logo,intro,pic,industry,local,status,scale,stage,url,ios,video,android,highlight,team,milestone,update_time) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE update_time=VALUES(update_time)";
            $st = $db->prepare($sql);

            foreach ($ids as $k => $i) {
                //if($k < 1700) continue;
                $arr = explode('/', $i);
                $file = $cache.end($arr).'.html';

                $html = toUtf8(read($file));
                $info = $this->getProjectInfo($html);
                
                if(!isset($info['industry']) || mb_strpos($html, '该页面正在被服务器约谈......')) continue;
                   
                $id = end($arr);
                $pic = json_encode($info['pic']);
                $industry = implode(',', $info['industry']);

                $team = json_encode($info['team']);
                $milestone = json_encode($info['trends']);
                $date = date('Y-m-d H:i:s');

                $st->bindParam(1,$id,PDO::PARAM_INT);
                $st->bindParam(2,$info['project_name'],PDO::PARAM_STR);
                $st->bindParam(3,$info['logo'],PDO::PARAM_STR);
                $st->bindParam(4,$info['intro'],PDO::PARAM_STR);
                $st->bindParam(5,$pic,PDO::PARAM_STR);
                $st->bindParam(6,$industry,PDO::PARAM_STR);
                $st->bindParam(7,$info['local'],PDO::PARAM_STR);
                $st->bindParam(8,$info['status'],PDO::PARAM_STR);
                $st->bindParam(9,$info['scale'],PDO::PARAM_STR);
                $st->bindParam(10,$info['stage'],PDO::PARAM_STR);
                $st->bindParam(11,$info['url'],PDO::PARAM_STR);
                $st->bindParam(12,$info['ios'],PDO::PARAM_STR);
                $st->bindParam(13,$info['video'],PDO::PARAM_STR);
                $st->bindParam(14,$info['android'],PDO::PARAM_STR);
                $st->bindParam(15,$info['highlight'],PDO::PARAM_STR);
                $st->bindParam(16,$team,PDO::PARAM_STR);
                $st->bindParam(17,$milestone,PDO::PARAM_STR);
                $st->bindParam(18,$date,PDO::PARAM_STR);

                $st->execute();
                $return = $db->lastInsertId();
                echo "id : ".$return."\r\n";

            }
        }

        //提取信息
        private function getProjectInfo($html){
            $info = array();
            $dom = phpQuery::newDocumentHTML($html);

            $info['project_name'] = trim(pq($dom['.span8 h4 a.user-link'])->text());
            $info['intro'] = trim(pq($dom['.span8 p.pitch'])->text());
            $info['logo'] = trim(pq($dom['.startuplogo img'])->attr('src'));
            
            $tags = pq($dom['td.label_icon'])->_next()->find('span');
            foreach ($tags as $tag) {
                $info['industry'][] = trim(pq($tag)->text());
            }


            $info['local'] = trim(pq($dom['td.local_icon'])->_next()->text());

            $info['url'] = '';
            $info['ios'] = '';
            $info['android'] = '';
            $info['video'] = '';
            $urls = $dom['.startup-other-info .f14'];
            foreach ($urls as $url) {
                $text = trim(pq($url)->text());
                if(mb_strpos($text, '项目网址') !== false){
                    $info['url'] = pq($url)->find('a')->attr('href');
                }elseif (mb_strpos($text, '苹果应用') !== false) {
                    $info['ios'] = pq($url)->find('a')->attr('href');
                }elseif (mb_strpos($text, '安卓应用') !== false) {
                    $info['android'] = pq($url)->find('a')->attr('href');
                }elseif (mb_strpos($text, '视频网址') !== false) {
                    $info['video'] = pq($url)->find('a')->attr('href');
                }
            }

            $info['status'] = trim(pq($dom['td.status_icon'])->_next()->find('span:first')->text());
            $info['scale'] = trim(pq($dom['td.status_icon'])->_next()->find('span:last')->text());
            $info['stage'] = trim(pq($dom['td.phrase_icons'])->_next()->text());


            $divs = $dom['.sub-section'];
            foreach ($divs as $div) {
                $text = trim(pq($div)->find('h4')->text());
                if($text == '项目亮点'){
                    $info['highlight'] = trim(pq($div)->find('p')->text());
                    break;
                }
            }

            $imgs = $dom['#startup_photos_block .startup-photo img'];
            $info['pic'] = array();
            foreach ($imgs as $img) {
                $info['pic'][] = pq($img)->attr('src');
            }
            

            $trends_list = $dom['#updates div.startup_status_box'];
            foreach ($trends_list as $k => $li) {
                $info['trends'][$k]['title'] = trim(pq($li)->find('div.contents div.text')->text());
                $info['trends'][$k]['type'] = trim(pq($li)->find('div.contents span')->text());
                $info['trends'][$k]['time'] = trim(pq($li)->find('div.contents div.date')->text());
            }
            $info['trends'] = isset($info['trends']) ? $info['trends'] : '';

            $info['team']['name'] = trim(pq($dom['.block-padding div.name a'])->text());
            $info['team']['avatar'] = trim(pq($dom['.block-padding .avatar_link img'])->attr('src'));
            $info['team']['job'] = trim(pq($dom['.block-padding div.name'])->text(),' · '.$info['team']['name']);
            $info['team']['info'] = trim(pq($dom['.block-padding div.info .pitch'])->text());
            $info['team']['info'] .= ' '.trim(pq($dom['.block-padding div.info .backgrounds'])->text());
            $dom -> unloadDocument();

            return $info;
        }
    }