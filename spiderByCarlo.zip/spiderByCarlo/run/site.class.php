<?php
    class Site{
        public function alexa(){
            $db=new PDO('mysql:dbname=site;host=127.0.0.1','root','root');
            $db->exec("set names utf8");
            $cache = CACHE_PATH . '/site/alexa/';

            $res = $db->query("SELECT id from site ORDER BY id ASC")->fetchAll(PDO::FETCH_COLUMN);

            $sql = "UPDATE alexa SET alexa_rank=:rank,data=:data,update_time=:time WHERE id=:id";
            $st = $db->prepare($sql);
                
            foreach ($res as $i) {
                $file = $cache.$i.'.html';
                if(!file_exists($file)) continue;

                $html = toUtf8(read($file));

                $alexa_info = $this->getAlexaInfo($html);
                
                $alexa_rank = $alexa_info['alexa_rank'];
                $data = json_encode($alexa_info);
                $date = date('Y-m-d H:i:s');

                $st->bindParam(':rank', $alexa_rank);
                $st->bindParam(':data', $data);
                $st->bindParam(':time', $date);
                $st->bindParam(':id', $i);
                
                $st->execute();
                echo "id : ".$i."\r\n";
            }
        }

        public function whois(){

        }

        //提取Alexa信息
        private function getAlexaInfo($html){
            $info = array();
            $dom = phpQuery::newDocumentHTML($html);

            $info['site'] = trim(pq($dom['div.bor-t1s h4 em:first'])->text());
            $info['alexa_rank'] = intval(trim(pq($dom['div.bor-t1s h4 em:last'])->text()));

            $list = $dom['div.info_right ul.info_detail li'];
            foreach ($list as $li) {
                $tit = trim(pq($li)->find('span.tit')->text());
                $li_info = trim(pq($li)->text());
                
                $value = trim(str_replace($tit, '', $li_info));
                $value = ($value && $value != '不详' && $value != '不祥' && $value != '没有记录') ? $value : NULL;

                switch ($tit) {
                    case '站点名称：':
                        $info['site_name'] = $value;
                        break;
                    case '网站站长：':
                        $info['webmaster'] = $value;
                        break;
                    case '电子信箱：':
                        $info['email'] = $value;
                        break;
                    case '下期排名：':
                        $info['next_rank'] = intval(str_replace(',', '', $value));
                        break;
                    case '收录日期：':
                        $info['index_date'] = $value; 
                        break;
                    case '成人内容：':
                        $info['sex_content'] = $value;
                        break;
                    case '反向链接：':
                        $info['backlinks'] = $value;
                        break;
                    case '联系电话：':
                        $info['phone'] = $value;
                        break;
                    case '详细地址：':
                        $info['address'] = $value;
                        break;
                    case '网站简介：':
                        $value = mb_strpos($value, '站点还没有向ALEXA') ? NULL : $value;
                        $info['intro'] = $value;
                        break;
                    default:
                        # code...
                        break;
                }
            }

            $info['trend'] = [];
            $alexa = $dom['div.mt1 ul.result_top:last'];
            $info['trend']['today_rank'] = intval(trim(str_replace(',','',pq($alexa)->find('li:first')->text())));

            $symbol = pq($alexa)->find('li:eq(1) img')->attr('src');
            $symbol = strpos($symbol, 'Up_arrow.gif') ? '+' : '-';
            $info['trend']['trend'] = intval($symbol.trim(str_replace(',','',pq($alexa)->find('li:eq(1)')->text())));

            $info['trend']['week_average'] = intval(trim(str_replace(',','',pq($alexa)->find('li:eq(2)')->text())));

            $symbol = pq($alexa)->find('li:eq(3) img')->attr('src');
            $symbol = strpos($symbol, 'Up_arrow.gif') ? '+' : '-';
            $info['trend']['week_trend'] = intval($symbol.trim(str_replace(',','',pq($alexa)->find('li:eq(3)')->text())));

            $info['trend']['month_average'] = intval(trim(str_replace(',','',pq($alexa)->find('li:eq(4)')->text())));

            $symbol = pq($alexa)->find('li:eq(5) img')->attr('src');
            $symbol = strpos($symbol, 'Up_arrow.gif') ? '+' : '-';
            $info['trend']['month_trend'] = intval($symbol.trim(str_replace(',','',pq($alexa)->find('li:eq(5)')->text())));

            $info['trend']['quarter_average'] = intval(trim(str_replace(',','',pq($alexa)->find('li:eq(6)')->text())));

            $symbol = pq($alexa)->find('li:eq(7) img')->attr('src');
            $symbol = strpos($symbol, 'Up_arrow.gif') ? '+' : '-';
            $info['trend']['quarter_trend'] = intval($symbol.trim(str_replace(',','',pq($alexa)->find('li:eq(7)')->text())));


            $info['rank_trend'] = trim(pq($dom['.wper26:first .wper30_info img'])->attr('src'));
            $info['search_traffic'] = trim(pq($dom['.wper26:last .wper30_info img'])->attr('src'));
            $dom -> unloadDocument();

            return $info;
        }

        //提取Whois信息
        private function getWhoisInfo($html){

        }
    }