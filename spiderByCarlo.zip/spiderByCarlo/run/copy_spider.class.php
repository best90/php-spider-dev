<?php
    use Ares333\CurlMulti\Core;

    class Copy_spider{
        public $curl;

        public function __construct(){
            $this->curl = new Core();
        }

        public function muhou(){
            $db=new PDO('mysql:dbname=company;host=127.0.0.1','root','root');
            $db->exec("set names utf8");

            $this->curl->maxThread = 1;

            $cache = CACHE_PATH . '/qichacha/muhou/';
            if (! file_exists( $cache )) {
                mkdir($cache);
            }

            $id = 72511;
            $res = $db->query("SELECT id,url,name FROM qichacha WHERE id>".$id." ORDER BY id ASC LIMIT 500")->fetchAll(PDO::FETCH_ASSOC);

            while(count($res) > 0) {
                while(count($res) > 0) {
                    $ip = mt_rand(101,120).'.'.mt_rand(50,250).'.'.mt_rand(10,250).'.'.mt_rand(10,250);
                    $re = array_shift($res);

                    if(empty($re['url']) || empty($re['name'])) continue;
                    $unique = explode('_', $re['url']);
                    $unique = end($unique);
                    $unique = substr($unique, 0, strpos($unique, '.'));
                    
                    $this->curl->add ( array (
                        'url' => 'http://www.qichacha.com/more_findmuhou?keyNo='.$unique,
                        'opt' => array (
                            CURLOPT_HEADER => false,
                            CURLOPT_HTTPHEADER => array('X-FORWARDED-FOR:'.$ip.'','CLIENT-IP:'.$ip.''),
                            CURLOPT_REFERER => 'http://www.qichacha.com/company_relation?keyNo='.$unique.'&name='.urlencode($re['name']),
                            CURLOPT_USERAGENT => userAgent(),
                            //CURLOPT_COOKIE => 'PHPSESSID=rdplc5mhvsdtdg87vggciraei3; CNZZDATA1254842228=1857387402-1464595951-%7C1464595951; SERVERID=0359c5bc66f888586d5a134d958bb1be|1464598050|1464597966',
                            CURLOPT_COOKIE => 'PHPSESSID=kg9eref1camnmhc4b7fuuu9907; SERVERID=0359c5bc66f888586d5a134d958bb1be|1464598087|1464579919; CNZZDATA1254842228=863333714-1464579742-%7C1464595951',
                            CURLOPT_RETURNTRANSFER => true,
                            CURLOPT_FOLLOWLOCATION => 0, 
                            CURLOPT_SSL_VERIFYPEER => false
                        ),
                        'args' => array (
                            'ip' => $ip,
                            'file' => $cache.$re['id'].'.txt'
                        )
                    ), array($this,'relationProcess'));
                }

                $this->curl->start ();

                $id = $re['id'];
                $res = $db->query("SELECT id,url,name FROM qichacha WHERE id>".$id." ORDER BY id ASC LIMIT 500")->fetchAll(PDO::FETCH_ASSOC);
            }

            $this->curl->start();
        }

        public function relation(){
            $db=new PDO('mysql:dbname=company;host=127.0.0.1','root','root');
            $db->exec("set names utf8");

            $this->curl->maxThread = 1;

            $cache = CACHE_PATH . '/qichacha/relation1/';
            if (! file_exists( $cache )) {
                mkdir($cache);
            }

            $id = 153214;
            $res = $db->query("SELECT id,url,name FROM qichacha WHERE id>".$id." ORDER BY id ASC LIMIT 500")->fetchAll(PDO::FETCH_ASSOC);

            while(count($res) > 0) {
                while(count($res) > 0) {
                    $ip = mt_rand(101,120).'.'.mt_rand(50,250).'.'.mt_rand(10,250).'.'.mt_rand(10,250);
                    $re = array_shift($res);

                    if(empty($re['url']) || empty($re['name'])) continue;
                    $unique = explode('_', $re['url']);
                    $unique = end($unique);
                    $unique = substr($unique, 0, strpos($unique, '.'));
                    
                    $this->curl->add ( array (
                        'url' => 'http://www.qichacha.com/cms_map?keyNo='.$unique.'&upstreamCount=4&downstreamCount=4',
                        'opt' => array (
                            CURLOPT_HEADER => false,
                            CURLOPT_HTTPHEADER => array('X-FORWARDED-FOR:'.$ip.'','CLIENT-IP:'.$ip.''),
                            CURLOPT_REFERER => 'http://www.qichacha.com/company_relation?keyNo='.$unique.'&name='.urlencode($re['name']),
                            CURLOPT_USERAGENT => userAgent(),
                            CURLOPT_COOKIE => 'PHPSESSID=rdplc5mhvsdtdg87vggciraei3; CNZZDATA1254842228=1857387402-1464595951-%7C1464595951; SERVERID=0359c5bc66f888586d5a134d958bb1be|1464598050|1464597966',
                            //CURLOPT_COOKIE => 'PHPSESSID=kg9eref1camnmhc4b7fuuu9907; SERVERID=0359c5bc66f888586d5a134d958bb1be|1464598087|1464579919; CNZZDATA1254842228=863333714-1464579742-%7C1464595951',
                            CURLOPT_RETURNTRANSFER => true,
                            CURLOPT_FOLLOWLOCATION => 0, 
                            CURLOPT_SSL_VERIFYPEER => false
                        ),
                        'args' => array (
                            'ip' => $ip,
                            'file' => $cache.$re['id'].'.txt'
                        )
                    ), array($this,'relationProcess'));
                }

                $this->curl->start ();

                $id = $re['id'];
                $res = $db->query("SELECT id,url,name FROM qichacha WHERE id>".$id." ORDER BY id ASC LIMIT 500")->fetchAll(PDO::FETCH_ASSOC);
            }

            $this->curl->start();
        }

        public function relationProcess($r, $args) {
            file_put_contents($args['file'], $r['content']);
            if(mb_strpos($r['content'], '您的账户存在异常')){
                echo "Failed to crawl !!!";
                die;
            }else{
                echo 'crawl '.$args['file']." success\n";
            }
            flush();
            //sleep(mt_rand(10,120));
        }
    }