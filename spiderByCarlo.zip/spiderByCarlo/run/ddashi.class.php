<?php
    class Ddashi{
        public $db;
        public function __construct(){
            $this->db = new PDO('mysql:dbname=app;host=127.0.0.1','root','root');
            $this->db->exec("set names utf8");
        }

        public function search(){
            $cache = CACHE_PATH . '/ddashi/search/';

            $res = $this->db->query("SELECT id,project_name FROM ddashi_list WHERE status = 1 ORDER BY id ASC LIMIT 500")->fetchAll(PDO::FETCH_ASSOC);

            $sql = "INSERT INTO ddashi_app_list(project_id,app_name,url,info,type,update_time) VALUES(:id,:app,:url,:info,:type,:time)";
            $st = $this->db->prepare($sql);

            while (count($res) > 0) {
                while (count($res) > 0) {
                    $re = array_shift($res);

                    $file = $cache.$re['id'].'.html';
                    if(!file_exists($file)) continue;

                    $html = toUtf8(read($file));
                    if(!$this->checkFile($html)){
                        $this->db->exec("UPDATE ddashi_list SET status = 0 WHERE id=".$re['id']);
                        continue;
                    }
                    $list = $this->getSearchList($html);
                    
                    $date = date('Y-m-d H:i:s');

                    if($list){
                        foreach ($list as $li) {
                            if(mb_strpos($li['name'], $re['project_name']) === false) continue;
                            $st->bindParam(':id',$re['id']);
                            $st->bindParam(':app',$li['name']);
                            $st->bindParam(':url',$li['url']);
                            $st->bindParam(':info',$li['info']);
                            $st->bindParam(':type',$li['type']);
                            $st->bindParam(':time',$date);

                            $st->execute();
                        }
                    }
                    
                    $this->db->exec("UPDATE ddashi_list SET status = 2 WHERE id=".$re['id']);
                }
                $res = $this->db->query("SELECT id,project_name FROM ddashi_list WHERE status = 1 ORDER BY id ASC LIMIT 500")->fetchAll(PDO::FETCH_ASSOC);
            }
        }

        //ios APP处理
        public function app_ios(){
            $cache = CACHE_PATH . '/ddashi/app_ios/';

            $res = $this->db->query("SELECT id,project_id,app_name,url FROM ddashi_app_list WHERE status = 1 ORDER BY id ASC LIMIT 500")->fetchAll(PDO::FETCH_ASSOC);

            $sql = "INSERT INTO ddashi_app_ios(app_list_id,app_name,icon,url,star,reviews,type,price,dev,rank,total_rank,data,update_time) VALUES(:lid,:app,:icon,:url,:star,:rev,:type,:pri,:dev,:rank,:trank,:dat,:utime) ON DUPLICATE KEY UPDATE update_time=VALUES(update_time)";
            $st = $this->db->prepare($sql);

            //$android_sql = "INSERT INTO ddashi_android_list(project_id,app_name,url,referer,update_time) VALUES(:pid,:app,:url,:ref,:utime) ON DUPLICATE KEY UPDATE update_time=VALUES(update_time)";
            //$android_st = $this->db->prepare($android_sql);

            while (count($res) > 0) {
                while (count($res) > 0) {
                    $re = array_shift($res);

                    $file = $cache.$re['id'].'.html';
                    if(!file_exists($file)){
                        $this->db->exec("UPDATE ddashi_app_list SET status = 0 WHERE id=".$re['id']);
                        continue;
                    }

                    $html = toUtf8(read($file));
                    if(!$this->checkFile($html)){
                        $this->db->exec("UPDATE ddashi_app_list SET status = 0 WHERE id=".$re['id']);
                        continue;
                    }

                    $info = $this->getIosAppInfo($html);
                    $app_data = trim(mb_substr($html,mb_strpos($html,'var data2 =')+11, mb_strpos($html,'var data3 =')-mb_strpos($html,'var data2 =')-14));
                    $app_data = json_encode($app_data);

                    $date = date('Y-m-d H:i:s');

                    $st->bindParam(':lid',$re['id']);
                    $st->bindParam(':app',$info['app_name']);
                    $st->bindParam(':icon',$info['icon']);
                    $st->bindParam(':url',$info['url']);
                    $st->bindParam(':star',$info['star']);
                    $st->bindParam(':rev',$info['reviews_num']);
                    $st->bindParam(':type',$info['type']);
                    $st->bindParam(':pri',$info['price']);
                    $st->bindParam(':dev',$info['dev']);
                    $st->bindParam(':rank',$info['rank']);
                    $st->bindParam(':trank',$info['total_rank']);
                    $st->bindParam(':dat',$app_data);
                    $st->bindParam(':utime',$date);

                    $st->execute();
                    echo "APP IOS Id: ".$this->db->lastInsertId()."\r\n";

                    /*if($info['android']){
                        $android_st->bindParam(':pid',$re['project_id']);
                        $android_st->bindParam(':app',$re['app_name']);
                        $android_st->bindParam(':url',$info['android']);
                        $android_st->bindParam(':ref',$re['url']);
                        $android_st->bindParam(':utime',$date);

                        $android_st->execute();
                        echo 'ANDROID LIST Id: '.$this->db->lastInsertId()."\r\n";
                    }*/

                    $this->db->exec("UPDATE ddashi_app_list SET status = 2 WHERE id=".$re['id']);
                }
                $res = $this->db->query("SELECT id,project_id,app_name FROM ddashi_app_list WHERE status = 1 ORDER BY id ASC LIMIT 500")->fetchAll(PDO::FETCH_ASSOC);
            }
        }

        //搜索android app
        public function search_android(){
            $cache = CACHE_PATH . '/ddashi/search_android/';

            $res = $this->db->query("SELECT id,project_name FROM ddashi_list WHERE android_status = 1 ORDER BY id ASC LIMIT 500")->fetchAll(PDO::FETCH_ASSOC);

            $sql = "INSERT INTO ddashi_android_list(project_id,app_name,url,info,update_time) VALUES(:id,:app,:url,:info,:utime) ON DUPLICATE KEY UPDATE  app_name=VALUES(app_name),info=VALUES(info),update_time=VALUES(update_time)";
            $st = $this->db->prepare($sql);

            while (count($res) > 0) {
                while (count($res) > 0) {
                    $re = array_shift($res);

                    $file = $cache.$re['id'].'.html';
                    if(!file_exists($file)){
                        $this->db->exec("UPDATE ddashi_list SET android_status = 0 WHERE id=".$re['id']);
                        continue;
                    }

                    $html = toUtf8(read($file));
                    if(!$this->checkFile($html)){
                        $this->db->exec("UPDATE ddashi_list SET android_status = 0 WHERE id=".$re['id']);
                        continue;
                    }
                    $list = $this->getSearchAndroidList($html);

                    $date = date('Y-m-d H:i:s');

                    if($list){
                        foreach ($list as $li) {
                            if(mb_strpos($li['name'], $re['project_name']) === false) continue;
                            $st->bindParam(':id',$re['id']);
                            $st->bindParam(':app',$li['name']);
                            $st->bindParam(':url',$li['url']);
                            $st->bindParam(':info',$li['info']);
                            $st->bindParam(':utime',$date);

                            $st->execute();
                            echo "ANDROID LIST Id: ".$this->db->lastInsertId()."\r\n";
                        }
                    }

                    $this->db->exec("UPDATE ddashi_list SET android_status = 2 WHERE id=".$re['id']);
                }
                $res = $this->db->query("SELECT id,project_name FROM ddashi_list WHERE android_status = 1 ORDER BY id ASC LIMIT 500")->fetchAll(PDO::FETCH_ASSOC);
            }
        }

        //android APP 数据处理
        public function app_android(){
            $cache = CACHE_PATH . '/ddashi/app_android/';

            $res = $this->db->query("SELECT id,app_name,url FROM ddashi_android_list WHERE status = 1 ORDER BY id ASC LIMIT 500")->fetchAll(PDO::FETCH_ASSOC);

            $sql = "INSERT INTO ddashi_app_android(android_list_id,app_name,icon,url,package,dev,data,download_data,rank_data,update_time) VALUES(:aid,:app,:icon,:url,:pac,:dev,:dat,:ddat,:rdat,:utime) ON DUPLICATE KEY UPDATE update_time=VALUES(update_time)";
            $st = $this->db->prepare($sql);

            while (count($res) > 0) {
                while (count($res) > 0) {
                    $re = array_shift($res);
                    //$re['id'] = 2;
                    $file = $cache.$re['id'].'.html';
                    if(!file_exists($file)){
                        $this->db->exec("UPDATE ddashi_android_list SET status = 0 WHERE id=".$re['id']);
                        continue;
                    }

                    $html = toUtf8(read($file));
                    if(!$this->checkFile($html)){
                        $this->db->exec("UPDATE ddashi_android_list SET status = 0 WHERE id=".$re['id']);
                        continue;
                    }

                    $info = $this->getAndroidAppInfo($html);

                    $data = trim(mb_substr($html,mb_strpos($html,'var chartData =')+15, mb_strpos($html,'function selectType')-mb_strpos($html,'var chartData =')-15));
                    $data = trim($data,';');
                    $data = json_encode($data);

                    $download_data = trim(mb_substr($html,mb_strpos($html,'var downloadData =')+18, mb_strpos($html,'dashi.detail.getDownloadBar')-mb_strpos($html,'var downloadData =')-18));
                    $download_data = trim($download_data,';');
                    $download_data = json_encode($download_data);

                    $rank_data = json_encode($info['rank_data']);

                    if(empty($info['app_name'])){
                        $info['app_name'] = $re['app_name'];
                    }
                    $date = date('Y-m-d H:i:s');

                    $st->bindParam(':aid',$re['id']);
                    $st->bindParam(':app',$info['app_name']);
                    $st->bindParam(':icon',$info['icon']);
                    $st->bindParam(':url',$re['url']);
                    $st->bindParam(':pac',$info['package']);
                    $st->bindParam(':dev',$info['dev']);
                    $st->bindParam(':dat',$data);
                    $st->bindParam(':ddat',$download_data);
                    $st->bindParam(':rdat',$rank_data);
                    $st->bindParam(':utime',$date);

                    $st->execute();
                    echo "APP ANDROID Id: ".$this->db->lastInsertId()."\r\n";

                    $this->db->exec("UPDATE ddashi_android_list SET status = 2 WHERE id=".$re['id']);
                }
                sleep(10);
                
                $res = $this->db->query("SELECT id,app_name,url FROM ddashi_android_list WHERE status = 1 ORDER BY id ASC LIMIT 500")->fetchAll(PDO::FETCH_ASSOC);
            }
        }

        //校验抓取的文件
        private function checkFile($html){
            if(mb_strpos($html, '</html>') === false || mb_strpos($html, '蝉大师') === false || mb_strpos($html, '存在可疑流量') !== false) return false;
            return true;
        }

        //提取url信息
        private function getSearchList($html){
            $info = array();
            $dom = phpQuery::newDocumentHTML($html);

            $list = $dom['#searchlist .col-sm-12'];
            foreach ($list as $k => $li) {
                $info[$k]['name'] = trim(pq($li)->find('.caption a')->attr('title'));
                $info[$k]['url'] = trim(pq($li)->find('.caption a')->attr('href'));
                $info[$k]['info'] = trim(pq($li)->find('.caption h5:first')->text());
                $type = trim(pq($li)->find('.caption h5:last')->text());
                $info[$k]['type'] = trim(mb_substr($type, 0, mb_strpos($type, '(')));
            }

            $dom -> unloadDocument();
            return $info;
        }

        /**提取Search Android列表
         * @param string $html
         */
        private function getSearchAndroidList($html){
            $info = array();
            $dom = phpQuery::newDocumentHTML($html);

            $list = $dom['#searchlist .col-sm-12'];
            foreach ($list as $k => $li) {
                $info[$k]['name'] = trim(pq($li)->find('.caption a')->attr('title'));
                $info[$k]['url'] = trim(pq($li)->find('.caption a')->attr('href'));
                $info[$k]['info'] = trim(pq($li)->find('.caption h5')->text());
            }

            $dom -> unloadDocument();
            return $info;
        }

        /**
         *提取APP IOS页面的信息
         * @param string $html
         */
        private function getIosAppInfo($html){
            $info = array();
            $dom = phpQuery::newDocumentHTML($html);

            $info['app_name'] = trim(pq($dom['.panel-top .col-lg-10:first span.app-name'])->text());
            $info['icon'] = pq($dom['.panel-top .col-lg-2 img'])->attr('src');

            $reviews = pq($dom['.panel-top .info .col-lg-2:first .info-name'])->text();
            $info['reviews_num'] = intval(str_replace(',','',mb_substr($reviews, mb_strpos($reviews,'(')+1, mb_strpos($reviews,')')-mb_strpos($reviews,'(')-1)));
            $info['star'] = pq($dom['.panel-top .info .col-lg-2:first .info-value'])->attr('data-rateit-value');
            $info['type'] = trim(pq($dom['.panel-top .info .col-lg-1:first .info-value a'])->text());
            $info['price'] = trim(pq($dom['.panel-top .info span.info-price'])->text());
            $info['dev'] = trim(pq($dom['.panel-top .info .col-lg-4 .info-value'])->text());
            $info['url'] = pq($dom['.panel-top .info .col-lg-2:last .info-value a'])->attr('href');

            $info['rank'] = trim(pq($dom['.data-table tr:last td:first'])->text());
            $info['total_rank'] = trim(pq($dom['.data-table tr:last td:last'])->text());
            $info['android'] = trim(pq($dom['.navbar-nav li.able:first a'])->attr('href'));

            $dom -> unloadDocument();
            return $info;
        }

        /**提取APP Android页面的信息
         * @param string $html
         * @return array
         */
        private function getAndroidAppInfo($html){
            $info = array();
            $dom = phpQuery::newDocumentHTML($html);

            $info['app_name'] = trim(pq($dom['.detail .appname'])->text());
            $info['icon'] = pq($dom['.container .img img'])->attr('src');
            $info['package'] = trim(pq($dom['.info .col-lg-2:eq(1) .info-value'])->text());
            $info['dev'] = trim(pq($dom['.info .col-lg-4 .info-value'])->text());

            $info['rank_date'] = trim(pq($dom['#recommend .date'])->text());

            $info['rank_data'] = [];
            $list = $dom['#recommend div.title'];
            foreach ($list as $k => $li) {
                $info['rank_data'][$k]['source'] = trim(pq($li)->text());
                $info['rank_data'][$k]['data'] = [];
                $rank_list = pq($li)->_next()->find('tr');
                foreach ($rank_list as $j => $rank) {
                    $info['rank_data'][$k]['data'][$j]['name'] = trim(pq($rank)->find('.col-lg-10')->text());
                    $info['rank_data'][$k]['data'][$j]['rank'] = trim(pq($rank)->find('.col-lg-2 span')->text());
                }
            }

            $dom -> unloadDocument();
            return $info;
        }
    }