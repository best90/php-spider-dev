<?php

/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2016/6/28
 * Time: 10:33
 */
class News{
    public $db;

    public function __construct(){
        $this->db = new PDO('mysql:dbname=news;host=127.0.0.1','root','root');
        $this->db->exec("set names utf8");
    }

    //百度新闻搜索处理
    public function baidu(){
        $cache = CACHE_PATH . '/news/baidu/';

        $res = $this->db->query("SELECT id,company_id,project_name FROM search WHERE baidu = 1 ORDER BY id ASC LIMIT 500")->fetchAll(PDO::FETCH_ASSOC);

        $sql = "INSERT INTO baidu(company_id,project_name,data,update_time) VALUES(:cid,:pro,:dat,:utime) ON DUPLICATE KEY UPDATE update_time=VALUES(update_time)";
        $st = $this->db->prepare($sql);

        while (count($res) > 0) {
            while (count($res) > 0) {
                $re = array_shift($res);
                $file = $cache.$re['id'].'.html';
                if(!file_exists($file)){
                    $this->db->exec("UPDATE search SET baidu = 0 WHERE id=".$re['id']);
                    continue;
                }

                $html = toUtf8(read($file));
                if(!$this->checkBaiduFile($html)){
                    $this->db->exec("UPDATE search SET baidu = 0 WHERE id=".$re['id']);
                    continue;
                }
                $info = $this->getBaiduNewsList($html);
                $data = json_encode($info);

                $date = date('Y-m-d H:i:s');

                $st->bindParam(':cid',$re['company_id']);
                $st->bindParam(':pro',$re['project_name']);
                $st->bindParam(':dat',$data);
                $st->bindParam(':utime',$date);

                $st->execute();
                echo "Baidu News Id: ".$this->db->lastInsertId()."\r\n";

                $this->db->exec("UPDATE search SET baidu = 2 WHERE id=".$re['id']);
            }

            $res = $this->db->query("SELECT id,company_id,project_name FROM search WHERE baidu = 1 ORDER BY id ASC LIMIT 500")->fetchAll(PDO::FETCH_ASSOC);
        }
    }

    //IT桔子新闻搜索处理
    public function itjuzi(){
        $cache = CACHE_PATH . '/news/itjuzi/';

        $res = $this->db->query("SELECT id,company_id,project_name FROM search WHERE itjuzi = 1 ORDER BY id ASC LIMIT 500")->fetchAll(PDO::FETCH_ASSOC);

        $sql = "INSERT INTO itjuzi(company_id,project_name,data,update_time) VALUES(:cid,:pro,:dat,:utime) ON DUPLICATE KEY UPDATE update_time=VALUES(update_time)";
        $st = $this->db->prepare($sql);

        while (count($res) > 0) {
            while (count($res) > 0) {
                $re = array_shift($res);
                $file = $cache.$re['id'].'.html';
                if(!file_exists($file)){
                    $this->db->exec("UPDATE search SET itjuzi = 0 WHERE id=".$re['id']);
                    continue;
                }

                $html = toUtf8(read($file));
                $info = $this->getItjuziNewsList($html);

                $data = json_encode($info);
                $date = date('Y-m-d H:i:s');

                $st->bindParam(':cid',$re['company_id']);
                $st->bindParam(':pro',$re['project_name']);
                $st->bindParam(':dat',$data);
                $st->bindParam(':utime',$date);

                $st->execute();
                echo "ITjuzi News Id: ".$this->db->lastInsertId()."\r\n";

                $this->db->exec("UPDATE search SET itjuzi = 2 WHERE id=".$re['id']);
            }

            $res = $this->db->query("SELECT id,company_id,project_name FROM search WHERE itjuzi = 1 ORDER BY id ASC LIMIT 500")->fetchAll(PDO::FETCH_ASSOC);
        }
    }

    //36kr新闻搜索处理
    public function kr36(){
        $cache = CACHE_PATH . '/news/kr36/';

        $res = $this->db->query("SELECT id,company_id,project_name FROM search WHERE 36kr = 1 ORDER BY id ASC LIMIT 500")->fetchAll(PDO::FETCH_ASSOC);

        $sql = "INSERT INTO 36kr(company_id,project_name,data,update_time) VALUES(:cid,:pro,:dat,:utime) ON DUPLICATE KEY UPDATE update_time=VALUES(update_time)";
        $st = $this->db->prepare($sql);

        while (count($res) > 0) {
            while (count($res) > 0) {
                $re = array_shift($res);
                $file = $cache.$re['id'].'.txt';
                if(!file_exists($file)){
                    $this->db->exec("UPDATE search SET 36kr = 0 WHERE id=".$re['id']);
                    continue;
                }

                $html = toUtf8(read($file));
                $info = json_decode($html,true);

                $news = [];
                if($info['data']['newsflashes']){
                    foreach ($info['data']['newsflashes'] as $k => $n) {
                        $news[$k]['title'] = $n['hash_title'];
                        $news[$k]['url'] = $n['news_url'];
                        $news[$k]['info'] = $n['description_text'];
                        $news[$k]['date'] = substr($n['updated_at'],0,strpos($n['updated_at'], 'T'));
                    }
                }

                $data = json_encode($news);
                $date = date('Y-m-d H:i:s');

                $st->bindParam(':cid',$re['company_id']);
                $st->bindParam(':pro',$re['project_name']);
                $st->bindParam(':dat',$data);
                $st->bindParam(':utime',$date);

                $st->execute();
                echo "36Kr News Id: ".$this->db->lastInsertId()."\r\n";

                $this->db->exec("UPDATE search SET 36kr = 2 WHERE id=".$re['id']);
            }

            $res = $this->db->query("SELECT id,company_id,project_name FROM search WHERE 36kr = 1 ORDER BY id ASC LIMIT 500")->fetchAll(PDO::FETCH_ASSOC);
        }
    }

    //虎嗅网新闻搜索处理
    public function huxiu(){
        $cache = CACHE_PATH . '/news/huxiu/';

        $res = $this->db->query("SELECT id,company_id,project_name FROM search WHERE huxiu = 1 ORDER BY id ASC LIMIT 500")->fetchAll(PDO::FETCH_ASSOC);

        $sql = "INSERT INTO huxiu(company_id,project_name,data,update_time) VALUES(:cid,:pro,:dat,:utime) ON DUPLICATE KEY UPDATE update_time=VALUES(update_time)";
        $st = $this->db->prepare($sql);

        while (count($res) > 0) {
            while (count($res) > 0) {
                $re = array_shift($res);
                $file = $cache . $re['id'] . '.html';
                if (!file_exists($file)) {
                    $this->db->exec("UPDATE search SET huxiu = 0 WHERE id=" . $re['id']);
                    continue;
                }

                $html = toUtf8(read($file));
                $info = $this->getHuxiuNewsList($html);

                $data = json_encode($info);
                $date = date('Y-m-d H:i:s');

                $st->bindParam(':cid', $re['company_id']);
                $st->bindParam(':pro', $re['project_name']);
                $st->bindParam(':dat', $data);
                $st->bindParam(':utime', $date);

                $st->execute();
                echo "Huxiu News Id: " . $this->db->lastInsertId() . "\r\n";

                $this->db->exec("UPDATE search SET huxiu = 2 WHERE id=" . $re['id']);
            }

            $res = $this->db->query("SELECT id,company_id,project_name FROM search WHERE huxiu = 1 ORDER BY id ASC LIMIT 500")->fetchAll(PDO::FETCH_ASSOC);
        }
    }

    //校验百度新闻文件
    private function checkBaiduFile($html){
        if(!mb_strpos($html,'</html>') || !mb_strpos($html,'百度')) return false;
        return true;
    }

    /**提取百度新闻列表
     * @param string $html
     * @return array
     */
    private function getBaiduNewsList($html){
        $info = array();
        $dom = phpQuery::newDocumentHTML($html);

        $list = $dom['#container .result'];
        foreach ($list as $k => $li) {
            $info[$k]['title'] = trim(pq($li)->find('h3.c-title a')->text());
            $info[$k]['url'] = trim(pq($li)->find('h3.c-title a')->attr('href'));

            $summary = pq($li)->find('.c-summary')->text();
            $span = pq($li)->find('.c-summary span')->text();
            $source = pq($li)->find('.c-author')->text();
            $summary = str_replace($source,'',$summary);
            $summary = str_replace($span,'',$summary);
            $info[$k]['info'] = trim($summary);

            if(mb_strpos($source,'小时前')){
                $info[$k]['date'] = date('Y-m-d');
                $source = mb_substr($source,0,mb_strpos($source,'小时前')-2);
            }else{
                $regex="'\d{4}年\d{1,2}月\d{1,2}'is";
                preg_match_all($regex,$source,$matches);
                $date = str_replace(array('年','月'),'-',$matches[0]);
                @$info[$k]['date'] = $date[0];

                $source = mb_substr($source, 0, mb_strpos($source,'20')-2);
            }

            $info[$k]['source'] = trim($source);
        }

        $dom -> unloadDocument();
        return $info;
    }

    /**提取IT桔子的新闻列表
     * @param string $html
     * @return array
     */
    private function getItjuziNewsList($html){
        $info = array();
        $dom = phpQuery::newDocumentHTML($html);

        $list = $dom['#the_search_list li'];
        foreach ($list as $k => $li) {
            $info[$k]['title'] = trim(pq($li)->find('a h4')->text());
            $info[$k]['url'] = trim(pq($li)->find('a')->attr('href'));
            $info[$k]['type'] = trim(pq($li)->find('span.tag')->text());
        }

        $dom -> unloadDocument();
        return $info;
    }

    /*
     * 提取虎嗅的新闻列表
     * @param string $html
     * @return array
     */
    private function getHuxiuNewsList($html){
        $info = array();
        $dom = phpQuery::newDocumentHTML($html);

        $list = $dom['.search-wrap-list-ul li'];
        foreach ($list as $k => $li) {
            $info[$k]['title'] = trim(pq($li)->find('h2')->text());
            $info[$k]['url'] = 'http://www.huxiu.com'.trim(pq($li)->find('h2 a')->attr('href'));
            $info[$k]['info'] = trim(pq($li)->find('.mob-summay')->text());

            $date = trim(pq($li)->find('.mob-author .time')->text());
            $info[$k]['date'] = substr($date,0,strpos($date,' '));
        }

        $dom -> unloadDocument();
        return $info;
    }
}