<?php
    class Angel{
        public function project(){
            $db=new PDO('mysql:dbname=angel_project;host=127.0.0.1','root','root');
            $db->exec("set names utf8");

            $cache = CACHE_PATH . '/angel/project/';
            $team_cache = CACHE_PATH . '/angel/team_info/';
            $detail_cache = CACHE_PATH . '/angel/detail_info/';
            $bp_cache = CACHE_PATH . '/angel/bp/';

            $ids = $db->query("SELECT com_id FROM angel WHERE com_id>13320687 ORDER BY com_id ASC")->fetchAll(PDO::FETCH_COLUMN);

            $sql = "INSERT INTO angel_project(com_id,proj_name,industry,country,province,city,logo_id,stage,description,org_name,advantage,url,pic,weibo,weixin,ios,android,biz_mode,adg_other,team,milestone,bp,update_time) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE update_time=VALUES(update_time)";
            //$sql = "INSERT INTO angel_project(com_id,proj_name,industry,country,province,city,logo_id,stage,description,org_name,advantage,update_time) VALUES(?,?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE update_time=VALUES(update_time)";
            $st = $db->prepare($sql);

            foreach ($ids as $id) {
                $file = $cache.$id.'.html';
                $team_file = $team_cache.$id.'.txt';
                $detail_file = $detail_cache.$id.'.txt';
                $bp_file = $bp_cache.$id.'.txt';

                $html = toUtf8(read($file));
                
                $brief = cutStr($html,'window.render_brief(',', "ACUSER"');
                $detail = cutStr($html,'window.render_proj_detail(',');');
                $brief = json_decode($brief, true);
                $detail = json_decode($detail, true);

                $org_name = isset($brief['org_name']) ? $brief['org_name'] : '';

                $team_text = file_get_contents($team_file);
                $team_info = json_decode($team_text, true);

                $team = array();
                if($team_info['data']['members']){
                    foreach ($team_info['data']['members'] as $k => $member) {
                        $team[$k]['name'] = $member['member_name'];
                        $team[$k]['title'] = (isset($member['is_founder']) && $member['is_founder'] == 1) ? '创始人' : $member['member_title'];
                        $team[$k]['desc'] = $member['member_desc'];
                        $team[$k]['avatar'] = $member['member_avatar'];
                    }
                }

                $detail_text = file_get_contents($detail_file);
                $detail_info = json_decode($detail_text, true);

                $details = array();
                $details['url'] =  $detail_info['data']['product_info']['url'];
                $details['pic'] = $detail_info['data']['product_info']['pic'];
                $details['weibo'] = $detail_info['data']['product_info']['weibo'];
                $details['weixin'] = $detail_info['data']['product_info']['weixin'];
                $details['ios'] = $detail_info['data']['product_info']['ios_download'];
                $details['android'] = $detail_info['data']['product_info']['android_download'];

                $details['biz_mode'] = $detail_info['data']['detail_info']['biz_mode_desc'];
                $details['advantage'] = $detail_info['data']['detail_info']['advantage'];
                $details['adg_other'] = $detail_info['data']['detail_info']['adg_other'];

                $news = array();
                if($detail_info['data']['proj_milestone']['news_info']){
                    foreach ($detail_info['data']['proj_milestone']['news_info'] as $k => $val) {
                        $news[$k]['title'] = $val['memo_desc'];
                        $news[$k]['type'] = $val['memo_type'];
                        $news[$k]['time'] = $val['memo_time'];
                    }
                }

                $bp_text = file_get_contents($bp_file);
                $bp_info = json_decode($bp_text, true);
                $bp = isset($bp_info['data']['bp']) ? $bp_info['data']['bp'] : '';

                $advantage = json_encode($details['advantage']);
                $pic = json_encode($details['pic']);
                $team = json_encode($team);
                $news = json_encode($news);
                $date = date('Y-m-d H:i:s');

                if(empty($brief['city'])) $brief['city'] = '';
                if(empty($org_name)) $org_name = '';
                if(empty($detail['description'])) $detail['description'] = '';

                $st->bindParam(1,$id,PDO::PARAM_INT);
                $st->bindParam(2,$brief['proj_name'],PDO::PARAM_STR);
                $st->bindParam(3,$brief['field'],PDO::PARAM_STR);
                $st->bindParam(4,$brief['country'],PDO::PARAM_STR);
                $st->bindParam(5,$brief['province'],PDO::PARAM_STR);
                $st->bindParam(6,$brief['city'],PDO::PARAM_STR);
                $st->bindParam(7,$brief['logo_id'],PDO::PARAM_STR);
                $st->bindParam(8,$brief['stage'],PDO::PARAM_STR);
                $st->bindParam(9,$detail['description'],PDO::PARAM_STR);
                $st->bindParam(10,$org_name,PDO::PARAM_STR);
                $st->bindParam(11,$advantage,PDO::PARAM_STR);
                $st->bindParam(12,$details['url'],PDO::PARAM_STR);
                $st->bindParam(13,$pic,PDO::PARAM_STR);
                $st->bindParam(14,$details['weibo'],PDO::PARAM_STR);
                $st->bindParam(15,$details['weixin'],PDO::PARAM_STR);
                $st->bindParam(16,$details['ios'],PDO::PARAM_STR);
                $st->bindParam(17,$details['android'],PDO::PARAM_STR);
                $st->bindParam(18,$details['biz_mode'],PDO::PARAM_STR);
                $st->bindParam(19,$details['adg_other'],PDO::PARAM_STR);
                $st->bindParam(20,$team,PDO::PARAM_STR);
                $st->bindParam(21,$news,PDO::PARAM_STR);
                $st->bindParam(22,$bp,PDO::PARAM_STR);
                $st->bindParam(23,$date,PDO::PARAM_STR);

                $return = $st->execute();
                if(empty($return)){
                    echo $id.' | '.$brief['proj_name'].' | '.$brief['field'].' | '.$brief['country'].' | '.$brief['province'].' | '.$brief['city'].' | '.$brief['logo_id'].' | '.$brief['stage'].' | '.$detail['description'].' | '.$org_name.' | '.$advantage.' | '.$details['url'].' | '.$pic.' | '.$details['weibo'].'  '.$details['weixin'].'  '.$details['ios'].'  '.$details['android'].'  '.$details['biz_mode'].'  '.$details['adg_other'].'  '.$team.'  '.$news.'  '.$bp;
                    die;
                }
                //$return = $db->lastInsertId();
                echo $id." id : ".$return."\r\n";

            }
        }

        
    }