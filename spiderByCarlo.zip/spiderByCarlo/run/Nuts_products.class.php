<?php 
    // IT桔子>36kr>拉勾网>天天投>创业邦>猎云>虎嗅>天使汇>创投圈
    class Nuts_products{

        public function go(){
            $target_db = $this->databaseObj('nuts_tool');
            //IT桔子
            //$this->syncITjuzi($target_db, 'itjuzi_project','itjuzi_project','project_name,product');
    
            //拉勾网
            $this->syncLagou($target_db,'lagou_project','lagou_project','project_name,product');
        }

/*
 * --------------------------------------------分割线------------------------------------------------------
 * 自定义相关函数
 */
        public function syncITjuzi($target_db, $dbname, $table, $field, $type = PDO::FETCH_ASSOC){
            $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field,'',$type);

            $sql = "INSERT INTO company_product(project_id,product_name,type,url,info) VALUES(?,?,?,?,?)";
            $st = $target_db->prepare($sql);

            foreach ($data as $d) {
                if(empty($d['project_name'])) continue;
                if($d['product'] == '""') continue;
                $result = $target_db->query("SELECT id FROM company_project WHERE project_name='".addslashes($d['project_name'])."'")->fetchAll(PDO::FETCH_COLUMN);
                if(empty($result)) continue;

                $project_id = $result[0];
                $exists = $target_db->query("SELECT id FROM company_product WHERE project_id='".$project_id."'")->fetchAll(PDO::FETCH_COLUMN);
                if($exists) continue;

                $list = json_decode($d['product'],true);
                if(empty($list)) continue;
                foreach ($list as $li) {
                    if(empty($li['name'])) continue;

                    $st->bindParam(1,$project_id,PDO::PARAM_INT);
                    $st->bindParam(2,$li['name'],PDO::PARAM_STR);
                    $st->bindParam(3,$li['type'],PDO::PARAM_STR);
                    $st->bindParam(4,$li['url'],PDO::PARAM_STR);
                    $st->bindParam(5,$li['info'],PDO::PARAM_STR);
                    $st->execute();
                    echo "id : ".$target_db->lastInsertId()."\r\n";
                }
            }
            echo "===============\r\n";
        }

        public function syncLagou($target_db, $dbname, $table, $field, $type = PDO::FETCH_ASSOC){
            $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field,'',$type);

            $sql = "INSERT INTO company_product(project_id,product_name,url,info) VALUES(?,?,?,?)";
            $st = $target_db->prepare($sql);

            foreach ($data as $d) {
                if(empty($d['project_name'])) continue;
                if($d['product'] == '""') continue;
                $result = $target_db->query("SELECT id FROM company_project WHERE project_name='".addslashes($d['project_name'])."'")->fetchAll(PDO::FETCH_COLUMN);
                if(empty($result)) continue;

                $project_id = $result[0];
                $exists = $target_db->query("SELECT id FROM company_product WHERE project_id='".$project_id."'")->fetchAll(PDO::FETCH_COLUMN);
                if($exists) continue;

                $list = json_decode($d['product'],true);
                if(empty($list)) continue;
                foreach ($list as $li) {
                    if(empty($li['product_name'])) continue;

                    $st->bindParam(1,$project_id,PDO::PARAM_INT);
                    $st->bindParam(2,$li['product_name'],PDO::PARAM_STR);
                    $st->bindParam(3,$li['product_url'],PDO::PARAM_STR);
                    $st->bindParam(4,$li['intro'],PDO::PARAM_STR);
                    $st->execute();
                    echo "id : ".$target_db->lastInsertId()."\r\n";
                }
            }
            echo "===============\r\n";
        }
    
        public function databaseObj($dbname,$host = '127.0.0.1',$user = 'root',$password = 'root'){
            $db=new PDO('mysql:dbname='.$dbname.';host='.$host,$user,$password);
            $db->exec("set names utf8");

            return $db;
        }

        public function selectData($db, $table, $field, $where = '', $type = PDO::FETCH_COLUMN){
            $data = $db->query("SELECT ".$field." FROM ".$table." ".$where)->fetchAll($type); 
            
            return $data;
        }
    }