<?php 
    // IT桔子>36kr>拉勾网>天天投>创业邦>猎云>虎嗅>天使汇>创投圈
    class Nuts_industry_id{

        public function go(){
            $target_db = $this->databaseObj('nuts_tool');
            //IT桔子
            //$this->syncCommon($target_db, 'itjuzi_project','itjuzi_project','project_name,industry');
            
            //36kr
            //$this->syncCommon($target_db, '36kr_project','36kr_project','project_name,industry');
            
            $this->syncCommon($target_db, 'nuts_tool','company_project','project_name,industry');
        }

/*
 * --------------------------------------------分割线------------------------------------------------------
 * 自定义相关函数
 */
        public function syncCommon($target_db, $dbname, $table, $field, $type = PDO::FETCH_ASSOC){
            $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field,'WHERE industry_id=0',$type);

            $sql = "UPDATE company_project SET industry_id=:industry_id WHERE id=:id";
            $st = $target_db->prepare($sql);
            foreach ($data as $d) {
                if(empty($d['project_name']) || empty($d['industry'])) continue;
                
                $proj = $target_db->query("SELECT id FROM company_project WHERE project_name='".addslashes($d['project_name'])."'")->fetchAll(PDO::FETCH_COLUMN);
                if(empty($proj)) continue;

                $project_id = $proj[0];

                
                $t = $target_db->query("SELECT id FROM industry WHERE name='".addslashes($d['industry'])."'")->fetchAll(PDO::FETCH_COLUMN);
                if(empty($t)) continue;

                $industry_id = $t[0];

                //echo $project_id.'--------------------'.$industry_id."\r\n";
                $st->bindParam(':id', $project_id);
                $st->bindParam(':industry_id',$industry_id);
                $st->execute();
                echo "id : ".$project_id."\r\n";
            }
            echo "===============\r\n";
        }

        public function syncCommon2($target_db, $dbname, $table, $field, $type = PDO::FETCH_ASSOC){
            $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field,'',$type);

            $sql = "INSERT INTO company_project_tag(project_id,tag_id) VALUES(?,?)";
            $st = $target_db->prepare($sql);
            foreach ($data as $d) {
                if(empty($d['project_name']) || empty($d['industry'])) continue;
                
                $proj = $target_db->query("SELECT id FROM company_project WHERE project_name='".addslashes($d['project_name'])."'")->fetchAll(PDO::FETCH_COLUMN);
                if(empty($proj)) continue;

                $project_id = $proj[0];

                $tags = explode(',', $d['industry']);
                foreach ($tags as $tag) {
                    $t = $target_db->query("SELECT id FROM tags WHERE name='".addslashes($tag)."'")->fetchAll(PDO::FETCH_COLUMN);
                    if(empty($t)) continue;

                    $tag_id = $t[0];
                    $st->bindParam(1,$project_id,PDO::PARAM_INT);
                    $st->bindParam(2,$tag_id,PDO::PARAM_INT);
                    $st->execute();
                    echo "id : ".$target_db->lastInsertId()."\r\n";
                } 
            }
            echo "===============\r\n";
        }

        public function syncHuxiu($target_db, $dbname, $table, $field, $type = PDO::FETCH_ASSOC){
            $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field,'',$type);

            $sql = "INSERT INTO company_project_tag(project_id,tag_id) VALUES(?,?)";
            $st = $target_db->prepare($sql);
            foreach ($data as $d) {
                if(empty($d['project_name']) || empty($d['tag'])) continue;
                
                $proj = $target_db->query("SELECT id FROM company_project WHERE project_name='".addslashes($d['project_name'])."'")->fetchAll(PDO::FETCH_COLUMN);
                if(empty($proj)) continue;

                $project_id = $proj[0];

                $tags = explode(',', $d['tag']);
                foreach ($tags as $tag) {
                    $t = $target_db->query("SELECT id FROM tags WHERE name='".addslashes($tag)."'")->fetchAll(PDO::FETCH_COLUMN);
                    if(empty($t)) continue;

                    $tag_id = $t[0];
                    $st->bindParam(1,$project_id,PDO::PARAM_INT);
                    $st->bindParam(2,$tag_id,PDO::PARAM_INT);
                    $st->execute();
                    echo "id : ".$target_db->lastInsertId()."\r\n";
                } 
            }
            echo "===============\r\n";
        }
    
        public function syncAngel($target_db, $dbname, $table, $field, $type = PDO::FETCH_ASSOC){
           $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field,'',$type);

            $sql = "INSERT INTO company_project_tag(project_id,tag_id) VALUES(?,?)";
            $st = $target_db->prepare($sql);
            foreach ($data as $d) {
                if(empty($d['proj_name']) || empty($d['industry'])) continue;
                
                $proj = $target_db->query("SELECT id FROM company_project WHERE project_name='".addslashes($d['proj_name'])."'")->fetchAll(PDO::FETCH_COLUMN);
                if(empty($proj)) continue;

                $project_id = $proj[0];

                $tags = explode(' · ', $d['industry']);
                foreach ($tags as $tag) {
                    $t = $target_db->query("SELECT id FROM tags WHERE name='".addslashes($tag)."'")->fetchAll(PDO::FETCH_COLUMN);
                    if(empty($t)) continue;

                    $tag_id = $t[0];
                    $st->bindParam(1,$project_id,PDO::PARAM_INT);
                    $st->bindParam(2,$tag_id,PDO::PARAM_INT);
                    $st->execute();
                    echo "id : ".$target_db->lastInsertId()."\r\n";
                } 
            }
            echo "===============\r\n";
        }
    
        public function databaseObj($dbname,$host = '127.0.0.1',$user = 'root',$password = 'root'){
            $db=new PDO('mysql:dbname='.$dbname.';host='.$host,$user,$password);
            $db->exec("set names utf8");

            return $db;
        }

        public function selectData($db, $table, $field, $where = '', $type = PDO::FETCH_COLUMN){
            $data = $db->query("SELECT ".$field." FROM ".$table." ".$where)->fetchAll($type); 
            
            return $data;
        }
    }