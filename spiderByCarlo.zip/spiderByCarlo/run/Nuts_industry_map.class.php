<?php
    class Nuts_industry_map{
        public function go(){
            $target_db = $this->databaseObj('nuts_tool');
            
            $this->syncCommon($target_db, 'evervc_project','evervc_project','project_name,tags');
        }

        public function check(){
            $target_db = $this->databaseObj('nuts_tool');
            $data = $this->selectData($target_db,'company_project_industry_map','project_id');

            $sql = "UPDATE company_project SET map=1 WHERE id=:id";
            $st = $target_db->prepare($sql);
            foreach ($data as $d) {
                $st->bindParam(':id',$d);
                $st->execute();
            }
        }

        public function syncCommon($target_db, $dbname, $table, $field, $type = PDO::FETCH_ASSOC){
            $db = $this->databaseObj($dbname);
            $data = $this->selectData($db,$table,$field,'',$type);

            $sql = "INSERT INTO company_project_industry_map(project_id,industry_map_id) VALUES(:pid,:mid)";
            $st = $target_db->prepare($sql);
            foreach ($data as $d) {
                if(empty($d['project_name']) || empty($d['tags'])) continue;
                
                $proj = $target_db->query("SELECT id FROM company_project WHERE project_name='".addslashes($d['project_name'])."'")->fetchAll(PDO::FETCH_COLUMN);
                if(empty($proj)) continue;

                $project_id = $proj[0];

                $tags = explode(',', $d['tags']);
                foreach ($tags as $tag) {
                    $t = $target_db->query("SELECT id FROM industry_map WHERE name='".addslashes($tag)."'")->fetchAll(PDO::FETCH_COLUMN);
                    if(empty($t)) continue;

                    $map_id = $t[0];

                    //echo $project_id.'--------------------'.$map_id."\r\n";

                    $st->bindParam(':pid', $project_id);
                    $st->bindParam(':mid',$map_id);
                    $st->execute();
                    echo "id : ".$target_db->lastInsertId()."\r\n";
                }
            }
            echo "===============\r\n";
        }

        public function databaseObj($dbname,$host = '127.0.0.1',$user = 'root',$password = 'root'){
            $db=new PDO('mysql:dbname='.$dbname.';host='.$host,$user,$password);
            $db->exec("set names utf8");

            return $db;
        }

        public function selectData($db, $table, $field, $where = '', $type = PDO::FETCH_COLUMN){
            $data = $db->query("SELECT ".$field." FROM ".$table." ".$where)->fetchAll($type); 
            
            return $data;
        }
    }