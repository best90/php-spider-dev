<?php
    class So{
        public function zhishu(){
            $db=new PDO('mysql:dbname=industry;host=127.0.0.1','root','root');
            $db->exec("set names utf8");

            $cache = CACHE_PATH . '/so/index/';

            $res = $db->query("SELECT id FROM index_zhishu")->fetchAll(PDO::FETCH_COLUMN);

            $sql = "UPDATE index_zhishu SET data=:data WHERE id=:id";
            $st = $db->prepare($sql);

            foreach ($res as $i) {
                $ids = $db->query("SELECT id,name FROM index_word WHERE pid=".$i)->fetchAll(PDO::FETCH_ASSOC);

                $index = [];
                foreach ($ids as $id) {
                    $file = $cache.$id['id'].'.txt';
                    if(!file_exists($file)) continue;

                    $text = file_get_contents($file);
                    $json_data = json_decode($text,true);

                    $index[] = explode('|', $json_data['data']['index'][$id['name']]);
                    $date = $json_data['data']['period'];
                }

                $index_arr = [];
                foreach ($index as $in) {
                    foreach ($in as $k => $n) {
                        @$index_arr[$k] += $n*5;
                    }
                }
                echo count($index_arr);
                $data = array(
                        'index' => $index_arr,
                        'date' => $date,
                    );
                $data = json_encode($data);

                $st->bindParam(':id',$i);
                $st->bindParam(':data',$data);

                $st->execute();
            }
        }
    }