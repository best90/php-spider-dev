<?php
    class Baidu{
        public function baike(){
            $db=new PDO('mysql:dbname=industry;host=127.0.0.1','root','root');
            $db->exec("set names utf8");

            $cache = CACHE_PATH . '/baidu/baike/';

            $res = $db->query("SELECT id,name FROM baike")->fetchAll(PDO::FETCH_ASSOC);

            $sql = "UPDATE baike SET word=:word,baike=:baike,intro=:intro WHERE id=:id";
            $st = $db->prepare($sql);

            foreach ($res as $re) {
                $file = $cache.$re['id'].'.html';
                if(!file_exists($file)) continue;

                $html = toUtf8(read($file));
                $list = $this->getSearchList($html);

                foreach ($list as $li) {
                    if($li['name'] != $re['name']) continue;
                    $st->bindParam(':id',$re['id']);
                    $st->bindParam(':word',$li['name']);
                    $st->bindParam(':baike',$li['url']);
                    $st->bindParam(':intro',$li['info']);

                    $st->execute();
                }

            }
        }

        public function news(){
            $db=new PDO('mysql:dbname=industry;host=127.0.0.1','root','root');
            $db->exec("set names utf8");

            $cache = CACHE_PATH . '/baidu/news/';

            $res = $db->query("SELECT id,name FROM news")->fetchAll(PDO::FETCH_ASSOC);

            $sql = "UPDATE news SET info=:info WHERE id=:id";
            $st = $db->prepare($sql);

            foreach ($res as $re) {
                $file = $cache.$re['id'].'.html';
                if(!file_exists($file)) continue;

                $html = toUtf8(read($file));
                $list = $this->getNewsList($html);

                $info = json_encode($list);
                
                $st->bindParam(':id',$re['id']);
                $st->bindParam(':info',$info);

                $st->execute();
            }
        }

        //APP111 厂商大全页面
        public function app111(){
            $db=new PDO('mysql:dbname=app;host=127.0.0.1','root','root');
            $db->exec("set names utf8");

            $cache = CACHE_PATH . '/baidu/app111/';

            $sql = "INSERT INTO app111_list(url,update_time) VALUES(:url,:utime) ON DUPLICATE KEY UPDATE update_time=VALUES(update_time)";
            $st = $db->prepare($sql);

            for ($i=0; $i <= 1420; $i++) {      
                $file = $cache.$i.'.html';
                if(!file_exists($file)) continue;

                $html = toUtf8(read($file));
                $list = $this->getIndexUrlList($html);
                if(empty($list)) continue;
            
                $date = date('Y-m-d H:i:s');
                foreach ($list as $val) {
                    if(empty($val['url'])) continue;

                    $st->bindParam(':url',$val['url']);
                    $st->bindParam(':utime',$date);
                    $st->execute();
                }
            }
        }

        //提取url信息
        private function getSearchList($html){
            $info = array();
            $dom = phpQuery::newDocumentHTML($html);

            $list = $dom['div.searchResult dl.search-list dd'];
            foreach ($list as $k => $li) {
                $info[$k]['name'] = trim(str_replace('_百度百科','',pq($li)->find('a.result-title')->text()));
                $info[$k]['url'] = trim(pq($li)->find('a.result-title')->attr('href'));
                $info[$k]['info'] = trim(pq($li)->find('p.result-summary')->text());
            }

            $dom -> unloadDocument();
            return $info;
        }

        //提取News列表信息
        private function getNewsList($html){
            $info = array();
            $dom = phpQuery::newDocumentHTML($html);

            $list = $dom['div.content table'];
            foreach ($list as $k => $li) {
                $info[$k]['title'] = trim(pq($li)->find('h3 a')->text());
                $info[$k]['url'] = trim(pq($li)->find('h3 a')->attr('href'));
                $str = trim(pq($li)->find('font .realtime')->text());
                $text = trim(str_replace($str,'',pq($li)->find('font')->text()));
                $info[$k]['info'] = mb_substr($text, 0, mb_strpos($text, '...')+3);
            }

            $dom -> unloadDocument();
            return $info;
        }

        //获取App111列表
        private function getIndexUrlList($html){
            $info = array();
            $dom = phpQuery::newDocumentHTML($html);

            $list = $dom['div#content_left .result'];
            foreach ($list as $k => $li) {
                $title = trim(pq($li)->find('h3.t a')->text());
                if(mb_strpos($title, '应用专区') === false) continue;
                $info[$k]['title'] = $title;

                $url = trim(pq($li)->find('h3.t a')->attr('href'));
                $info[$k]['url'] = $this->parseBaiduUrl($url);
            }

            $dom -> unloadDocument();
            return $info;
        }

        //获取301、302真实地址
        private function parseBaiduUrl($url){
            sleep(1);
            $header = get_headers($url,1);
            if (strpos($header[0],'301') || strpos($header[0],'302')) {
                if(is_array($header['Location'])) {
                    return $header['Location'][count($header['Location'])-1];
                }else{
                    return $header['Location'];
                }
            }else {
                return $url;
            }
        }
    }