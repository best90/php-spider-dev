<?php

	return array(
		'project' => array (
				'username' => 'root',
				'password' => 'root',
				'dsn' =>"mysql:host=127.0.0.1;dbname=project"
		),
	);


?>
